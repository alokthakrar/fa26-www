import marimo

__generated_with = "0.25.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Lab 4: Image Deconvolution and Reconstruction
    ### EE 66: Introduction to Signals, Dynamics, and Information

    **Acknowledgement:** Fall 2026 - Baris Oktay, Jonathan Loy, Daniel Lief, Preena Maruthavelu, Jacob Kwon

    A camera does not record the world directly. Light passes through an optical system, the sensor integrates that light over time and space, and electronics introduce noise. The resulting photograph may therefore be blurred even when the scene itself was sharp. In this lab, you will model that process as a linear system and design a stable reconstruction algorithm.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Table of Contents

    * [Task 0: Pre-lab](#part0)
    * [Task 1: The point-spread function](#part1)
    * [Task 2: From an integral to a sum](#task2)
    * [Task 3: Convolution is matrix multiplication](#part3)
    * [Task 4: What blur preserves and what it suppresses](#task4)
    * [Task 5: The inverse problem](#part5)
    * [Task 6: Regularization](#task6)
    * [Task 7: Model mismatch](#part7)
    * [Task 8: Design challenge helper functions](#task8)
    * [Task 9: Final challenge](#task9)
    * [Task 10: Further study](#part10)
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Learning objectives
    By the end of the lab, you should be able to:

    1. explain why many blur processes are modeled by convolution;
    2. move between continuous convolution, discrete convolution, and matrix multiplication;
    3. interpret a point-spread function as the response of an imaging system to a point;
    4. use singular values and the condition number to diagnose an unstable inverse problem;
    5. explain why direct inverse filtering amplifies noise;
    6. implement Tikhonov-regularized deconvolution;
    7. select a model and regularization strength using evidence rather than appearance alone.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Why image deconvolution and reconstruction matter

    Blur is not just a cosmetic inconvenience. A camera may move during exposure, a microscope may have a finite point-spread function, and an astronomical telescope may suppress fine spatial detail. In each case, the recorded image is an indirect, imperfect measurement of the scene.

    In this lab you will move continuously between four descriptions of the same system: a physical blur mechanism, a convolution sum or integral, a matrix operator, and a frequency-domain transfer function. The central task is **image deconvolution**: undoing blur when the forward model is convolution. We also use the broader word **reconstruction** because the final image is recovered from indirect, noisy measurements.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part0'></a>
    ## <span style="color:navy">Task 0: Pre-lab: why can a photograph be blurry?</span>

    ![Examples of image degradation](public/degradation_gallery.png)

    Blur can arise from several mechanisms:

    - **motion blur:** the camera or object moves while the shutter is open;
    - **defocus blur:** rays from one scene point spread over multiple sensor pixels;
    - **atmospheric or optical blur:** the system smooths fine spatial detail;
    - **sensor noise:** electronics add fluctuations that were not present in the scene.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Check-in 0.1: Which effects are reversible?
    Which of these effects sounds reversible? Which seems to permanently destroy information? Give a physical explanation before using equations.
    """)
    return


@app.cell(hide_code=True)
def _(answer_1, mo):
    mo.callout(answer_1, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <span style = "color:red">
    Please execute the following cell, as it contains all the necessary imports for this lab. </span>
    """)
    return


@app.cell
def _():
    # '%matplotlib inline' command supported automatically in marimo
    import numpy as np
    import matplotlib.pyplot as plt
    from pathlib import Path
    from scipy.signal import convolve2d
    from skimage.io import imread
    from utils.imaging import blur, gallery, gaussian_kernel, inverse_filter, motion_kernel, normalize, psf_to_otf, psnr, relerr, tikhonov
    plt.rcParams.update({'figure.figsize': (8, 4), 'font.size': 11})
    from tests.autograder import (
        test_Q2a,
        test_Q2b,
        test_Q4a,
        test_Q6a
    )
    from utils.challenge import (
        hash,
        try_candidates,
        make_message_image
    )

    return (
        blur,
        convolve2d,
        gallery,
        imread,
        inverse_filter,
        motion_kernel,
        np,
        plt,
        psf_to_otf,
        psnr,
        relerr,
        test_Q2a,
        test_Q2b,
        test_Q4a,
        test_Q6a,
        tikhonov,
        try_candidates,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Try another sample image
    The lab defaults to a single `camera.png` asset, but scikit-image ships several other openly-licensed sample images. Feel free to swap `sharp` for any of these later in the lab, or drop in your own image from `public/` the same way.
    """)
    return


@app.cell
def _(plt):
    from skimage import data, img_as_float
    sample_images = {'camera': img_as_float(data.camera()), 'astronaut (gray)': img_as_float(data.astronaut().mean(axis=2)), 'coins': img_as_float(data.coins()), 'checkerboard': img_as_float(data.checkerboard())}
    (_fig, _axs) = plt.subplots(1, len(sample_images), figsize=(12, 3))
    for (_ax, (name, _im)) in zip(_axs, sample_images.items()):
        _ax.imshow(_im, cmap='gray')
        _ax.set_title(name)
        _ax.axis('off')
    plt.tight_layout()
    # To try a different sample image anywhere below, e.g.:
    # sharp = sample_images["astronaut (gray)"]
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part1'></a>
    ## <span style="color:navy">Task 1. The point-spread function</span>
    An ideal camera would map one bright point in the scene to one bright pixel. A real camera maps that point to a small pattern called the **point-spread function** (PSF), denoted $h(x,y)$.

    If the system is approximately linear and shift invariant, the response to a complicated scene can be built by adding shifted copies of this PSF. For a continuous image $f(x,y)$, the measured image is

    $$g(x,y)=\int_{-\infty}^{\infty}\int_{-\infty}^{\infty} f(\xi,\eta)h(x-\xi,y-\eta)\,d\xi\,d\eta.$$

    This is the two-dimensional convolution integral. The variables $\xi$ and $\eta$ identify source locations. Each source value $f(\xi,\eta)$ contributes a shifted PSF to the output.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ![Examples of PSF](public/PSF.png)

    *Each pixel of a 2D image is convolved with the point-spread function (PSF) of the imaging system. Knowing the PSF allows us to reconstruct the image by deconvolving it with that PSF.* [1]
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Check-in 1.1: Interpret the integral

    Without evaluating the integral, explain what happens if $f(x,y)$ contains exactly one bright point. Then explain what happens if it contains two bright points. Your answer should connect superposition to the physical image formed on the sensor.
    """)
    return


@app.cell(hide_code=True)
def _(answer_2, mo):
    mo.callout(answer_2, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <!-- END QUESTION -->
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task2'></a>
    ## <span style="color:navy">Task 2. From an integral to a sum</span>
    Digital images are sampled on a grid. The discrete model is

    $$g[m,n]=\sum_{i}\sum_{j} f[i,j]h[m-i,n-j].$$

    For a one-dimensional signal, this becomes

    $$y[n]=\sum_{k=0}^{L-1}h[k]x[n-k].$$

    The kernel values tell us how one input sample is spread across neighboring output samples.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### 2A. 1D Convolution
    """)
    return


@app.cell
def _(np, plt):
    x_1 = np.array([0.0, 0.0, 1.0, 1.0, 0.0, 0.0])
    h_1 = np.array([0.25, 0.5, 0.25])
    y_1 = np.convolve(x_1, h_1, mode='same')
    (_fig, (ax1, ax2, ax3)) = plt.subplots(1, 3, figsize=(12, 4))
    ax1.stem(x_1, linefmt='C0-', markerfmt='C0o', basefmt=' ', label='input $x[n]$')
    ax1.legend()
    ax1.set_xlabel('sample index')
    ax2.stem(h_1, linefmt='C1-', markerfmt='C1s', basefmt=' ', label='system impulse response (aka PSF)')
    ax2.legend()
    ax2.set_xlabel('sample index')
    ax3.stem(y_1, linefmt='C2-', markerfmt='C2s', basefmt=' ', label='blurred $y[n]$')
    ax3.legend()
    ax3.set_xlabel('sample index')
    _fig.suptitle('A short averaging kernel spreads sharp changes')
    plt.tight_layout()
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### 2B. 2D Convolution
    Now that you know how a 1D convolution works, it is time to step up to 2D. Note that in order to use matrix multiplication (either by using **"@"** operator or **np.dot()** the width of the first matrix needs to match the height of the second matrix. So how can you apply a convolution?)
    """)
    return


@app.cell
def _(np):
    # Signal 
    x = np.array([[0.0, 0.0, 0.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0, 0.0], [0.0, 1.0, 1.0, 1.0, 0.0], [0.0, 0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 0.0, 0.0, 0.0]])
    h = np.array([[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]])
    # A 3 × 3 averaging PSF
    h = h / h.sum()
    return h, x


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Before coding: turn convolution into a matrix

    Convolution is linear, so after flattening an image into a vector we can write

    $$\mathbf y=H\mathbf x.$$

    Here $H$ is the matrix that performs convolution with the PSF. There are two useful ways to interpret it:

    - **Column $j$** is the complete output image produced by placing a single impulse at input pixel $j$ and then applying the blur.
    - **Row $i$** contains the contributions from every input pixel to output pixel $i$.

    The first interpretation gives us a direct construction algorithm: blur one impulse at a time, flatten each result, and store it as a column of $H$. The next exercise asks you to complete only the final flatten-and-store step.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Coding Exercise 2.1
    *Hint: Search numpy implementation for reshaping.*
    """)
    return


@app.cell
def _(convolve2d, np):
    def build_2d_convolution_matrix(psf, image_shape):
        """Construct H for zero-padded 2D ``same`` convolution.

        Args:
            psf: 2D NumPy array containing the blur kernel.
            image_shape: ``(rows, columns)`` of the images H will act on.

        Returns:
            A square array of shape ``(num_pixels, num_pixels)``.
        """
        num_pixels = int(np.prod(image_shape))
        H = np.zeros((num_pixels, num_pixels))

        for j in range(num_pixels):
            # Make an all-zero image, then put a single 1 at flat index j.
            impulse = np.zeros(image_shape)
            impulse.flat[j] = 1.0

            # Blur that impulse with the same PSF and mode used in the model.
            blurred_impulse = convolve2d(impulse, psf, mode="same")

            # Flatten the blurred impulse and store it as column j of H.

            # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
            raise NotImplementedError()
            H[:, j] = ...

        return H

    return (build_2d_convolution_matrix,)


@app.cell
def _(build_2d_convolution_matrix, mo, test_Q2a, test_Q2a_btn):
    if test_Q2a_btn.value:
        with mo.status.spinner(title="Running Test Build 2D Convolution Matrix..."):
            test_Q2a(build_2d_convolution_matrix)
    test_Q2a_btn
    return


@app.cell(hide_code=True)
def _(mo, Q2b_hint_1, Q2b_hint_2, Q2b_hint_3):
    mo.md(f"""
    ### Coding Exercise 2.2
    {Q2b_hint_1}
    {Q2b_hint_2}
    {Q2b_hint_3}
    """)
    return


@app.cell
def _(build_2d_convolution_matrix, convolve2d, h, np, x):
    H = build_2d_convolution_matrix(h, x.shape)

    # TODO: Flatten x, apply H, and reshape the result back to x.shape.

    # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
    raise NotImplementedError()
    x_vec = ...
    y_vec = ...
    y_matrix = ...

    y_reference = convolve2d(x, h, mode='same')
    print('Image shape:', x.shape)
    # Reference result for verification
    return H, x_vec, y_matrix, y_reference


@app.cell
def _(H, mo, test_Q2b, test_Q2b_btn, x, x_vec, y_matrix):
    if test_Q2b_btn.value:
        with mo.status.spinner(title="Running Test Q2B..."):
            test_Q2b(H, x, x_vec, y_matrix)
    test_Q2b_btn
    return


@app.cell
def _(H, h, plt, x, y_matrix, y_reference):
    (_fig, axes) = plt.subplots(2, 3, figsize=(14, 7))
    images = [(x, 'Input image $x$', 'gray'), (h, 'Point-spread function (PSF) $h$', 'viridis'), (H, 'Convolution matrix $H$', 'viridis'), (y_reference, 'Scipy Built-in convolve2d(x, h)', 'gray'), (y_matrix, 'Custom 2D Convolution', 'gray')]
    flat_axes = axes.flat
    for (_ax, (image, title, cmap)) in zip(flat_axes, images):
        _im = _ax.imshow(image, cmap=cmap)
        _ax.set_title(title)
        _ax.set_xlabel('column')
        _ax.set_ylabel('row')
        _fig.colorbar(_im, ax=_ax, fraction=0.046, pad=0.04)
    for _ax in flat_axes[len(images):]:
        _ax.axis('off')
    plt.tight_layout()
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The two output images should match: the lower-left result uses SciPy's convolution directly, while the lower-middle result uses $H\mathbf x$. The image of $H$ is not another photograph; its rows and columns visualize how input pixels are connected to output pixels by the PSF.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Optional: Calculate by hand

    Compute the output sample at the center of the signal using the convolution sum. Identify which input samples contribute and how strongly. Then verify that your answer matches the plotted output.
    """)
    return


@app.cell(hide_code=True)
def _(answer_3, mo):
    mo.callout(answer_3, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part3'></a>
    ## <span style="color:navy">Task 3. Convolution is matrix multiplication</span>

    Convolution is a **linear operation**, which means it can always be written as a matrix multiplication.

    Instead of writing

    $$
    y = h * x,
    $$

    we can vectorize the image and write

    $$
    \mathbf{y} = H\mathbf{x},
    $$

    where

    - $\mathbf{x}$ is the flattened input image,
    - $\mathbf{y}$ is the flattened blurred image,
    - $H$ is the **convolution matrix** constructed from the point-spread function (PSF) $h$.

    The PSF is still the blur kernel. The matrix $H$ simply applies that same kernel to **every pixel simultaneously**.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Example (1D)

    For the averaging kernel

    $$
    h=
    \begin{bmatrix}
    0.25 & 0.50 & 0.25
    \end{bmatrix},
    $$

    the convolution matrix becomes

    $$
    H=
    \begin{bmatrix}
    0.50 & 0.25 & 0    & 0    & 0    & 0\\
    0.25 & 0.50 & 0.25 & 0    & 0    & 0\\
    0    & 0.25 & 0.50 & 0.25 & 0    & 0\\
    0    & 0    & 0.25 & 0.50 & 0.25 & 0\\
    0    & 0    & 0    & 0.25 & 0.50 & 0.25\\
    0    & 0    & 0    & 0    & 0.25 & 0.50
    \end{bmatrix}.
    $$

    Notice that every diagonal contains the same value. This is the defining property of a **Toeplitz matrix**.

    ### Why is this useful?

    Representing convolution as matrix multiplication allows us to use powerful tools from linear algebra. Once the blur is written as

    $$
    \mathbf{y}=H\mathbf{x},
    $$

    we can study questions such as

    - Is the blur invertible?
    - How much information is lost?
    - How sensitive is the reconstruction to noise?

    Using the matrix $H$, we can analyze these questions using concepts such as

    - Singular Value Decomposition (SVD)
    - Matrix rank
    - Condition number
    - Least-squares reconstruction
    - Regularization

    These ideas form the foundation of many modern image reconstruction algorithms used in CT, MRI, microscopy, astronomy, and computational photography.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Check-in 3.1: Building H

    **Question:** Think about how you would build the matrix $H$.

    Suppose the input image contains a single nonzero pixel (an impulse), while all other pixels are zero.

    What should one column of the convolution matrix $H$ contain?

    **Hint:** Each column corresponds to the output produced by one basis image containing a single impulse.
    """)
    return


@app.cell(hide_code=True)
def _(answer_4, mo):
    mo.callout(answer_4, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **New: visualize the matrix structure.** Printing $H$ as numbers is hard to read once it gets bigger than a few rows. Plotting it as an image makes the Toeplitz (constant-diagonal) structure obvious at a glance.
    """)
    return


@app.cell
def _(H, plt):
    (_fig, _ax) = plt.subplots(figsize=(4, 4))
    _im = _ax.imshow(H, cmap='viridis')
    _ax.set_title('Structure of H (Toeplitz)')
    _ax.set_xlabel('input index')
    _ax.set_ylabel('output index')
    plt.colorbar(_im, fraction=0.046)
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task4'></a>
    ## <span style="color:navy">Task 4. What blur preserves and what it suppresses</span>
    The singular value decomposition writes

    $$H=U\Sigma V^T.$$

    The columns of $V$ are input patterns. Multiplying by $H$ scales each pattern by its singular value and rotates it into an output pattern. A large singular value means the pattern survives strongly; a small singular value means the camera almost erases it.

    This is what **ill-conditioned** means here: the camera measures some input patterns strongly and other patterns extremely weakly. Recovering a weak pattern requires dividing by its small singular value. Dividing by a number near zero produces a very large result, so even tiny measurement noise can become a large reconstruction error.
    """)
    return


@app.cell
def _(H, np, plt, x):
    (U, s, Vt) = np.linalg.svd(H)
    (_fig, _axs) = plt.subplots(1, 3, figsize=(13, 3.5))
    _axs[0].stem(np.arange(len(s)), s)
    _axs[0].set_title('singular values')
    _axs[0].set_xlabel('index')
    _axs[1].imshow(Vt[0].reshape(x.shape), cmap='coolwarm')
    _axs[1].set_title('best-preserved input direction')
    _axs[2].imshow(Vt[-1].reshape(x.shape), cmap='coolwarm')
    _axs[2].set_title('most-suppressed input direction')
    _axs[1].axis('off')
    _axs[2].axis('off')
    plt.tight_layout()
    print('condition number =', np.linalg.cond(H))
    plt.show()
    return (s,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The condition number is

    $$\kappa(H)=\frac{\sigma_{\max}}{\sigma_{\min}}.$$

    A condition number near $1$ means all input directions are measured at similar strength. A large condition number means the weakest direction is measured much less strongly than the best-preserved direction. For example, if a direction is scaled by $0.001$, direct inversion must divide by $0.001$ -- an amplification of $1000$ for both the desired signal and any noise in that direction.
    """)
    return


@app.cell(hide_code=True)
def _(mo, condition_num_hint_1, condition_num_hint_2):
    mo.md(f"""
    ### Coding Exercise 4.1
    **New task -- compute the condition number yourself.** You already have `s`, the singular values, from the cell above. Fill in `condition_number` below (don't just call `np.linalg.cond` -- compute it directly from `s` so you can see exactly what the formula from the equation above is doing).

    {condition_num_hint_1}
    {condition_num_hint_2}
    """)
    return


@app.cell
def _(np, s):
    # TODO: Compute the condition number directly from the singular values in s.

    # YOUR CODE HERE
    condition_number = None

    print(f"kappa(H) = {condition_number:.3g}")
    return (condition_number,)


@app.cell
def _(condition_number, mo, s, test_Q4a, test_Q4a_btn):
    if test_Q4a_btn.value:
        with mo.status.spinner(title="Running Test Condition Number..."):
            test_Q4a(condition_number, s)
    test_Q4a_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part5'></a>
    ## <span style="color:navy">Task 5. The inverse problem</span>
    Our camera model is

    $$\mathbf y=H\mathbf x+\mathbf n,$$

    where $\mathbf n$ represents noise. If $H$ were perfectly invertible, we might try

    $$\hat{\mathbf x}=H^{-1}\mathbf y.$$

    Substituting the noisy model gives

    $$\hat{\mathbf x}=\mathbf x+H^{-1}\mathbf n.$$

    Therefore, the inverse acts on the noise too. Directions associated with small singular values are multiplied by approximately $1/\sigma_i$, which can be enormous.

    A simple analogy is turning up the volume on a very quiet recording. The desired sound becomes louder, but so does the hiss. Blur makes some image patterns -- especially fine spatial detail -- very quiet, and direct inversion turns both those patterns and the measurement noise back up.
    """)
    return


@app.cell
def _(blur, gallery, imread, motion_kernel):
    sharp=imread('public/camera.png',as_gray=True)
    psf=motion_kernel(19,12)
    observed=blur(sharp,psf,noise_std=.012,seed=66)
    gallery([sharp,psf/psf.max(),observed],['unknown sharp image','motion PSF','camera measurement'])
    return observed, psf, sharp


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Check-in 5.1: Predict inverse-filter behavior

    The Fourier transform converts circular convolution into multiplication:

    $$Y[k,\ell]=H[k,\ell]X[k,\ell]+N[k,\ell].$$

    Here $H[k,\ell]$ is the **optical transfer function (OTF)**: the Fourier transform, or frequency response, of the PSF. It tells us how strongly the camera passes each spatial frequency.

    Direct inverse filtering uses

    $$\hat X[k,\ell]=\frac{Y[k,\ell]}{H[k,\ell]}.$$

    Predict what happens where $|H[k,\ell]|$ is close to zero.
    """)
    return


@app.cell(hide_code=True)
def _(answer_5, mo):
    mo.callout(answer_5, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <!-- END QUESTION -->
    """)
    return


@app.cell
def _(inverse_filter, np, observed, plt, psf, psf_to_otf):
    naive = inverse_filter(observed, psf, eps=1e-06)
    Hf = psf_to_otf(psf, observed.shape)
    (_fig, _axs) = plt.subplots(1, 3, figsize=(13, 4))
    _axs[0].imshow(np.log1p(np.abs(np.fft.fftshift(Hf))), cmap='magma')
    _axs[0].set_title('$\\log(1+|H|)$')
    _axs[1].imshow(observed, cmap='gray')
    _axs[1].set_title('measurement')
    _axs[2].imshow(naive, cmap='gray')
    _axs[2].set_title('direct inverse')
    for _ax in _axs:
        _ax.axis('off')
    plt.tight_layout()
    plt.show()
    return (Hf,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **New: look at the *actual* frequency response of this PSF.** `Hf` above is already the OTF of `psf`. Here we look directly at where it gets small -- those are exactly the frequencies the naive inverse amplifies out of control.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Fourier-domain and instability
    Complex exponentials are eigenfunctions of shift-invariant systems. If the input is a sinusoidal pattern, convolution changes its amplitude and phase but not its spatial frequency. That property is why the Fourier domain diagonalizes circular convolution: one large coupled system becomes many scalar equations, one per frequency. The speedup is useful, but frequencies where the transfer function is nearly zero remain hard to recover.
    """)
    return


@app.cell
def _(Hf, np, plt):
    (_fig, _ax) = plt.subplots(figsize=(4.5, 4.5))
    _im = _ax.imshow(np.log1p(np.abs(np.fft.fftshift(Hf))), cmap='inferno')
    _ax.set_title('|H(w)| for this PSF (log scale)')
    _ax.axis('off')
    plt.colorbar(_im, fraction=0.046)
    plt.show()
    print('smallest |H(w)|:', np.min(np.abs(Hf)), '  largest:', np.max(np.abs(Hf)))
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Check-in 5.2: Diagnose inverse-filter artifacts

    Describe at least two artifacts in the direct inverse. Why does the result look worse than the input measurement even though the inverse filter is mathematically trying to undo the blur?
    """)
    return


@app.cell(hide_code=True)
def _(answer_6, mo):
    mo.callout(answer_6, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <!-- END QUESTION -->
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task6'></a>
    ## <span style="color:navy">Task 6. Regularization</span>
    Direct inversion becomes unstable because it divides by singular values or frequency responses that may be nearly zero. Dividing by a very small number greatly amplifies noise; dividing by zero is undefined. **Regularization prevents that blow-up.** It accepts that information nearly erased by the camera cannot be recovered reliably.

    Tikhonov regularization, also called ridge regression, solves

    $$\hat{\mathbf x}=\arg\min_{\mathbf x}\left(\|H\mathbf x-\mathbf y\|_2^2+\lambda\|\mathbf x\|_2^2\right).$$

    The first term asks: **If we blur the candidate reconstruction, does it reproduce the measurement?** The second discourages the algorithm from using extremely large pixel values merely to fit noise. The parameter $\lambda>0$ is a trust knob:

    - Small $\lambda$: trust the data more and recover more detail, but risk noise and ringing.
    - Large $\lambda$: limit unstable amplification more strongly, but lose edges and fine texture.

    Setting the gradient to zero gives the ridge-regression solution

    $$\hat{\mathbf x}=(H^TH+\lambda I)^{-1}H^T\mathbf y.$$

    The eigenvalues of $H^TH$ are $\sigma_i^2$. Adding $\lambda I$ changes the dangerous near-zero values to $\sigma_i^2+\lambda$, so the system is safer to solve.

    For convolution, the Fourier transform separates the problem into one scalar equation per spatial frequency. Direct inversion can be written as $\overline H Y/|H|^2$; regularization adds $\lambda$ to the denominator:

    $$\hat X[k,\ell]=\frac{\overline{H[k,\ell]}}{|H[k,\ell]|^2+\lambda}Y[k,\ell].$$

    If $|H[k,\ell]|$ is nearly zero, the denominator is now at least $\lambda$ instead of nearly zero. Regularization cannot recreate information that was completely erased, but it prevents noise from being mistaken for recovered detail.
    """)
    return


@app.cell
def _(blur, mo, motion_kernel, plt, sharp, tikhonov):
    # Interactive blur-and-reconstruct explorer
    # Change the physical blur and regularization strength in real time.
    length_slider = mo.ui.slider(1, 35, step=2, value=15, label="Length")
    angle_slider = mo.ui.slider(0, 170, step=10, value=20, label="Angle")
    lambda_slider = mo.ui.slider(-6, 0, step=0.25, value=-2.5, label="log10(lambda)")

    widgets = mo.hstack([length_slider, angle_slider, lambda_slider])

    def explore_reconstruction(length, angle, log10_lambda):
        psf_local = motion_kernel(length, angle)
        y_local = blur(sharp, psf_local, noise_std=0.012, seed=6)
        xhat = tikhonov(y_local, psf_local, 10 ** log10_lambda)
        (_fig, _ax) = plt.subplots(1, 4, figsize=(16, 4))
        _ax[0].imshow(sharp, cmap='gray')
        _ax[0].set_title('original')
        _ax[1].imshow(psf_local, cmap='magma')
        _ax[1].set_title('point-spread function')
        _ax[2].imshow(y_local, cmap='gray')
        _ax[2].set_title('measurement')
        _ax[3].imshow(xhat, cmap='gray')
        _ax[3].set_title(f'reconstructed, lambda={10 ** log10_lambda:.2g}')
        for a in _ax:
            a.axis('off')
        plt.tight_layout()
        return _fig

    mo.vstack([
        mo.md(r"""
        ### Interactive blur-and-reconstruct explorer

        - **Length** is the motion-blur length in pixels.
        - **Angle** is measured from the horizontal image axis: $0^\circ$ is horizontal, positive angles rotate counterclockwise, and negative angles rotate clockwise.
        - **log10(lambda)** controls regularization; for example, $-3$ means $\lambda=10^{-3}$.
        """),
        widgets,
    ])
    return angle_slider, explore_reconstruction, lambda_slider, length_slider


@app.cell
def _(angle_slider, explore_reconstruction, lambda_slider, length_slider):
    explore_reconstruction(length_slider.value, angle_slider.value, lambda_slider.value)
    return


@app.cell(hide_code=True)
def _(mo, regularization_hint_1, regularization_hint_2, regularization_hint_3):
    mo.md(f"""
    ### Coding Exercise 6.1
    Implement the frequency-domain form of the ridge/Tikhonov solution above.

    `y` and `psf` are real-valued 2D NumPy arrays, and `lam` is a positive scalar. Return a real-valued array with the same shape as `y`.

    {regularization_hint_1}
    {regularization_hint_2}
    {regularization_hint_3}
    """)
    return


@app.cell
def _(np, psf_to_otf):
    def regularized_restore(y, psf, lam):
        """Restore a 2D image using Fourier-domain Tikhonov regularization.

        Args:
            y: Real-valued 2D measured image.
            psf: Real-valued 2D point-spread function.
            lam: Positive regularization strength.

        Returns:
            A real-valued 2D reconstruction with the same shape as ``y``.
        """

        # DELETE THE FOLLOWING LINE AND IMPLEMENT THE FUNCTION BELOW
        raise NotImplementedError()

    return (regularized_restore,)


@app.cell
def _(mo, regularized_restore, test_Q6a, test_Q6a_btn):
    if test_Q6a_btn.value:
        with mo.status.spinner(title="Running Test Regularized Restore..."):
            test_Q6a(regularized_restore)
    test_Q6a_btn
    return


@app.cell
def _(np, observed, plt, psf, psnr, regularized_restore, relerr, sharp):
    lambdas = np.logspace(-6, -1, 10)
    recons = [np.clip(regularized_restore(observed, psf, _l), 0, 1) for _l in lambdas]
    errs = [relerr(_r, sharp) for _r in recons]
    qualities = [psnr(_r, sharp) for _r in recons]
    (_fig, _axs) = plt.subplots(2, 5, figsize=(15, 6))
    for (_ax, _r, _l, q) in zip(_axs.ravel(), recons, lambdas, qualities):
        _ax.imshow(_r, cmap='gray')
        _ax.set_title(f'$\\lambda={_l:.1e}$\nPSNR={q:.1f} dB')
        _ax.axis('off')
    plt.tight_layout()
    plt.show()
    return errs, lambdas


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Display ranges can hide reconstruction mistakes
    The gallery clips reconstructed images to the display range `[0, 1]` so the pictures are easy to compare. That display step can hide overshoot, undershoot, and ringing. When you evaluate an algorithm, inspect both the clipped image and the raw reconstruction values. A result can look acceptable after clipping while still being physically implausible.
    """)
    return


@app.cell
def _(lambdas, observed, psf, regularized_restore):
    # Inspect raw reconstruction values before display clipping.
    raw_recons = [regularized_restore(observed, psf, _l) for _l in lambdas]
    for (_l, _r) in zip(lambdas, raw_recons):
        print(f'lambda={_l:.1e}: min={_r.min():+.3f}, max={_r.max():+.3f}, std={_r.std():.3f}')
    return (raw_recons,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Choosing lambda without ground truth
    In the sweep above we used the original sharp image to compute error, but real reconstruction problems usually do not provide the answer key. One diagnostic is an L-curve: plot the measurement residual against the reconstruction norm as `lambda` varies. The corner is not a proof of optimality, but it makes the tradeoff between fitting the data and controlling instability visible.
    """)
    return


@app.cell
def _(convolve2d, lambdas, np, observed, plt, psf, raw_recons):
    # L-curve diagnostic: does not use the original sharp image.
    residual_norms = []
    solution_norms = []
    for _r in raw_recons:
        predicted = convolve2d(_r, psf, mode='same', boundary='wrap')
        residual_norms.append(np.linalg.norm(predicted - observed))
        solution_norms.append(np.linalg.norm(_r))
    plt.loglog(residual_norms, solution_norms, 'o-')
    for (_l, xv, yv) in zip(lambdas, residual_norms, solution_norms):
        plt.text(xv, yv, f'{_l:.0e}', fontsize=8)
    plt.xlabel('measurement residual norm')
    plt.ylabel('reconstruction norm')
    plt.title('L-curve diagnostic for lambda selection')
    plt.grid(True, which='both', alpha=0.3)
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Check-in 6.2: Interpret the sweep

    Identify one under-regularized reconstruction, one over-regularized reconstruction, and one reasonable compromise. For each, describe what happened to noise, ringing, edges, and fine texture.
    """)
    return


@app.cell(hide_code=True)
def _(answer_7, mo):
    mo.callout(answer_7, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <!-- END QUESTION -->
    """)
    return


@app.cell
def _(errs, lambdas, np, plt):
    plt.semilogx(lambdas,errs,'o-',label='relative error')
    plt.xlabel('$\lambda$'); plt.ylabel('relative error'); plt.grid(True,alpha=.3)
    best=int(np.argmin(errs)); print('best tested lambda:',lambdas[best])
    plt.show()
    return (best,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part7'></a>
    ## <span style="color:navy">Task 7. Model mismatch</span>
    An optimizer can solve the wrong model perfectly. In practice, we rarely know the exact PSF. You are given one measurement and several candidate motion directions. Reconstruct with each candidate and decide which physical model is most plausible.
    """)
    return


@app.cell
def _(
    best,
    blur,
    gallery,
    lambdas,
    motion_kernel,
    np,
    observed,
    regularized_restore,
):
    angles = [-15, 0, 12, 25, 40]
    trial_psfs = [motion_kernel(19, a) for a in angles]
    # Keep raw reconstructions for quantitative scores; gallery clips only for display.
    trial = [regularized_restore(observed, k, lambdas[best]) for k in trial_psfs]
    residuals = [np.linalg.norm(blur(_r, k, clip=False) - observed) for (_r, k) in zip(trial, trial_psfs)]
    gallery(trial, [f'assumed {a} degrees\nresid={e:.2f}' for (a, e) in zip(angles, residuals)], cols=3, figsize=(12, 7))
    return angles, residuals, trial


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Residuals, roughness, and overfitting
    A small forward residual means the candidate reconstruction reproduces the measurement after the assumed blur is applied. That is necessary, but not sufficient: a noisy or ringing image can also fit the measurement.

    The roughness score below measures changes between neighboring pixels using horizontal and vertical finite differences. Noise and ringing usually increase this score, so combining residual and roughness can reject an unstable reconstruction. However, real edges, text, and fine texture also increase roughness. The rule can therefore prefer an overly smooth image. Its weight is subjective, so always state a failure mode when using it.
    """)
    return


@app.cell
def _(angles, np, plt, residuals, trial):
    def roughness_score(x):
        vertical = np.diff(x, axis=0)
        horizontal = np.diff(x, axis=1)
        return np.linalg.norm(vertical) + np.linalg.norm(horizontal)
    roughness = np.array([roughness_score(_r) for _r in trial])
    resid = np.array(residuals)
    resid_n = resid / (resid.max() + 1e-12)
    rough_n = roughness / (roughness.max() + 1e-12)
    no_reference_score = resid_n + 0.2 * rough_n
    best_model = int(np.argmin(no_reference_score))
    plt.figure(figsize=(7, 3))
    plt.bar([str(a) for a in angles], no_reference_score)
    plt.xlabel('assumed motion angle')
    plt.ylabel('residual + 0.20 roughness penalty')
    plt.title(f'No-reference rule picks {angles[best_model]} degrees')
    plt.grid(True, axis='y', alpha=0.3)
    print('best angle by this rule:', angles[best_model])
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### (Optional) 7.1: Select a PSF
    Develop a rule for selecting the candidate PSF without access to the original sharp image. Your rule may use the forward-model residual, image smoothness, edge statistics, or another defensible quantity. Explain one failure mode of your rule.
    """)
    return


@app.cell(hide_code=True)
def _(answer_8, mo):
    mo.callout(answer_8, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task8'></a>
    ## <span style="color:navy">Task 8. Design challenge: Creating Helper Functions to Deblur Images</span>
    Implement the following helper functions that will be used to deblur the images

    For evaluate, make sure to return x_hat (the recovered image) and r (the residual) in that order.
    """)
    return


@app.cell
def _(blur, motion_kernel, np, regularized_restore):
    def residual(Hx_hat, y): 
        """
        Returns the residual || H x_hat - y ||. 
        """ 
        raise NotImplementedError()

    def evaluate(y, angle, lam, length):
        """
        Try one (angle, lam) candidate. Each call uses 1 of your 12 tries. 

        y: 2D NumPy array containing the observed blurred image.
        angle: scalar blur direction in degrees, measured counterclockwise from
            the horizontal image axis (negative values rotate clockwise).
        lam: positive scalar regularization strength.
        length: positive integer blur length in pixels.


        Returns x_hat (the recovered image) and r (the residual). 

        Functions you will use:

        motion_kernel(length, angle): builds a small blur kernel, a straight line `length` pixels long at `angle` degrees.

        regularized_restore(y, kernel, lam): deblurs y with Tikhonov
        regularization using the constructed kernel. Larger lam usually gives a
        more stable but less detailed result. Returns the recovered image x_hat.

        blur(v, kernel, clip=False): gives the unclipped linear prediction Hv.
        """
        raise NotImplementedError()

    return (evaluate,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task9'></a>
    ## <span style="color:navy">Task 9. Final challenge: reveal the hidden message</span>
    You will be asked to input your SID to generate a random code. This code will be placed into an image and then blurred. Your job is to deblur the image to recover the secret code.

    You may evaluate at most **12 candidate reconstructions**. Choose both a blur angle and a regularization strength.

    **Angle convention:** $0^\circ$ is horizontal. Positive angles rotate the motion stripe counterclockwise (for example, $+30^\circ$ looks like `/`), while negative angles rotate it clockwise (for example, $-30^\circ$ looks like `\`). Because the PSF is an unoriented line rather than an arrow, angles that differ by $180^\circ$ describe the same blur direction.

    Enter each candidate as two numbers separated by one comma, with no parentheses; for example: `10, 1e-3`.

    Once the secret code is readable, keep your clearest reconstruction visible for your TA to inspect during checkoff.

    Run the following cell to begin the final challenge
    """)
    return


@app.cell(hide_code=True)
def _(motion_kernel, plt):
    _angles = (-30, 0, 30)
    _fig, _axes = plt.subplots(1, 3, figsize=(7.2, 2.3))
    for _ax, _angle in zip(_axes, _angles):
        _ax.imshow(motion_kernel(21, _angle), cmap="gray")
        _direction = "clockwise" if _angle < 0 else "counterclockwise" if _angle > 0 else "horizontal"
        _ax.set_title(f"{_angle:+d}°: {_direction}" if _angle else "0°: horizontal")
        _ax.axis("off")
    _fig.suptitle("Motion-PSF angle convention")
    _fig.tight_layout()
    _fig
    return


@app.cell
def _(evaluate, final_challenge_btn, try_candidates):
    if final_challenge_btn.value:
        try_candidates(evaluate)
    final_challenge_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part10'></a>
    ## <span style="color:navy">Task 10. Further study</span>
    If you would like to learn more about image deconvolution and reconstruction, take a look at the following topics after the required work is complete.

    **A. Smoothness regularization.** Replace $\|x\|_2^2$ with $\|Dx\|_2^2$, where $D$ computes finite differences. Explain why this prior may preserve broad intensity while discouraging pixel-to-pixel oscillation.

    **B. Wiener filtering.** Assume signal and noise power levels are known and compare the Wiener filter with Tikhonov regularization.

    **C. Blind deconvolution.** After the required lab, alternate between estimating the image and estimating a low-dimensional PSF. Keep this optional: the ambiguity is the main lesson, not a required implementation.

    **D. Color reconstruction.** Apply the method to color channels and identify color artifacts.
    """)
    return


@app.cell
def _(
    H,
    build_2d_convolution_matrix,
    condition_number,
    mo,
    regularized_restore,
    s,
    test_Q2a,
    test_Q2b,
    test_Q4a,
    test_Q6a,
    test_all_btn,
    x,
    x_vec,
    y_matrix,
):
    if test_all_btn.value:
        with mo.status.spinner(title="Running Test Build 2D Convolution Matrix..."):
            test_Q2a(build_2d_convolution_matrix)
            test_Q2b(H, x, x_vec, y_matrix)
            test_Q4a(condition_number, s)
            test_Q6a(regularized_restore)
    test_all_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='feedback'></a>
    ## Feedback
    If you have any feedback to give the teaching staff about the labs (lab content, staff, etc), you can submit it through this Google form. Responses are **fully anonymous** and responses are actively monitored to improve the labs and course. Completing this form is **not required**.

    [Anonymous feedback Google form](https://forms.gle/ezDiDHxYRHN7xtdV9)

    *If you have a personal matter to discuss or need a response to your feedback, please contact <a href="mailto:ee66.lab@berkeley.edu">ee66.lab@berkeley.edu</a> and/or <a href="mailto:ee66@berkeley.edu">ee66@berkeley.edu</a>*.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='checkoff'></a>
    ## Checkoff
    When you are ready to get checked off, fill out the **[checkoff Google form](https://forms.gle/pwqopqgEaHvv7GUk9)**.

    Your TA or a Lab Assistant will join you when they are available and go through some checkoff questions with you and your partner (if applicable). They will go through the checkoff list in order. Please be patient!
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## References

    [1] D. R. Gennaro and G. G. Z. Zhang, A Postprocessing Method for Spatially Variant Point Spread Function Compensation, 2010. Available: https://api.semanticscholar.org/CorpusID:14681321

    [2] R. C. Gonzalez and R. E. Woods, *Digital Image Processing*, 4th ed. Pearson, 2018 -- background on the convolutional imaging model, point-spread functions, and inverse/Wiener filtering.

    [3] A. N. Tikhonov and V. Y. Arsenin, *Solutions of Ill-Posed Problems*. Winston & Sons, 1977 -- the regularization framework used in Section 6.

    [4] G. H. Golub, P. C. Hansen, and D. P. O'Leary, "Tikhonov Regularization and Total Least Squares," *SIAM J. Matrix Anal. Appl.*, 21(1), 1999 -- selecting $\lambda$ (background for the L-curve idea and the $\lambda$-sweep in Section 6).

    [5] S. van der Walt et al., "scikit-image: Image processing in Python," *PeerJ* 2:e453, 2014 -- the `skimage.data` sample images (`camera`, `astronaut`, `coins`, `checkerboard`, ...) used throughout this lab.

    [6] Otter-Grader documentation, https://otter-grader.readthedocs.io/ -- public notebook checks used for the coding TODOs.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    answer_1 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_2 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_3 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_4 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_5 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_6 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_7 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_8 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    test_Q2a_btn = mo.ui.run_button(label="Test Build 2D Convolution Matrix")
    test_Q2b_btn = mo.ui.run_button(label="Test Q2b")
    test_Q4a_btn = mo.ui.run_button(label="Test Condition Number")
    test_Q6a_btn = mo.ui.run_button(label="Test Regularization Restore")
    test_all_btn = mo.ui.run_button(label="Test All")
    final_challenge_btn = mo.ui.run_button(label="Start Final Challenge")
    Q2b_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": "x_vec should have shape (number of pixels,), not x.shape."}, lazy=False)
    )
    Q2b_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": "Matrix multiplication gives y_vec = H @ x_vec."}, lazy=False)
    )
    Q2b_hint_3 = mo.as_html(
        mo.accordion({"Hint #3": "Reshape y_vec back to the original image shape before comparing."}, lazy=False)
    )
    condition_num_hint_1 = mo.as_html(
            mo.accordion({"Hint #1": "np.linalg.svd returns singular values sorted from largest to smallest."}, lazy=False)
    )
    condition_num_hint_2 = mo.as_html(
            mo.accordion({"Hint #2": "kappa(H) = sigma_max / sigma_min."}, lazy=False)
    )
    regularization_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": "Convert the PSF into the frequency response H with psf_to_otf(psf, y.shape), and compute Y with np.fft.fft2(y)."}, lazy=False)
    )
    regularization_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": "Apply Xhat = conj(H) * Y / (abs(H)**2 + lam)."}, lazy=False)
    )
    regularization_hint_3 = mo.as_html(
        mo.accordion({"Hint #3": "Transform Xhat back with np.fft.ifft2 and return its real part."}, lazy=False)
    )
    return (
        Q2b_hint_1,
        Q2b_hint_2,
        Q2b_hint_3,
        answer_1,
        answer_2,
        answer_3,
        answer_4,
        answer_5,
        answer_6,
        answer_7,
        answer_8,
        final_challenge_btn,
        test_Q2a_btn,
        test_Q2b_btn,
        test_Q4a_btn,
        test_Q6a_btn,
        test_all_btn,
        condition_num_hint_1,
        condition_num_hint_2,
        regularization_hint_1,
        regularization_hint_2,
        regularization_hint_3,
    )


@app.cell
def _():
    import marimo as mo

    return (mo,)


if __name__ == "__main__":
    app.run()

import hashlib
import numpy as np
from matplotlib import pyplot as plt
from utils.imaging import blur, normalize, motion_kernel, gallery

ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
#LENGTH = 30

def hash(sid, length=6, salt="deblur-challenge"):
    """
    Map a 10-digit student ID to a short readable code like 'K7R-M2Q'.
    The same sid always gives the same code.
    """
    s = str(sid).strip()
    if not (s.isdigit() and len(s) == 10):
        raise ValueError("sid must be a 10-digit number.")

    digest = hashlib.sha256((salt + s).encode()).digest()
    n = int.from_bytes(digest, "big")

    chars = []
    for _ in range(length):
        n, r = divmod(n, len(ALPHABET))
        chars.append(ALPHABET[r])

    half = length // 2
    return "".join(chars[:half]) + "-" + "".join(chars[half:])



def try_candidates(evaluate, budget=12, noise_sigma=0.01, length=75):
    """Prompt for the student's sid, build their blurred measurement, then
    prompt for up to `budget` (angle, lambda) pairs and show each result."""
    while True:
        sid = input("Enter your 10-digit student ID: ").strip()
        if sid.isdigit() and len(sid) == 10:
            break
        print("That isn't a 10-digit number. Please try again.")

    code = hash(sid)
    show_code = True
    x = make_message_image(code)
    rng = np.random.default_rng(int(sid))
    y = blur(x, motion_kernel(length, angle_from_id(sid))) \
        + noise_sigma * rng.standard_normal(x.shape)

    gallery([y],['challenge measurement'])
    plt.show()

    tries = 0
    while tries < budget:
        entry = input(f"Try {tries + 1}/{budget}: angle, lambda "
                      f"(e.g. 10, 1e-3), type your secret code if you think you found it, or press Enter to stop: ")
        if entry.strip() == "":
            show_code = False
            break
        elif entry.strip() == code:
            print("Congrats, you successfully found the secret code!")
            print("Keep your clearest reconstruction visible for your TA to inspect during checkoff.")
            break
        elif len(entry.split(",")) == 1:
            print("Sorry, that was not the secret code, please try again or continue deblurring.")
            continue
        try:
            angle_str, lam_str = entry.split(",")
            angle, lam = float(angle_str), float(lam_str)
            if lam <= 0:
                raise ValueError
            if angle <= -50 or angle > 50:
                raise ValueError
        except ValueError:
            print("Couldn't read that. Use the format: angle (-50 < angle <= 50), lambda  (lambda > 0)")
            continue

        result = evaluate(y, angle, lam, length)
        tries += 1
        print(f"Try {tries}: angle={angle} degrees, lambda={lam:.0e}, residual={result[1]:.2f}")
        gallery([np.clip(y, 0, 1), np.clip(result[0], 0, 1)],
                ["Blurred measurement", f'Try {tries}: {angle} degrees, lambda={lam:.0e}\nresid={result[1]:.2f}'],
                cols=2, figsize=(10, 3.5))
        plt.show()

    print(f"Used {tries}/{budget} tries.")
    if tries == budget:
        entry = input("Now that you've used all your tries, what do you think the secret code is?")
        if entry.strip() == code:
            print("Congrats, you successfully found the secret code!")
            print("Keep your clearest reconstruction visible for your TA to inspect during checkoff.")
        else:
            print("Sorry, that was not the secret code. Here is the secret code:")
    if show_code:
        gallery([x], ["Your code"])
        plt.show()

def make_message_image(message, shape=(192, 192), fontsize=24):
    _fig = plt.figure(figsize=(shape[1] / 100, shape[0] / 100), dpi=100)
    _ax = _fig.add_axes([0, 0, 1, 1])
    _ax.set_facecolor('white')
    _ax.text(0.5, 0.52, message, ha='center', va='center', fontsize=fontsize, weight='bold', wrap=True)
    _ax.set_xlim(0, 1)
    _ax.set_ylim(0, 1)
    _ax.axis('off')
    _fig.canvas.draw()
    rgba = np.asarray(_fig.canvas.buffer_rgba())
    plt.close(_fig)
    gray = 1 - rgba[..., :3].mean(axis=2) / 255
    return normalize(gray)

def make_hidden_message_challenge(message, angle=15, length=21, noise_std=0.015, seed=66):
    clean = make_message_image(message)
    h = motion_kernel(length, angle)
    challenge = blur(clean, h, noise_std=noise_std, seed=seed)
    return clean, h, challenge

def angle_from_id(sid):
    return (int(sid) % 100) - 49

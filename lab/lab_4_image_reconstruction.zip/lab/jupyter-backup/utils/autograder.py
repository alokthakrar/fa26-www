"""Lightweight EE 66 check feedback wrapper.

These checks are a friendly fallback for notebooks that are not running Otter.
The Otter metadata in the notebook mirrors the deterministic coding checks.
"""
import numpy as np
from scipy.signal import convolve2d

from utils.imaging import psf_to_otf


def _report(name, passed, detail=""):
    if passed:
        print(f"PASS - {name}: {detail}")
    else:
        print(f"TRY AGAIN - {name}: {detail}")
    return bool(passed)


def test_build_2d_convolution_matrix(fn):
    psf = np.array([[0.0, 1.0, 0.0], [1.0, 2.0, 1.0], [0.0, 1.0, 0.0]])
    psf = psf / psf.sum()
    x = np.arange(12, dtype=float).reshape(3, 4)
    try:
        H = fn(psf, x.shape)
        out = (H @ x.ravel()).reshape(x.shape)
    except Exception as e:
        return _report("Q2a: 2D convolution matrix", False, f"({type(e).__name__}: {e})")
    expected = convolve2d(x, psf, mode="same")
    ok = isinstance(H, np.ndarray) and H.shape == (x.size, x.size) and np.allclose(out, expected)
    return _report("Q2a: 2D convolution matrix", ok)


def test_blur_matrix(fn):
    """Backward-compatible alias for older draft notebooks."""
    return test_build_2d_convolution_matrix(fn)


def test_condition_number(condition_number, singular_values):
    return _report(
        "Q4a: condition number",
        condition_number is not None
        and np.isfinite(condition_number)
        and np.isclose(condition_number, singular_values[0] / singular_values[-1]),
    )


def test_regularized(fn):
    y = np.arange(25, dtype=float).reshape(5, 5) / 25
    psf = np.ones((3, 3)) / 9
    lam = 1e-2
    H = psf_to_otf(psf, y.shape)
    expected = np.real(
        np.fft.ifft2(np.conj(H) * np.fft.fft2(y) / (np.abs(H) ** 2 + lam))
    )
    try:
        out = fn(y, psf, lam)
    except Exception as e:
        return _report("Q6a: regularized reconstruction", False, f"({type(e).__name__}: {e})")
    ok = (
        isinstance(out, np.ndarray)
        and out.shape == y.shape
        and np.isfinite(out).all()
        and np.allclose(out, expected)
    )
    return _report("Q6a: regularized reconstruction", ok)


def summary(results):
    results = list(results)
    n = sum(bool(x) for x in results)
    print(f"\nSUMMARY: {n}/{len(results)} autograder checks passed.")
    if n == len(results):
        print("All checked tasks passed!")

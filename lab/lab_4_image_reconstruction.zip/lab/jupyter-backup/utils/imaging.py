import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import convolve2d
from skimage.transform import rotate


def normalize(x):
    x = np.asarray(x, float)
    lo, hi = np.percentile(x, [0.5, 99.5])
    return np.clip((x - lo) / (hi - lo + 1e-12), 0, 1)


def gaussian_kernel(size=15, sigma=2.5):
    a = np.arange(size) - (size - 1) / 2
    xx, yy = np.meshgrid(a, a)
    k = np.exp(-(xx**2 + yy**2) / (2 * sigma**2))
    return k / k.sum()


def motion_kernel(length=17, angle_deg=0):
    length = int(length)
    if length < 1:
        raise ValueError("length must be positive")
    if length % 2 == 0:
        length += 1
    k = np.zeros((length, length))
    k[length // 2, :] = 1
    k = rotate(k, angle_deg, resize=False, order=1, preserve_range=True)
    return k / (k.sum() + 1e-12)


def blur(image, psf, noise_std=0, seed=66, clip=True):
    """Apply the circular-convolution model used by the FFT reconstructions."""
    y = convolve2d(image, psf, mode="same", boundary="wrap")
    if noise_std:
        y = y + np.random.default_rng(seed).normal(0, noise_std, y.shape)
    return np.clip(y, 0, 1) if clip else y


def psf_to_otf(psf, shape):
    """Pad and circularly center a PSF before taking its Fourier transform."""
    pad = np.zeros(shape)
    h, w = psf.shape
    pad[:h, :w] = psf
    pad = np.roll(pad, -(h // 2), axis=0)
    pad = np.roll(pad, -(w // 2), axis=1)
    return np.fft.fft2(pad)


def inverse_filter(y, psf, eps=1e-6):
    H = psf_to_otf(psf, y.shape)
    return np.real(np.fft.ifft2(np.fft.fft2(y) / (H + eps)))


def tikhonov(y, psf, lam):
    H = psf_to_otf(psf, y.shape)
    Y = np.fft.fft2(y)
    return np.real(np.fft.ifft2(np.conj(H) * Y / (np.abs(H) ** 2 + lam)))


def relerr(a, b):
    return np.linalg.norm(a - b) / (np.linalg.norm(b) + 1e-12)


def psnr(a,b):
    mse = np.mean((a - b) ** 2)
    return 10 * np.log10(1 / (mse + 1e-12))


def gallery(images, titles, cols=None, figsize=None):
    n = len(images)
    cols = cols or n
    rows = int(np.ceil(n / cols))
    figsize = figsize or (4 * cols, 3.4 * rows)
    fig, axs = plt.subplots(rows, cols, figsize=figsize)
    axs = np.atleast_1d(axs).ravel()
    for ax, img, title in zip(axs, images, titles):
        ax.imshow(img, cmap="gray", vmin=0, vmax=1)
        ax.set_title(title)
        ax.axis("off")
    for ax in axs[n:]:
        ax.axis("off")
    plt.tight_layout()
    return fig

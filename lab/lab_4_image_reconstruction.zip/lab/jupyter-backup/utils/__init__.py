"""Utility package for the image reconstruction lab draft.

Import imaging helpers from ``utils.imaging`` and checks from ``utils.autograder``.
Keeping this package initializer lightweight lets ``from utils import autograder``
work even when optional plotting/image dependencies are unavailable.
"""

__all__ = ["autograder"]

import sys
from pathlib import Path

import numpy as np
from scipy.signal import convolve2d

_BASE_DIR = Path(__file__).resolve().parent

for _p in (_BASE_DIR, _BASE_DIR.parent):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from utils.imaging import psf_to_otf


def _asymmetric_psf(n=3):
    k = np.arange(1.0, n * n + 1).reshape(n, n)
    return k / k.sum()


def test_Q2a(build_2d_convolution_matrix):
    assert callable(build_2d_convolution_matrix), (
        "Return build_2d_convolution_matrix from its Marimo cell so later cells can use it."
    )
    cases = [
        (_asymmetric_psf(3), (5, 5)),
        (_asymmetric_psf(3), (3, 4)),
        (_asymmetric_psf(3), (6, 4)),
        (np.ones((3, 3)) / 9, (4, 6)),
    ]
    rng = np.random.default_rng(0)
    for psf, shape in cases:
        image = rng.standard_normal(shape)
        H = build_2d_convolution_matrix(psf, shape)
        assert isinstance(H, np.ndarray), "H must be a NumPy array."
        assert H.shape == (image.size, image.size), (
            f"For an image of shape {shape}, H must be {image.size} x {image.size}."
        )
        actual = (H @ image.ravel()).reshape(shape)
        assert np.allclose(actual, convolve2d(image, psf, mode="same")), (
            f"H @ x does not match convolve2d for image shape {shape}. Column j of H "
            "should be the flattened blur of an impulse at flat index j."
        )

    print("Question 2a Passed!")


def test_Q2b(H, x, x_vec, y_matrix):
    assert np.shape(x_vec) == (x.size,), (
        "x_vec must be the flattened image with shape (number of pixels,)."
    )
    assert np.shape(y_matrix) == x.shape, (
        "Reshape y_vec back to the original image shape."
    )
    assert np.allclose(y_matrix, (H @ x.ravel()).reshape(x.shape)), (
        "y_matrix should equal H @ x_vec, reshaped to the image shape."
    )

    print("Question 2b Passed!")


def test_Q4a(condition_number, singular_values):
    assert condition_number is not None, "Fill in condition_number."
    assert np.ndim(condition_number) == 0 and np.isfinite(condition_number), (
        "condition_number must be a single finite number."
    )
    s = np.asarray(singular_values)
    assert np.isclose(condition_number, s.max() / s.min()), (
        "kappa(H) = sigma_max / sigma_min, using the singular values in s."
    )

    print("Question 4a Passed!")


def _expected_restore(y, psf, lam):
    H = psf_to_otf(psf, y.shape)
    return np.real(np.fft.ifft2(np.conj(H) * np.fft.fft2(y) / (np.abs(H) ** 2 + lam)))


def test_Q6a(regularized_restore):
    assert callable(regularized_restore), (
        "Return regularized_restore from its Marimo cell so later cells can use it."
    )
    y = np.random.default_rng(1).random((32, 24))
    for psf in (np.ones((3, 3)) / 9, _asymmetric_psf(5)):
        for lam in (1e-6, 1e-2, 1.0):
            out = regularized_restore(y, psf, lam)
            assert isinstance(out, np.ndarray) and out.shape == y.shape, (
                "Return an array with the same shape as y."
            )
            assert np.isrealobj(out), "Return the real part of np.fft.ifft2(Xhat)."
            assert np.isfinite(out).all(), "The output contains NaN or inf."
            assert np.allclose(out, _expected_restore(y, psf, lam)), (
                f"Output does not match conj(H) * Y / (|H|^2 + lam) for lam={lam}. "
                "Use the lam argument, not a fixed value."
            )

    y_before = y.copy()
    regularized_restore(y, np.ones((3, 3)) / 9, 0.1)
    assert np.array_equal(y, y_before), "regularized_restore must not modify y."

    print("Question 6a Passed!")
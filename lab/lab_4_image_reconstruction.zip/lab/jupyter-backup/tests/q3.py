import numpy as np
from scipy.signal import convolve2d


def test_build_2d_convolution_matrix(fn):
    psf = np.array([[0.0, 1.0, 0.0], [1.0, 2.0, 1.0], [0.0, 1.0, 0.0]])
    psf = psf / psf.sum()
    image = np.arange(12, dtype=float).reshape(3, 4)
    H = fn(psf, image.shape)
    got = (H @ image.ravel()).reshape(image.shape)
    expected = convolve2d(image, psf, mode="same")
    assert H.shape == (image.size, image.size)
    assert np.allclose(got, expected)

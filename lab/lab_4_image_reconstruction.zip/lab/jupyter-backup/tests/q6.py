import numpy as np
from utils.imaging import psf_to_otf


def test_regularized(fn):
    y = np.arange(25, dtype=float).reshape(5, 5) / 25
    psf = np.ones((3, 3)) / 9
    lam = 0.01
    H = psf_to_otf(psf, y.shape)
    expected = np.real(
        np.fft.ifft2(np.conj(H) * np.fft.fft2(y) / (np.abs(H) ** 2 + lam))
    )
    assert np.allclose(fn(y, psf, lam), expected)

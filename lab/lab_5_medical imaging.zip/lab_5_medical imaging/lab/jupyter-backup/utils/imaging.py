import numpy as np
import matplotlib.pyplot as plt
from skimage.transform import radon, iradon


def fft2c(x):
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(x)))


def ifft2c(k):
    return np.real(np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(k))))


def cartesian_mask(shape, accel=4, center_fraction=.12):
    h, w = shape
    mask = np.zeros(shape, dtype=bool)
    step = max(1, int(accel))
    mask[::step, :] = True
    c = max(2, int(round(h * center_fraction)))
    start = h // 2 - c // 2
    mask[start:start + c, :] = True
    return mask


def radial_mask(shape, spokes=20):
    h, w = shape
    yy, xx = np.indices(shape)
    cy, cx = (h - 1) / 2, (w - 1) / 2
    ang = np.arctan2(yy - cy, xx - cx)
    mask = np.zeros(shape, dtype=bool)
    for a in np.linspace(-np.pi / 2, np.pi / 2, spokes, endpoint=False):
        mask |= np.abs(np.angle(np.exp(1j * (ang - a)))) < np.pi / max(h, w)
    return mask


def sample_kspace(img, mask):
    return fft2c(img) * mask


def zero_fill(k):
    return ifft2c(k)


def make_sinogram(img, angles):
    return radon(img, theta=np.asarray(angles), circle=True)


def backproject(sino, angles, output_size):
    return iradon(sino, theta=np.asarray(angles), filter_name=None, circle=True, output_size=output_size)


def filtered_backproject(sino, angles, output_size):
    return iradon(sino, theta=np.asarray(angles), filter_name="ramp", circle=True, output_size=output_size)


def nrmse(a, b):
    return np.linalg.norm(a - b) / (np.linalg.norm(b) + 1e-12)


def gallery(images, titles, cols=None, figsize=None, cmap="gray"):
    n = len(images)
    cols = cols or n
    rows = int(np.ceil(n / cols))
    fig, axs = plt.subplots(rows, cols, figsize=figsize or (4 * cols, 3.4 * rows))
    axs = np.atleast_1d(axs).ravel()
    for ax, im, title in zip(axs, images, titles):
        ax.imshow(im, cmap=cmap)
        ax.set_title(title)
        ax.axis("off")
    for ax in axs[n:]:
        ax.axis("off")
    plt.tight_layout()
    return fig

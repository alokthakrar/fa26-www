"""Utility package for the medical imaging lab draft."""

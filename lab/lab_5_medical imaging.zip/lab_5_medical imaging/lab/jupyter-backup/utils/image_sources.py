"""Select grayscale source images for the medical-imaging exercises."""
from pathlib import Path

import numpy as np
from skimage.io import imread
from skimage.transform import resize
from skimage.util import img_as_float

_IMAGES = {
    "brain": ("brain.jpg", (256, 256)),
    "calf": ("calf.png", (512, 512)),
    "hand": ("hand.png", (512, 512)),
}


def load_medical_image(public_dir, name, use_cartoons=False):
    """Load the chosen source as a 2-D float image with the lab's fixed shape.

    Cartoon files are illustrations, not anonymized or modified patient scans.
    Convert them to grayscale before any FFT, reconstruction, or grading.
    Original images follow the original loading path without resampling.
    """
    original, shape = _IMAGES[name]
    filename = f"{name}_cartoon.png" if use_cartoons else original
    image = img_as_float(imread(Path(public_dir) / filename, as_gray=True))
    if use_cartoons:
        image = resize(image, shape, anti_aliasing=True, preserve_range=True)
        image = np.clip(image, 0.0, 1.0)
    if image.shape != shape:
        raise ValueError(f"{filename}: expected {shape}, got {image.shape}")
    return image

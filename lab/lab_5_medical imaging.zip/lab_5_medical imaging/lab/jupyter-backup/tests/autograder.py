"""Autograder for Lab 5: Introduction to Medical Imaging.

Each test_QX function is called from the notebook cell right after the
student function it checks. A test raises an AssertionError with a hint
when something is wrong, and prints "Question X Passed!" otherwise.
"""
from pathlib import Path
import sys

import numpy as np


_BASE_DIR = Path(__file__).resolve().parent

# tests/ lives next to utils/, so put the lab folder on the path too.
for _p in (_BASE_DIR, _BASE_DIR.parent):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from utils.wavelets import haar2_forward, haar2_inverse  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fill_hint(name, value):
    if value is None:
        return (
            f"{name} is None. Did you forget a `return` statement, or to "
            "assign the variable?"
        )
    if value is Ellipsis:
        return f"{name} is still `...`. Replace the `...` placeholder with your code."
    return None


def _array(value, name):
    """Convert a student value to a numeric NumPy array, or fail with a hint."""
    hint = _fill_hint(name, value)
    assert hint is None, hint
    try:
        arr = np.asarray(value)
    except Exception:
        arr = None
    assert arr is not None and arr.dtype.kind in "biufc", (
        f"{name} should be a NumPy array of numbers, but it is a "
        f"{type(value).__name__}."
    )
    return arr


def _shape(arr, shape, name):
    assert arr.shape == tuple(shape), (
        f"{name} has shape {arr.shape}, but it should have shape {tuple(shape)}."
    )


def _short(value):
    if isinstance(value, np.ndarray):
        return f"<{'x'.join(map(str, value.shape))} array>"
    return repr(value)


def _call(func, name, *args, **kwargs):
    """Call a student function, turning any crash into a readable message."""
    hint = _fill_hint(name, func)
    assert hint is None, hint
    assert callable(func), (
        f"{name} should be a function, but it is a {type(func).__name__}."
    )
    shown = ", ".join(
        [_short(a) for a in args] + [f"{k}={_short(v)}" for k, v in kwargs.items()]
    )
    try:
        return func(*args, **kwargs)
    except Exception as error:
        raise AssertionError(
            f"{name}({shown}) raised {type(error).__name__}: {error}"
        ) from error


def _mask(value, name, shape):
    """Check that a mask has the right shape and only True/False (or 1/0)."""
    arr = _array(value, name)
    _shape(arr, shape, name)
    if arr.dtype != bool:
        assert np.all((arr == 0) | (arr == 1)), (
            f"{name} should only contain True/False (or 1/0) values."
        )
        arr = arr != 0
    return arr


def _close(actual, expected):
    actual, expected = np.asarray(actual), np.asarray(expected)
    if actual.shape != expected.shape:
        return False
    if actual.dtype == bool or expected.dtype == bool:
        return np.array_equal(actual, expected)
    return np.allclose(actual, expected)


def _match(actual, expected, hint, wrong_versions=()):
    """Pass if actual matches expected. Otherwise, look for a known mistake
    among wrong_versions [(wrong_value, hint), ...] to explain the failure."""
    if _close(actual, expected):
        return
    for wrong, wrong_hint in wrong_versions:
        if _close(actual, wrong):
            raise AssertionError(wrong_hint)
    raise AssertionError(hint)


def _lines(mask):
    """If the mask is made of full columns (or full rows), return
    ("columns", sampled) (or ("rows", sampled)); otherwise (None, None)."""
    if np.all(mask == mask[:1, :]):
        return "columns", mask[0, :]
    if np.all(mask == mask[:, :1]):
        return "rows", mask[:, 0]
    return None, None


def _ref_radial_mask(shape, radius, center, inclusive=False, squared=False):
    yy, xx = np.indices(shape)
    r2 = (yy - center[0]) ** 2 + (xx - center[1]) ** 2
    r = r2 if squared else np.sqrt(r2)
    return r <= radius if inclusive else r < radius


# ---------------------------------------------------------------------------
# Section 1: 2-D Fourier Transforms
# ---------------------------------------------------------------------------

def test_Q1a(make_radial_mask):
    for shape, radius in (((512, 512), 20), ((64, 64), 10), ((40, 70), 9), ((33, 33), 5)):
        label = f"make_radial_mask({shape}, {radius})"
        actual = _mask(_call(make_radial_mask, "make_radial_mask", shape, radius), label, shape)
        h, w = shape

        # Either h/2 or h//2 is a fine center; < and <= are both fine.
        accepted = [
            _ref_radial_mask(shape, radius, center, inclusive)
            for center in ((h / 2, w / 2), (h // 2, w // 2))
            for inclusive in (False, True)
        ]
        if any(np.array_equal(actual, a) for a in accepted):
            continue

        expected = accepted[0]
        n_bad = int(np.count_nonzero(actual != expected))
        _match(
            actual, expected,
            f"{label} is incorrect: {n_bad} of {expected.size} pixels differ. "
            f"Expected about pi * radius**2 = {np.pi * radius ** 2:.0f} True "
            f"pixels, but your mask has {int(actual.sum())}. The mask should be "
            "True where the distance from (h/2, w/2) is less than radius.",
            [
                (~expected,
                 f"{label} is inverted. It should be True inside the circle (the "
                 "low frequencies) and False outside."),
                (_ref_radial_mask(shape, radius, ((h - 1) / 2, (w - 1) / 2)),
                 "Center the circle at (h/2, w/2): that is where the zero "
                 "frequency sits after np.fft.fftshift."),
                (_ref_radial_mask(shape, radius, (h / 2, w / 2), squared=True),
                 "Your mask compares the *squared* distance to radius. Take the "
                 "square root (np.sqrt) to get the distance r."),
                (_ref_radial_mask(shape, radius, (w / 2, h / 2)),
                 "The center coordinates are swapped. shape is (rows, columns) = "
                 "(h, w), so the row index yy goes with h and xx goes with w."),
            ],
        )

    print("Question 1a Passed!")


def test_Q1b(make_sampling_mask_rows):
    for shape, step in (((512, 512), 2), ((512, 512), 4), ((64, 48), 3), ((10, 7), 1)):
        label = f"make_sampling_mask_rows({shape}, {step})"
        actual = _mask(
            _call(make_sampling_mask_rows, "make_sampling_mask_rows", shape, step),
            label, shape,
        )
        expected = np.zeros(shape, dtype=bool)
        expected[::step, :] = True
        if np.array_equal(actual, expected):
            continue

        # With step 2 the inverted mask is just a different offset, which is fine.
        assert not (step > 2 and np.array_equal(actual, ~expected)), (
            f"{label} zeroes every sample-th row and keeps the rest. It should "
            "do the opposite: keep every sample-th row and zero the rest."
        )
        kind, _ = _lines(actual)
        assert kind is not None, (
            f"{label} should keep entire rows (mask[row, :] = True), but some "
            "rows are only partly True."
        )
        expected_cols = np.zeros(shape, dtype=bool)
        expected_cols[:, ::step] = True
        assert not np.array_equal(actual, expected_cols), (
            f"{label} keeps columns. It should keep rows: index the first axis, "
            "as in mask[::sample, :]."
        )
        kept = np.flatnonzero(actual.all(axis=1))
        # Starting at a different offset gives the same aliasing, so allow it.
        offset_ok = (
            kept.size > 0 and kept[0] < step
            and np.array_equal(kept, np.arange(kept[0], shape[0], step))
            and not actual[~actual.all(axis=1)].any()
        )
        assert offset_ok, (
            f"{label} is incorrect. It should be True on rows 0, sample, "
            f"2*sample, ... and False elsewhere. Your mask keeps {kept.size} "
            f"full rows; expected {int(expected[:, 0].sum())}."
        )

    print("Question 1b Passed!")


def test_Q1c(truncate_fov_rows):
    rng = np.random.default_rng(66)
    cases = (
        (rng.random((512, 512)) + 0.1, 2),
        (rng.random((512, 512)) + 0.1, 4),
        (rng.random((101, 60)) + 0.1, 3),
        (rng.random((64, 64)) + 0.1, 1),
    )
    for img, step in cases:
        n = img.shape[0]
        original = img.copy()
        label = f"truncate_fov_rows(<{n}x{img.shape[1]} image>, {step})"
        out = _array(_call(truncate_fov_rows, "truncate_fov_rows", img, step), label)
        assert np.array_equal(img, original), (
            f"{label} modified its input image. Build a new array (for example "
            "with np.zeros_like(img)) instead of zeroing rows of img in place."
        )
        _shape(out, img.shape, label)

        zero_cols = np.all(out == 0, axis=0)
        assert not (zero_cols.any() and not zero_cols.all()), (
            f"{label} zeroes whole columns. Truncate rows (the first axis) and "
            "keep every column."
        )
        kept = np.flatnonzero(np.any(out != 0, axis=1))
        keep = n // step
        start = (n - keep) // 2
        outer = np.setdiff1d(np.arange(n), np.arange(start, start + keep))
        assert not (step > 1 and np.array_equal(kept, outer)), (
            f"{label} keeps the outer rows. It should keep the *middle* "
            f"{keep} rows and zero the top and bottom."
        )
        assert kept.size in (keep, -(-n // step)), (
            f"{label} keeps {kept.size} rows, but it should keep the middle "
            f"n // sample = {keep} rows."
        )
        assert np.array_equal(kept, np.arange(kept[0], kept[0] + kept.size)), (
            f"{label}: the kept rows should form one contiguous band in the middle."
        )
        assert abs((kept[0] + kept[-1]) / 2 - (n - 1) / 2) <= 1, (
            f"{label} keeps rows {kept[0]} to {kept[-1]}, which is not centered. "
            f"Start the band at (n - n // sample) // 2 = {start}."
        )
        assert np.array_equal(out[kept], img[kept]), (
            f"{label}: the kept rows should be copied unchanged from img."
        )

    print("Question 1c Passed!")


# ---------------------------------------------------------------------------
# Section 3: Compressed Sensing: Filling in the Blanks
# ---------------------------------------------------------------------------

def test_Q3a(make_A_and_AH):
    rng = np.random.default_rng(66)
    for shape, level in (((32, 32), 3), ((64, 32), 2), ((16, 16), 1)):
        mask = rng.random(shape) < 0.4
        ops = _call(make_A_and_AH, "make_A_and_AH", shape, mask, level=level)
        hint = _fill_hint("make_A_and_AH(...)", ops)
        assert hint is None, hint
        assert isinstance(ops, tuple) and len(ops) == 2, (
            "make_A_and_AH should return the pair (A, AH)."
        )
        A, AH = ops

        x = rng.standard_normal(shape) + 1j * rng.standard_normal(shape)
        y = rng.standard_normal(shape) + 1j * rng.standard_normal(shape)
        shifted = np.fft.ifftshift(mask)
        img = haar2_inverse(x, level=level)
        where = f"(shape={shape}, level={level})"

        actual_A = _array(_call(A, "A", x), f"A(x) {where}")
        _shape(actual_A, shape, f"A(x) {where}")
        _match(
            actual_A, shifted * np.fft.fft2(img, norm="ortho"),
            f"A(x) {where} is incorrect. It should compute "
            "np.fft.ifftshift(mask) * np.fft.fft2(haar2_inverse(x, level=level), "
            "norm='ortho').",
            [
                (mask * np.fft.fft2(img, norm="ortho"),
                 "A(x) multiplies by `mask`, which is drawn in centered "
                 "coordinates. Use `shifted_mask` (defined for you just above A): "
                 "it lines up with the un-centered output of np.fft.fft2."),
                (shifted * np.fft.fft2(haar2_forward(x, level=level), norm="ortho"),
                 "A(x) uses haar2_forward, which goes image -> wavelet. x is "
                 "already wavelet coefficients, so you need the opposite: "
                 "haar2_inverse(x, level=level)."),
                (shifted * np.fft.ifft2(img, norm="ortho"),
                 "A(x) uses the inverse FFT. F takes the image TO k-space, so use "
                 "np.fft.fft2 (AH is the one that uses ifft2)."),
                (shifted * haar2_inverse(np.fft.fft2(x, norm="ortho"), level=level),
                 "A(x) applies the operators in the wrong order. A = M F W^-1 acts "
                 "right to left: first haar2_inverse, THEN np.fft.fft2, then the mask."),
                (shifted * np.fft.fft2(haar2_inverse(x, level=3), norm="ortho"),
                 "A(x) hard-codes level=3. Pass the function's `level` argument "
                 "instead: haar2_inverse(x, level=level)."),
                (np.fft.fft2(img, norm="ortho"),
                 "A(x) never applies the sampling mask. Multiply the k-space by "
                 "shifted_mask."),
                (shifted * np.fft.fft2(img),
                 "Keep norm='ortho' in np.fft.fft2 so that the adjoint of the "
                 "FFT is exactly the inverse FFT."),
                (shifted * np.fft.fft2(x, norm="ortho"),
                 "x lives in the wavelet domain. Convert it to an image with "
                 "haar2_inverse(x, level=level) before the FFT (A = M F W^-1)."),
            ],
        )

        img_y = np.fft.ifft2(shifted * y, norm="ortho")
        actual_AH = _array(_call(AH, "AH", y), f"AH(y) {where}")
        _shape(actual_AH, shape, f"AH(y) {where}")
        _match(
            actual_AH, haar2_forward(img_y, level=level),
            f"AH(y) {where} is incorrect. It should compute "
            "haar2_forward(np.fft.ifft2(shifted_mask * y, norm='ortho'), level=level).",
            [
                (haar2_forward(np.fft.ifft2(mask * y, norm="ortho"), level=level),
                 "AH(y) applies the unshifted mask. Use the same shifted_mask "
                 "as in A."),
            ],
        )

    print("Question 3a Passed!")


def test_Q3b(b, x, recon, babak_img, cs_mask):
    """Section 3: setting up and solving the BPD problem for Babak."""
    img = np.asarray(babak_img, dtype=float)
    mask = _mask(cs_mask, "cs_mask", img.shape)
    ksp_c = np.fft.fftshift(np.fft.fft2(img, norm="ortho"))
    expected_b = np.fft.ifftshift(ksp_c * mask)

    b_arr = _array(b, "b")
    _shape(b_arr, img.shape, "b")
    _match(
        b_arr, expected_b,
        "b is incorrect. It should be the measured samples with the centering "
        "undone: b = np.fft.ifftshift(cs_ksp_masked).",
        [
            (ksp_c * mask,
             "b is still centered. make_A_and_AH works with the unshifted layout "
             "of np.fft.fft2, so undo the shift: b = np.fft.ifftshift(cs_ksp_masked)."),
            (np.fft.ifftshift(ksp_c),
             "b contains ALL of k-space. It should only hold the samples you "
             "measured: start from cs_ksp_masked, not cs_ksp."),
            (np.fft.ifftshift(np.fft.fftshift(np.fft.fft2(img)) * mask),
             "b was computed without norm='ortho'. Use cs_ksp_masked, which "
             "already has the right normalization."),
        ],
    )

    x_arr = _array(x, "x")
    _shape(x_arr, img.shape, "x")

    rec = _array(recon, "recon")
    _shape(rec, img.shape, "recon")
    assert not np.iscomplexobj(rec), (
        "recon is complex. Take the magnitude with np.abs so it is a real image."
    )
    _match(
        rec, np.abs(haar2_inverse(x_arr, level=3)),
        "recon should be the image that x represents: "
        "np.abs(haar2_inverse(x, level=3)).",
        [
            (np.abs(x_arr),
             "recon is still wavelet coefficients. bpd returns x in the wavelet "
             "domain, so turn it back into an image first: "
             "np.abs(haar2_inverse(x, level=3))."),
            (np.real(haar2_inverse(x_arr, level=3)),
             "Use the magnitude (np.abs), not the real part."),
            (np.abs(haar2_forward(x_arr, level=3)),
             "haar2_forward goes from an image TO wavelet coefficients. You need "
             "the opposite direction: haar2_inverse."),
            (np.abs(haar2_inverse(x_arr, level=1)),
             "Use level=3, to match the level used inside make_A_and_AH."),
        ],
    )

    err_bpd = np.linalg.norm(rec - img) / np.linalg.norm(img)
    err_zero = np.linalg.norm(np.abs(np.fft.ifft2(expected_b, norm="ortho")) - img) / np.linalg.norm(img)
    assert err_bpd < err_zero, (
        f"Your BPD reconstruction (NRMSE {err_bpd:.3f}) is no better than "
        f"zero-filling (NRMSE {err_zero:.3f}), so x is probably not the BPD "
        "solution for this mask. Check that A, AH come from "
        "make_A_and_AH(babak_img.shape, cs_mask) and that "
        "x = bpd(b, A, AH, babak_img.shape)."
    )

    print("Question 3b Passed!")


# ---------------------------------------------------------------------------
# Section 5: A Design Challenge, Revisited
# ---------------------------------------------------------------------------

def test_Q5(final_mask, recon_bpd_final, brain_img, fsr_radius=40):
    """Section 5: the FSR + spiral mask and its BPD reconstruction."""
    brain = np.asarray(brain_img, dtype=float)
    mask = _array(final_mask, "final_mask")
    _shape(mask, brain.shape, "final_mask")
    assert mask.dtype == bool, (
        f"final_mask should be a boolean (True/False) array, but its dtype is "
        f"{mask.dtype}. Combine boolean masks with `|`."
    )

    assert mask.mean() > 0.03, (
        f"final_mask samples only {100 * mask.mean():.1f}% of k-space. If you "
        "combined the disk and the spiral with & (AND), only pixels in BOTH "
        "masks survive. Use | (OR), so a pixel is sampled if EITHER mask "
        "samples it."
    )

    h, w = mask.shape
    yy, xx = np.indices(mask.shape)
    disk = np.hypot(yy - h / 2, xx - w / 2) < fsr_radius - 1
    assert mask[disk].all(), (
        f"final_mask should fully sample a disk of radius {fsr_radius} around "
        "the center of k-space (the FSR). Did you include "
        "make_radial_mask(brain_img.shape, fsr_radius) in final_mask?"
    )
    outer = np.hypot(yy - h / 2, xx - w / 2) > 2 * fsr_radius
    assert mask[outer].mean() > 0.05, (
        "final_mask has almost no samples outside the FSR. Add the spiral "
        "(make_spiral_trajectory_mask) to cover the high frequencies."
    )
    coverage = mask.mean()
    assert 0.15 <= coverage <= 0.35, (
        f"final_mask covers {100 * coverage:.1f}% of k-space, but the budget "
        "is about 25%. Check the parameters you passed to the two mask functions."
    )

    recon = _array(recon_bpd_final, "recon_bpd_final")
    _shape(recon, brain.shape, "recon_bpd_final")
    assert not np.iscomplexobj(recon), (
        "recon_bpd_final is complex. Take the magnitude (np.abs) of the image."
    )
    err = np.linalg.norm(recon - brain) / np.linalg.norm(brain)
    assert err < 0.16, (
        f"recon_bpd_final has NRMSE {err:.3f} against the brain image, but a "
        "correct BPD reconstruction with this mask gets about 0.13. Check that "
        "b is the masked k-space with the shift undone, that the FFTs use "
        "norm=\"ortho\", and that you turned x back into an image with "
        "haar2_inverse(x, level=3)."
    )

    print("Question 5 Passed!")


# ---------------------------------------------------------------------------
# Section 6: From attenuation to line integrals
# ---------------------------------------------------------------------------

def test_Q6(intensities_to_line_integrals):
    """Section 6: Beer-Lambert, from detector intensities to line integrals."""
    rng = np.random.default_rng(66)
    cases = (
        (np.array([1000.0, 500.0, 250.0, 37.0]), 1000.0),
        (rng.uniform(0.05, 1.0, (20, 30)) * 1e4, 1e4),
        (np.array([[2.0, 0.5]]), 2.0),
    )
    for I, I0 in cases:
        original = I.copy()
        label = f"intensities_to_line_integrals(<{'x'.join(map(str, I.shape))} array>, I0={I0:g})"
        out = _array(_call(intensities_to_line_integrals, "intensities_to_line_integrals", I, I0), label)
        assert np.array_equal(I, original), (
            f"{label} modified its input I. Compute a new array instead of "
            "changing I in place."
        )
        _shape(out, I.shape, label)
        _match(
            out, -np.log(I / I0),
            f"{label} is incorrect. Solve I = I0 * exp(-p) for the line integral "
            "p: divide by I0, take the natural log, and flip the sign.",
            [
                (np.log(I / I0),
                 "The sign is flipped. Since I <= I0, ln(I / I0) is negative, but "
                 "attenuation along a line is positive: put a minus sign in front."),
                (-np.log(I),
                 "Divide by I0 first. The line integral depends on the FRACTION "
                 "of the beam that got through, I / I0."),
                (-np.log10(I / I0),
                 "Use the natural log, np.log. np.log10 is base 10, but "
                 "Beer-Lambert uses e."),
                (1 - I / I0,
                 "Take a logarithm. The attenuation sits in the exponent, and the "
                 "log is what brings it back down."),
                (I0 / I,
                 "Take a logarithm. The attenuation sits in the exponent, and the "
                 "log is what brings it back down."),
            ],
        )

    print("Question 6 Passed!")


def test_Q3_model(mri_forward, mri_zero_fill):
    """Check complex MRI measurements, layout, and measurement consistency."""
    rng = np.random.default_rng(663)
    for shape in ((5, 7), (8, 6)):
        img = rng.normal(size=shape) + 1j * rng.normal(size=shape)
        for mask in (np.ones(shape, bool), np.zeros(shape, bool), rng.random(shape) < 0.45):
            original, original_mask = img.copy(), mask.copy()
            measured = _array(_call(mri_forward, "mri_forward", img, mask), "mri_forward output")
            _shape(measured, shape, "mri_forward output")
            expected = np.fft.ifftshift(mask) * np.fft.fft2(img, norm="ortho")
            _match(measured, expected,
                   "Check the FFT direction, norm='ortho', and alignment of the centered mask. "
                   "Keep complex coefficients; abs or real changes the measurements.")
            assert np.array_equal(img, original) and np.array_equal(mask, original_mask), (
                "mri_forward must not modify img or mask in place."
            )
            before = measured.copy()
            estimate = _array(_call(mri_zero_fill, "mri_zero_fill", measured), "mri_zero_fill output")
            _shape(estimate, shape, "mri_zero_fill output")
            _match(estimate, np.fft.ifft2(expected, norm="ortho"),
                   "y is already uncentered. Use the inverse transform with matching normalization "
                   "and return its complex result; take magnitudes only for display.")
            assert np.array_equal(measured, before), "mri_zero_fill must not modify y."
            again = _array(_call(mri_forward, "mri_forward", estimate, mask), "remeasured image")
            assert np.allclose(again, measured), "Zero-fill should preserve the acquired samples."
            if mask.all():
                assert np.allclose(estimate, img), "Full sampling should recover the complex input image."

        second = rng.normal(size=shape) + 1j * rng.normal(size=shape)
        alpha, beta = 0.7 + 0.2j, -0.4
        lhs = _call(mri_forward, "mri_forward", alpha * img + beta * second, mask)
        rhs = alpha * _call(mri_forward, "mri_forward", img, mask) + beta * _call(mri_forward, "mri_forward", second, mask)
        assert np.allclose(lhs, rhs), "For a fixed mask, mri_forward must preserve linear combinations."
    print("Question 3.0 Passed!")


def test_Q6b(build_ct_matrix, ct_forward):
    """Compare the constructed matrix against the projector on unseen images."""
    from skimage.transform import radon

    rng = np.random.default_rng(666)
    for shape, angles in (((3, 4), np.array([0., 37., 90.])),
                          ((4, 4), np.array([12., 64., 121., 157.]))):
        original_angles = angles.copy()
        matrix = _array(_call(build_ct_matrix, "build_ct_matrix", shape, angles), "CT matrix")
        sino_shape = radon(np.zeros(shape), theta=angles, circle=False, preserve_range=True).shape
        _shape(matrix, (int(np.prod(sino_shape)), int(np.prod(shape))), "CT matrix")
        assert np.array_equal(angles, original_angles), "Do not modify the input angles."
        for j in (0, int(np.prod(shape)) // 2, int(np.prod(shape)) - 1):
            basis = np.zeros(shape)
            basis.flat[j] = 1
            expected = radon(basis, theta=angles, circle=False, preserve_range=True).ravel()
            _match(matrix[:, j], expected,
                   f"Column {j} should contain all measurements of pixel {j} alone. "
                   "Reset the basis image each time, flatten row by row, and store a column, not a row.")
        for img in (rng.random(shape), rng.normal(size=shape)):
            before_matrix, before_img = matrix.copy(), img.copy()
            measured = _array(_call(ct_forward, "ct_forward", matrix, img), "ct_forward output")
            _shape(measured, (int(np.prod(sino_shape)),), "ct_forward output")
            expected = radon(img, theta=angles, circle=False, preserve_range=True).ravel()
            _match(measured, expected,
                   "Matrix prediction must agree with the supplied projector. Use @ and row-by-row "
                   "flattening; do not transpose the matrix or take a magnitude.")
            assert np.array_equal(matrix, before_matrix) and np.array_equal(img, before_img), (
                "ct_forward must not modify its inputs."
            )
    # A tiny independent weighted-sum example also prevents bypassing the input matrix.
    matrix = np.array([[1., 2., 0., 0.], [0., 0., 3., 1.]])
    img = np.array([[1., 2.], [3., 4.]])
    measured = _array(_call(ct_forward, "ct_forward", matrix, img), "ct_forward output")
    _shape(measured, (2,), "ct_forward output")
    _match(measured, np.array([5., 13.]), "Use the supplied matrix's weights to sum the image pixels.")
    print("Question 6b Passed!")


def test_Q7a(ct_backproject):
    """Check weighted accumulation, shape, and the transpose identity."""
    matrix = np.array([[1., 2., 0., 0.], [0., 0., 3., 1.]])
    y = np.array([2., -1.])
    actual = _array(_call(ct_backproject, "ct_backproject", matrix, y, (2, 2)), "backprojection")
    _shape(actual, (2, 2), "backprojection")
    _match(actual, np.array([[2., 4.], [-3., -1.]]),
           "Backprojection sums each measurement into pixels using the same weights. "
           "Use the transpose, then reshape; keep signs and do not normalize or clip.")
    rng = np.random.default_rng(667)
    for shape, measurements in (((3, 4), 7), ((2, 3), 9)):
        matrix = rng.normal(size=(measurements, int(np.prod(shape))))
        y = rng.normal(size=measurements)
        original_matrix, original_y = matrix.copy(), y.copy()
        actual = _array(_call(ct_backproject, "ct_backproject", matrix, y, shape), "backprojection")
        _shape(actual, shape, "backprojection")
        expected = np.sum(matrix * y[:, None], axis=0).reshape(shape)
        _match(actual, expected, "Check the transpose and the row-by-row reshape. Return the weighted sum unchanged.")
        x = rng.normal(size=shape)
        assert np.allclose(np.dot(matrix @ x.ravel(), y), np.sum(x * actual)), (
            "The forward and backprojection operations should satisfy <Ax, y> = <x, A^T y>."
        )
        assert np.array_equal(matrix, original_matrix) and np.array_equal(y, original_y), (
            "ct_backproject must not modify its inputs."
        )
    print("Question 7a Passed!")

"""Local autograder package for EE 66 Lab 5."""

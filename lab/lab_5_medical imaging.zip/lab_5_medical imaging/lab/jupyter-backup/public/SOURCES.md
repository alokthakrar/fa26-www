# Asset Sources

- `phantom.png`: generated from the Shepp-Logan phantom distributed through scikit-image. Used throughout Part 2 (CT).
- `modality_comparison.png`: generated specifically for this lab draft.
- All k-space, mask, sinogram, projection, and reconstruction figures produced by running the notebook's own code cells are generated specifically for this lab draft.
- No EECS 120 images, data, code, tests, or text are included.

## MRI images used in Part 1

- `BabakAyazifar.png`, `calf.png`, `hand.png`: added by Ryan Black for the Fall 2026 MRI/compressed-sensing rewrite. Per the notebook's own attribution line, MRI data used in this lab are drawn from http://mridata.org/about. **TODO before deployment:** confirm with Ryan Black the exact per-image provenance/license for these three files (which mridata.org series each came from, and any additional processing) so this file can cite them individually rather than as a group.
- `brain.jpg`: from the Kaggle "Brain Tumor MRI Dataset" (M. Nickparvar), https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset/data, per the notebook's own attribution line. **TODO before deployment:** confirm the dataset's license terms permit redistribution in course materials.
- `center_out_cartesian.gif`, `top_to_bottom_cartesian.gif`, `center_out_circular_radial.gif`, `extremities_to_center_radial.gif`, `random_ordering.gif`, `spoke_by_spoke_circular_radial.gif`, `wrist.jpg`: provided by Ryan Black to illustrate k-space fill order and piece-by-piece reconstruction in Part 1, Section 5. **TODO before deployment:** confirm original source/license and redistribution permission with Ryan Black.

## Photos used to introduce k-space (Section 1)

- `zebra.png`: grayscale crop of "Zebra Botswana edit02.jpg" (two zebras, 350 x 350 crop resized to 256 x 256) by Paul Maritz, Wikimedia Commons, CC BY 2.5 (https://commons.wikimedia.org/wiki/File:Zebra_Botswana_edit02.jpg).
- `trees.png`: grayscale, cropped and resized to 512 x 512 from "Aspen Trunks - Eldorado National Forest (4009039919).jpg," U.S. Forest Service, Wikimedia Commons, public domain (https://commons.wikimedia.org/wiki/File:Aspen_Trunks_-_Eldorado_National_Forest_(4009039919).jpg).

## External Clinical Reference Images Embedded By URL

*(loaded live from Wikimedia Commons in the "What is MRI and CT?" cell -- not stored locally; requires internet access in the room)*

- MRI scanner: MeunierAurelia, "IRM 3T clinique NeuroSpin.jpg," Wikimedia Commons, CC BY-SA 4.0.
- CT scanner: Goleisureintl, "Computed Tomography (CT) Scan Facility in Navi Mumbai.jpg," Wikimedia Commons, CC BY 4.0.

## Course reference image

- `lti_scotty.png`: supplied with this lab revision as `Babak-Captain-Kirk-Star-Trek-LTI-Systems-Read-My-Lips-No-New-Frequencies.png`; the original is retained in `old/reference_assets/` at the workspace root.


### Optional cartoon sources

`brain_cartoon.png`, `calf_cartoon.png`, and `hand_cartoon.png` were generated with the built-in image_gen tool for this lab. The original scans supplied silhouette/composition references only. They depict an illustrated brain, a sock-covered calf, and a glove, with no pathology or internal scan detail. The loader converts them to grayscale and matches the original image dimensions. These are teaching illustrations, not clinical data. Full generation prompts are recorded in `cartoon_prompts.json`.

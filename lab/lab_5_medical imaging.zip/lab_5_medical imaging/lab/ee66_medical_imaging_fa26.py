import marimo

__generated_with = "0.24.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Lab 5: Introduction to Medical Imaging
    ### EE 66: Introduction to Signals, Dynamics, and Information

    **Acknowledgement:** Fall 2026 - Baris Oktay, Ryan Black, Kerry Pan, Theo de La Cruz, Amin Mobedi, Mihir Sharma.

    *Most MRI data used in this lab are from [mridata.org](http://mridata.org/about) and the [Kaggle brain tumor MRI dataset](https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset/data).*

    Medical imaging lets us see inside the human body without surgery. The signal model varies across modalities, and turning measurements into a useful image takes some engineering. In this lab, we focus on **two common medical imaging modalities** to answer one unifying question:

    > **How does an engineer design measurement schemes under the constraints imposed by the imaging modality?** Such constraints include limited time and computation and safety restrictions (i.e. radiation exposure).

    <span style="color:red">**Heads up: this lab is longer than previous labs.** If you get stuck, check the hints first, and ask for help early instead of spending a long time on one part.</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    cartoon_images = mo.ui.switch(value=False, label="Use cartoon images")
    mo.vstack([
        mo.md(r"""
        **A note about the images:** this lab includes MRI scans of a brain (including a tumor), a calf, and a hand. If you are comfortable viewing them, leave the switch off and continue. If you would prefer illustrations, turn on **Use cartoon images** before scrolling down.
        
        The cartoons are shown in **black and white** and replace the source images throughout the exercises. The same code and grading work in either mode; image details and numerical results will differ. The cartoons are teaching illustrations, not clinical images. Choose a mode before starting your work.
        """),
        cartoon_images,
    ])
    return (cartoon_images,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Table of Contents

    **Part 1: MRI**

    * [0. Recap of 1-D Signals](#sec0)
    * [1. 2-D Fourier Transforms](#sec1)
    * [2. A Design Challenge](#sec2)
    * [3. Compressed Sensing: Filling in the Blanks](#sec3)
    * [4. Non-Cartesian Sampling and Motion Artifacts](#sec4)
    * [5. A Design Challenge, Revisited](#sec5)

    **Part 2: CT**

    * [Bridging MRI and CT](#bridge)
    * [6. From attenuation to line integrals](#sec6)
    * [7. Reconstructing the image: backprojection and filtered backprojection](#sec7)
    * [8. Radiation dose and the measurement budget](#sec8)
    * [9. MRI and CT side by side](#sec9)

    **[Checkoff](#checkoff)**
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Learning objectives
    By the end of this lab, you should be able to:

    1. read k-space: what low and high frequencies encode, and how the extent and spacing of samples set resolution and field of view;
    2. design MRI sampling patterns and reconstruct them with zero-fill and with compressed sensing (BPD);
    3. explain how CT turns X-ray measurements into a sinogram, and how filtered backprojection turns it back into an image;
    4. build MRI and CT measurement operators and distinguish measurement agreement from image accuracy;
    5. recommend and defend a measurement budget for MRI and CT.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## What is MRI and CT?

    At a high level of abstraction, all imaging modalities are going to transmit energy _into_ the patient and then receive energy _from_ the patient. Figuring out the right way to deposit and detect this energy is a tough interdisciplinary engineering challenge regardless of the imaging modality. In this lab, we'll describe briefly, for two common types of medical imaging, the types of measurements made and how they are used to make an image.

    The table below has pictures of each machine and a brief description of their functionality. Even though they look similar, the physics and signal processing that each uses to make an image are _completely different_.

    <table>
    <tr>
    <td width="50%">
    <img src="https://upload.wikimedia.org/wikipedia/commons/5/59/IRM_3T_clinique_NeuroSpin.jpg" width="100%">
    <br>
    <b>MRI scanner.</b> MRI uses a strong uniform magnetic field and radio-frequency excitation fields to make the hydrogen nuclei in your body (think, water) spin. Then, non-uniform gradient fields give the spins' precession frequency a spatial dependence. The received signal depends on this resonant frequency; we use that spatial dependence to reconstruct an image. Note that MRI does not use ionizing radiation (X-rays), and the signal ultimately comes from the precessing nuclei themselves.
    </td>
    <td width="50%">
    <img src="https://upload.wikimedia.org/wikipedia/commons/9/9c/Computed_Tomography_%28CT%29_Scan_Facility_in_Navi_Mumbai.jpg" width="100%">
    <br>
    <b>CT scanner.</b> CT uses a rotating X-ray emitter and an opposing detector to measure how much an X-ray is attenuated as it passes through the patient. Each measurement has one degree of freedom (attenuation per ray) but encodes information from two dimensions (the attenuation coefficient at position (x, y)). Intuitively, collecting projections from many angles in some sense "makes up" for that second degree of freedom and gives enough information to reconstruct an image. The algorithm that synthesizes these is called filtered backprojection. Unlike MRI, CT does use ionizing radiation and the signal does not come from within the patient.
    </td>
    </tr>
    </table>

    *Image credits: "IRM 3T clinique NeuroSpin.jpg," MeunierAurelia, CC BY-SA 4.0; "Computed Tomography (CT) Scan Facility in Navi Mumbai.jpg," Goleisureintl, CC BY 4.0, via Wikimedia Commons.*

    MRI and CT scanners produce similar anatomical images, but neither one records the image pixel by pixel. MRI measures **spatial frequencies**, and CT measures how much X-rays are weakened along straight lines through the body. Parts 1 and 2 of this lab go through each one in more detail.

    ![Two measurement domains](public/modality_comparison.png)

    In both cases, our goal is to turn these measurements into a useful image.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <span style = "color:red">
    The hidden cells below load the imports and images for this lab. If something later fails with a NameError, make sure these cells have run. </span>

    **Working in this notebook:** complete the cells marked `TODO`, delete the marked `raise NotImplementedError()` line, and run the nearby test button. Cells that depend on unfinished code will show errors until you fill it in; this is expected. Put written responses in the answer boxes. Plots update automatically when their inputs change.
    """)
    return


@app.cell(hide_code=True)
def _():
    import numpy as np
    import matplotlib.pyplot as plt
    from skimage.io import imread
    from skimage.util import img_as_float
    from skimage.metrics import structural_similarity as ssim
    from skimage.transform import radon, iradon

    from utils.imaging import backproject, filtered_backproject, gallery, make_sinogram, nrmse
    from utils.wavelets import haar2_forward, haar2_inverse, bpd
    from tests.autograder import (
        test_Q1a,
        test_Q1b,
        test_Q1c,
        test_Q3a,
        test_Q3b,
        test_Q5,
        test_Q6,
        test_Q6b,
    )

    plt.rcParams.update({'figure.figsize': (8, 4), 'font.size': 11})
    return (
        backproject,
        bpd,
        filtered_backproject,
        gallery,
        haar2_forward,
        haar2_inverse,
        img_as_float,
        imread,
        iradon,
        make_sinogram,
        np,
        nrmse,
        plt,
        radon,
        ssim,
        test_Q1a,
        test_Q1b,
        test_Q1c,
        test_Q3a,
        test_Q3b,
        test_Q5,
        test_Q6,
        test_Q6b,
    )


@app.cell(hide_code=True)
def _(cartoon_images, img_as_float, imread, mo):
    from utils.image_sources import load_medical_image
    # Shared images used throughout the lab.
    _public = mo.notebook_dir() / "public"
    babak_img = img_as_float(imread(_public / 'BabakAyazifar.png', as_gray=True))
    zebra_img = img_as_float(imread(_public / 'zebra.png', as_gray=True))
    trees_img = img_as_float(imread(_public / 'trees.png', as_gray=True))
    calf_img = load_medical_image(_public, "calf", cartoon_images.value)
    hand_img = load_medical_image(_public, "hand", cartoon_images.value)
    brain_img = load_medical_image(_public, "brain", cartoon_images.value)
    phantom = imread(_public / 'phantom.png', as_gray=True)
    phantom = phantom / phantom.max()
    return (
        babak_img,
        brain_img,
        calf_img,
        hand_img,
        phantom,
        trees_img,
        zebra_img,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Part 1. MRI.

    MRI stands for...

    ___Magnetic___, referring to the fact that we are depositing and receiving energy by changing magnetic fields.

    ___Resonance___, referring to the fact that the nuclear spins inside the body like to precess at a certain "resonant" frequency.

    ___Imaging___, referring to the fact that we are reconstructing images of the body.

    In MRI, our goal is to recover an image of the "magnetization" $m(\mathbf r)$. This fancy word means basically "how strong is the signal emitted by nuclei at position $\mathbf r$?" The problem is that **MRI hardware is not spatially sensitive enough to directly measure $m(\mathbf r)$**. The solution that MRI engineers have come up with is to sample instead the _spatial fourier transform_ of $m(\mathbf r)$. In other words, we've sampled in the _fourier basis_; we call the fourier basis for spatial signals **"k-space"** and so the measured signal is called $M(\mathbf k)$. Our goal is to turn $M(\mathbf k)$ back into $m(\mathbf r)$.

    For a complete Cartesian k-space grid in our simplified model, MRI reconstruction is an **inverse Fourier transform**. With missing samples, an inverse FFT gives a zero-filled estimate; recovering missing information will require additional assumptions in Section 3. This perhaps brings you back to the early days of EE66, when we learned that the DFT helps us convert signals between time and frequency. The difference is that we're dealing with two- or three-dimensional spatial signals instead of one-dimensional time signals, so our spatial frequencies must also be two- or three-dimensional $^1$. This brings us to the main objective of this part of the lab:

    > **Which Fourier coefficients - that is, which spatial frequencies - are worth spending scan time to measure?**

    In summary, we can abstract away the nitty-gritty physical and mathematical derivations for MRI, leaving the **EE66 model of MRI**:
    1. the scanner encodes spatial position with phase and frequency;
    2. the scanner collects samples of the **2-D Fourier transform** of the object;
    3. an **inverse Fourier transform** reconstructs an image.

    We want to figure out which samples we should direct the scanner to collect. Since we've worked almost exclusively in 1-D this class, we're going to first spend some time making the jump to 2-D. Then we'll hop into k-space with some non-medical images.

    <sup> 1: check out [this](https://drive.google.com/file/d/1BNZvVWC6zujUavx7eYdH6LxVYibmlPMt/view?usp=share_link) short explanation of spatial frequencies if you want to learn more. </sup>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec0'></a>
    ## <span style="color:navy">0. Recap of 1-D Signals</span>

    Before jumping into two-dimensional k-space, it's worth remembering *why* sampling rate matters at all, using a signal you already know how to reason about: a 1-D sum of sinusoids (recall the Shazam lab).

    A scanner -- acoustic, MRI, or otherwise -- only has finite time, so it cannot measure an infinite continuous signal, and it cannot sample arbitrarily densely. Sampling too coarsely makes different frequencies produce indistinguishable sample values; this is called **aliasing**, and it is the same phenomenon you will see again in two dimensions in Section 1.

    The signal plotted below is

    $$x(t) = \sin(2\pi \cdot 7\,t) + 0.55\,\sin(2\pi \cdot 33\,t),$$

    a 7 Hz sinusoid plus a smaller 33 Hz sinusoid, over one second. The **gray curve** is the continuous signal; the **orange stems** are the samples we would actually measure with 24, 48, and 96 evenly spaced samples.
    """)
    return


@app.cell(hide_code=True)
def _(np, plt):
    t_ref = np.linspace(0, 1, 800, endpoint=False)
    f_low = 7
    f_high = 33
    continuous = np.sin(2*np.pi*f_low*t_ref) + 0.55*np.sin(2*np.pi*f_high*t_ref)

    sample_counts = [24, 48, 96]
    _fig, _ax = plt.subplots(len(sample_counts), 1, figsize=(9, 6), sharex=True)
    for _axis, _n in zip(_ax, sample_counts):
        _ts = np.linspace(0, 1, _n, endpoint=False)
        _xs = np.sin(2*np.pi*f_low*_ts) + 0.55*np.sin(2*np.pi*f_high*_ts)
        _axis.plot(t_ref, continuous, color='0.75', lw=1.2, label='continuous reference')
        _axis.stem(_ts, _xs, linefmt='C1-', markerfmt='C1o', basefmt=' ', label=f'{_n} samples')
        _axis.set_ylabel('amplitude')
        _axis.legend(loc='upper right')
    _ax[-1].set_xlabel('time (normalized)')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Check-in 0.1:** Looking at the plot above, what is the issue with the 24-sample row? Which of the two sinusoids (7Hz or 33Hz) do you expect to be reconstructed incorrectly, and why?
    """)
    return


@app.cell(hide_code=True)
def _(answer_1, mo):
    mo.callout(answer_1, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The main takeaway from above is that **sampling too far apart can cause us to lose valuable information**, a phenomenon known as *aliasing*. For another example and visualization, check out this [short explanation of aliasing](https://www.geeksforgeeks.org/electronics-engineering/aliasing-effect/).

    When you take EE120, you'll explore this idea more formally through the *Nyquist rate*.

    Another fundamental relationship you'll explore later in 2-D is between **sampling extent** and **resolution**.

    - **Sampling extent** is how much of a domain we measure. In time, it's the length of the recording ($T$ seconds in the example below). In k-space, it's how far out from the center we collect samples.
    - **Resolution** refers to how finely we can distinguish nearby structures in the other (Fourier-transformed) domain.

    Sampling over a larger extent in one domain lets us resolve finer details in the other.

    For now, we'll demonstrate this by sampling a signal in the time domain and examining its frequency resolution using the DFT. We'll define a simple sum of sinusoids below and, just for fun, add a small bit of noise. Then, we take the fourier transform and see how it looks. The signal is

    $$f(t) = 2.8\,\sin(2\pi \cdot 1\,t) + 0.4\,\sin(2\pi \cdot 0.5\,t) + 1.2\,\sin(2\pi \cdot 2\,t) + \text{noise}, \qquad 0 \le t < T,$$

    so it contains sinusoids at 0.5 Hz, 1 Hz, and 2 Hz. The slider sets $T$, the sampling extent in seconds (the sampling *rate* stays fixed at 1000 samples per second). Start with $T = 1$.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    T_slider = mo.ui.slider(1, 20, step=1, value=1, label="sampling extent T (seconds)", show_value=True)
    T_slider
    return (T_slider,)


@app.cell(hide_code=True)
def _(T_slider, np, plt):
    T = T_slider.value   # extent of sampling, set by the slider above
    n_samples = int(T*1000)  # keep sampling rate identical

    t = np.linspace(0, T, n_samples)
    f = 2.8*np.sin(2*np.pi*t) + 0.4*np.sin(0.5 * 2*np.pi*t) + 1.2*np.sin(2 * 2*np.pi*t) + np.random.randn(n_samples)

    _F = np.fft.fft(np.pad(f, (0, 10*n_samples)))    # zero padding gives smoother frequency representation but NO REAL CHANGE IN RESOLUTION
    _freqs = np.fft.fftfreq(_F.shape[0], d=T/n_samples)
    _F = _F[:_F.shape[0]//256]                 # plot only the lowest frequencies for the purposes of demonstration
    _freqs = _freqs[:_freqs.shape[0]//256]
    plt.figure()
    plt.plot(_freqs, np.abs(_F))
    plt.tick_params(left=False, labelleft=False)
    plt.xlabel("frequency (Hz)")
    plt.gca()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    If the result does not match your expectations, try sampling with a greater extent by moving the slider!

    **Check-in 0.2:** What is the smallest extent with which you can sample and resolve the spikes? A rough estimate is fine.
    """)
    return


@app.cell(hide_code=True)
def _(answer_3, mo):
    mo.callout(answer_3, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec1'></a>
    ## <span style="color:navy">1. 2-D Fourier Transforms</span>

    In Section 0, we wrote a 1-D signal as a sum of sinusoids. Images work the same way, except the building blocks are **2-D sinusoids**, which look like stripes across the image. Together, patterns like these form the **2-D Fourier basis**, and a few of them are plotted below.

    Each pattern is labeled by two frequencies $(k_x, k_y)$, where $k_x$ is how many times the pattern repeats as you move left to right across the image, and $k_y$ is how many times it repeats from top to bottom. Larger values give finer stripes, and the mix of $k_x$ and $k_y$ sets which way the stripes are tilted. The pattern $(0, 0)$ is constant and just sets the overall brightness.
    """)
    return


@app.cell(hide_code=True)
def _(np, plt):
    # a few 2-D Fourier basis patterns, cos(2*pi*(kx*x + ky*y)/N), for small kx, ky
    _N = 64
    _y, _x = np.indices((_N, _N))
    _fig, _ax = plt.subplots(4, 4, figsize=(8, 8.4))
    for _ky in range(4):
        for _kx in range(4):
            _ax[_ky, _kx].imshow(np.cos(2 * np.pi * (_kx * _x + _ky * _y) / _N), cmap="gray", vmin=-1, vmax=1)
            _ax[_ky, _kx].set_title(f"$(k_x, k_y) = ({_kx}, {_ky})$", fontsize=10)
            _ax[_ky, _kx].axis("off")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Any image can be written as a weighted sum of these patterns. For an image $f[x, y]$ with $N$ columns and $M$ rows, the weights come from the **2-D DFT**:

    $$F[k_x,k_y]=\sum_{x=0}^{N-1}\sum_{y=0}^{M-1} f[x,y]\, e^{-j2\pi\left(\frac{k_x x}{N}+\frac{k_y y}{M}\right)}.$$

    `np.fft.fft2` computes this for us. (The complex exponential packs a cosine pattern and a sine pattern into one number.) Each coefficient $F[k_x,k_y]$ tells us how much of pattern $(k_x,k_y)$ is in the image.

    **k-space is just a picture of these coefficients.** The pixel at position $(k_x, k_y)$ shows how big the coefficient $F[k_x,k_y]$ is. When we plot it, we use `np.fft.fftshift` to move the $(0,0)$ pattern to the middle, so finer patterns sit farther from the center. The coefficients are complex numbers, so we plot their magnitude with `np.abs`. A few of them are much larger than the rest, so we plot $\log(1+|F|)$ to keep the small ones visible. The axes are in cycles per pixel, from 0 at the center out to $\pm 0.5$ at the edges (stripes that flip every pixel).

    Let's build some intuition for how k-space looks for different images, starting with some zebras.
    """)
    return


@app.cell(hide_code=True)
def _(np, plt):
    def show_with_kspace(img, title):
        """Plot an image next to its k-space (log magnitude), with frequency axes."""
        _k = np.log1p(np.abs(np.fft.fftshift(np.fft.fft2(img))))
        _fig, _ax = plt.subplots(1, 2, figsize=(10, 4.3))
        _ax[0].imshow(img, cmap="gray")
        _ax[0].set_title(title)
        _ax[0].axis("off")
        _ax[1].imshow(_k, cmap="gray", extent=(-0.5, 0.5, 0.5, -0.5), vmin=np.percentile(_k, 90), vmax=np.percentile(_k, 99.9))
        _ax[1].set_title(f"k-space of the {title.lower()}" + r"  ($\log(1+|F|)$)")
        _ax[1].set_xlabel("$k_x$ (cycles/pixel)")
        _ax[1].set_ylabel("$k_y$ (cycles/pixel)")
        plt.tight_layout()
        return _fig

    return (show_with_kspace,)


@app.cell(hide_code=True)
def _(show_with_kspace, zebra_img):
    show_with_kspace(zebra_img, "Zebras")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The zebras are covered in stripes that look a lot like the Fourier patterns above. Most of the stripes on their necks and chests run up and down at a slight angle, so the brightness changes mostly as you move left to right, and their k-space is stretched out **sideways** along the $k_x$ axis. Because the stripes bend and point in slightly different directions, the energy spreads into a fuzzy band instead of a few sharp dots. Also, you may notice this zebra also has some horizontal lines. However, since the lines are thicker, these will tend to correspond to lower frequencies, and thus the vertical k-space is not as stretched out, with values higher closer to (0,0), the lowest frequency.

    Next, let's look at a picture of some trees.
    """)
    return


@app.cell(hide_code=True)
def _(show_with_kspace, trees_img):
    show_with_kspace(trees_img, "Trees")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The tree trunks have hard vertical edges, so the brightness changes sharply as you move left to right across a trunk but hardly at all as you move up and down along it. The energy in k-space therefore lines up along the **horizontal** ($k_x$) axis, and since the trunks are straight, it forms a thin line instead of the zebras' fuzzy band. In general, lines in an image will correspond to perpendicular lines in k-space.

    Now let's go the other way and start from k-space. **What image does this k-space come from?**
    """)
    return


@app.cell(hide_code=True)
def _(babak_img, np, plt):
    _k = np.log1p(np.abs(np.fft.fftshift(np.fft.fft2(babak_img))))
    _fig, _ax = plt.subplots(figsize=(5.2, 4.6))
    _ax.imshow(_k, cmap="gray", extent=(-0.5, 0.5, 0.5, -0.5), vmin=np.percentile(_k, 90), vmax=np.percentile(_k, 99.9))
    _ax.set_title(r"mystery k-space  ($\log(1+|F|)$)")
    _ax.set_xlabel("$k_x$ (cycles/pixel)")
    _ax.set_ylabel("$k_y$ (cycles/pixel)")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(babak_img, mo, plt):
    _fig, _ax = plt.subplots(figsize=(4, 4))
    _ax.imshow(babak_img, cmap="gray")
    _ax.axis("off")
    plt.tight_layout()
    mo.accordion({"Click to reveal the image": mo.vstack([
        mo.as_html(_fig),
        mo.md(r"It's **Babak**! It is hard to recognize a face from this log-magnitude plot alone (the full complex k-space does determine the image), but what you *can* see is that most of the energy in k-space is near the center, which is true of almost every real image."),
    ])})
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Like the zebras and the trees, Babak's k-space is brightest at the center, because the coefficients for low spatial frequencies are much larger than the rest. The log scale actually hides how lopsided this is: about **98% of the image's energy** sits within 5 pixels of the center, a tiny dot that covers 0.03% of k-space.

    Recall that our MRI machine is literally sampling points in the frequency domain, so **points in k-space**! An engineer who wants to spend less time sampling k-space might say, _"well, most of the energy is in the center, so let's only sample the center!"_ First, we'll try that and, while we're at it, we'll also see what would happen if the engineer got a bit confused and decided to do the opposite.

    Along the way, we'll look at two properties of an MR image:

    + **field of view (FOV):** how big the region is where the image lives;
    + **resolution:** how finely we can tell nearby structures apart (how sharp the image is).

    First, **write the following function** to create a radial boolean mask we could use to keep only frequencies near the center of k-space. The mask is `True` (or 1) at the k-space positions you want to keep and `False` (or 0) everywhere else.
    """)
    return


@app.cell(hide_code=True)
def _(Q1a_hint_1, Q1a_hint_2, mo):
    mo.vstack([Q1a_hint_1, Q1a_hint_2])
    return


@app.cell
def _(np):
    def make_radial_mask(shape, radius):
        """Make a filled circle (disk) mask centered in the image.

        Inputs:
            shape  -- (h, w), the size of the mask (same as the image / k-space)
            radius -- radius of the circle, in pixels

        Returns:
            a boolean array of size (h, w): True inside the circle (distance from
            the center (h/2, w/2) less than `radius`), False everywhere else.

        Why: applied to centered k-space, this keeps only the LOW frequencies.
        """
        yy, xx = np.indices(shape)   # yy[i, j] = i (row index), xx[i, j] = j (column index)
        h, w = shape

        # TODO: compute the distance from the center and return the disk mask.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()
        r = ...
        return ...

    return (make_radial_mask,)


@app.cell(hide_code=True)
def _(make_radial_mask, mo, test_Q1a, test_Q1a_btn):
    if test_Q1a_btn.value:
        with mo.status.spinner(title="Running Test Q1a..."):
            test_Q1a(make_radial_mask)
    test_Q1a_btn
    return


@app.cell(hide_code=True)
def _(babak_img, make_radial_mask, mask_radius_slider, np, plt):
    # visualize the low- and high-frequency masks and masked k-space
    mask_radius = mask_radius_slider.value   # set by the slider above
    low_mask = make_radial_mask(babak_img.shape, mask_radius)
    high_mask = ~low_mask   # high mask is inverted low mask

    _ksp = np.fft.fftshift(np.fft.fft2(babak_img))
    low_ksp = np.where(low_mask, _ksp, 0)
    high_ksp = np.where(high_mask, _ksp, 0)

    _fig, _ax = plt.subplots(2, 2, figsize=(8, 8))
    _ax[0, 0].imshow(low_mask, cmap='gray', vmin=0, vmax=1)
    _ax[0, 0].set_title(f'low-freq mask (r < {mask_radius})')
    _ax[0, 1].imshow(high_mask, cmap='gray', vmin=0, vmax=1)
    _ax[0, 1].set_title(f'high-freq mask (r > {mask_radius})')
    _ax[1, 0].imshow(np.log1p(np.abs(low_ksp)), cmap='gray')
    _ax[1, 0].set_title(r'masked k-space $\log(1+|F|)$')
    _ax[1, 1].imshow(np.log1p(np.abs(high_ksp)), cmap='gray')
    _ax[1, 1].set_title(r'masked k-space $\log(1+|F|)$')
    for _a in _ax.ravel():
        _a.axis('off')
    plt.tight_layout()
    _fig
    return low_mask, mask_radius


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Now we reconstruct an image from each masked k-space by taking the inverse Fourier transform of only the frequencies we kept. The functions below do this for both strategies, and we'll compare the results.
    """)
    return


@app.cell
def _(make_radial_mask, np):
    def recon_low_freqs(img, radius):
        """transform the image into k-space, shift it,
            apply a DC mask, and reconstruct."""
        ksp = np.fft.fftshift(np.fft.fft2(img))
        mask = make_radial_mask(ksp.shape, radius)
        masked = np.where(mask, ksp, 0)  # keep k-space inside the circle, zero elsewhere
        return np.fft.ifft2(np.fft.ifftshift(masked)).real  # undo the shift, then inverse FFT

    def recon_high_freqs(img, radius):
        """transform the image into k-space, shift it,
            apply an AC mask, and reconstruct."""
        ksp = np.fft.fftshift(np.fft.fft2(img))
        mask = ~make_radial_mask(ksp.shape, radius)  # ~ flips True/False: keep everything OUTSIDE the circle
        masked = np.where(mask, ksp, 0)
        return np.fft.ifft2(np.fft.ifftshift(masked)).real

    return recon_high_freqs, recon_low_freqs


@app.cell(hide_code=True)
def _(babak_img, mask_radius, plt, recon_high_freqs, recon_low_freqs):
    low_only = recon_low_freqs(babak_img, radius=mask_radius)
    high_only = recon_high_freqs(babak_img, radius=mask_radius)

    _fig, _ax = plt.subplots(1, 3, figsize=(12, 4))
    _ax[0].imshow(babak_img, cmap='gray')
    _ax[0].set_title('original')
    _ax[1].imshow(low_only, cmap='gray')
    _ax[1].set_title('low freqs only')
    _ax[2].imshow(high_only, cmap='gray')
    _ax[2].set_title('high freqs only')
    for _a in _ax:
        _a.axis('off')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    What do you notice about the image reconstructed by only low frequency information? What about the image reconstructed by only high frequency information? **More generally, what can you say about the _types of image features_ encoded respectively in the low and high frequencies?**

    **Warning:** the slider below sets the mask radius. Drag it all the way down to 5 at your own risk.
    """)
    return


@app.cell(hide_code=True)
def _(answer_4, mo):
    mo.callout(answer_4, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mask_radius_slider = mo.ui.slider(5, 150, step=5, value=20, label="mask radius (pixels)", show_value=True)
    mask_radius_slider
    return (mask_radius_slider,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Hopefully you see that the low-frequency-only image looks pretty good, except that it is blurry (nearby structures smear together). Try dragging the mask radius slider above to a larger value and watch the image sharpen as you "bring back" high-frequency information. This demonstrates one of the fundamental relationships between an image and its k space: **the extent of sampling (how large we set our mask to be) in k space determines the image's resolution** (how finely we can distinguish nearby structures). _If you want a high resolution image, you have no choice but to spend time collecting high frequency information!_

    Next we will see the other fundamental relationship: **_sampling_ k space affects the original image's _field of view_**.

    Informally: the **resolution** of your reconstruction is set by **how far out** in k-space you sample, e.g. how large we set mask radius above to be ($\text{resolution}\sim 1/k_{\max}$), while the **spacing** between your k-space samples sets the **field of view** you can represent without aliasing ($\Delta k \sim 1/\text{FOV}$). Both relationships are just restatements of the sampling idea from Section 0, now applied independently to the extent and the spacing of your k-space samples. A skipped-row mask is exactly the binary-mask idea from Section 0's aliasing discussion:

    $$K_{\mathrm{meas}}[k,\ell]=M[k,\ell]\,K[k,\ell], \qquad \hat f = \mathcal F^{-1}\{K_{\mathrm{meas}}\},$$

    where $M$ is the sampling mask (1 where you measure, 0 where you don't) and $\hat f$ is the **zero-filled reconstruction** you get by inverse-transforming the masked k-space directly.
    """)
    return


@app.cell(hide_code=True)
def _(low_mask, mo, np, plt):
    _psf = np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(low_mask.astype(float)))).real
    _h, _w = low_mask.shape
    _cy, _cx = _h // 2, _w // 2
    _zoom = 15
    _fig, _ax = plt.subplots(1, 2, figsize=(8, 4))
    _ax[0].imshow(low_mask, cmap='gray')
    _ax[0].set_title('mask $M$ (k-space)')
    _ax[0].axis('off')
    _crop = _psf[_cy - _zoom:_cy + _zoom, _cx - _zoom:_cx + _zoom]
    _lim = np.max(np.abs(_crop))
    _plot = _ax[1].imshow(_crop, cmap='RdBu_r', vmin=-_lim, vmax=_lim,
                          extent=(-_zoom, _zoom, _zoom, -_zoom))
    _fig.colorbar(_plot, ax=_ax[1], label='signed amplitude', shrink=0.75)
    _ax[1].set_title(r"impulse response $F^{-1}(M)$ (zoomed)")
    _ax[1].set_xlabel('horizontal offset (pixels)')
    _ax[1].set_ylabel('vertical offset (pixels)')
    plt.tight_layout()

    mo.accordion({"Optional: where does the blur actually come from?": mo.vstack([
        mo.md(r"""
    The zero-fill formula above, $\hat f = \mathcal F^{-1}\{M \cdot K\}$, is a product in k-space. By the convolution theorem, a product in one domain is a **convolution** in the other:

    $$h=\mathcal F^{-1}\{M\}, \qquad \hat f = f * h.$$

    Here $f$ is the image and $*$ is **circular convolution**: the finite DFT treats the image as periodic, so contributions can wrap around its edges. The plotted response is shifted to put its center in the middle.

    $\mathcal F^{-1}\{M\}$ is the **impulse response** (point-spread function) of "measure with mask $M$, then zero-fill": it's what a single bright point would turn into after passing through this measurement scheme, and the zero-filled reconstruction is just the true image smeared by that response everywhere at once. Here it is for the low-frequency mask from Section 1:
    """),
        mo.as_html(_fig),
        mo.md(r"""
    The disk produces a central peak surrounded by alternating positive and negative rings. Increasing its radius narrows the central peak, so nearby points are easier to distinguish. The sharp cutoff also produces ringing; this response is not just a positive blur.
    """),
    ])})
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Finish implementing the following function** that keeps only every `sample`th row (and zeros out the rest). The cell after it uses your mask to reconstruct a sparsely sampled version of Babak.
    """)
    return


@app.cell(hide_code=True)
def _(Q1b_hint_1):
    Q1b_hint_1
    return


@app.cell
def _(np):
    def make_sampling_mask_rows(shape, sample):
        """Make a mask that keeps every `sample`-th row of k-space.

        Inputs:
            shape  -- (h, w), the size of the mask
            sample -- keep one row out of every `sample` rows (2 = every other row)

        Returns:
            a boolean array of size (h, w): rows 0, sample, 2*sample, ... are all
            True; every other row is all False.

        Why: this simulates a faster scan that skips k-space lines.
        """
        mask = np.zeros(shape, dtype=bool)   # start with nothing sampled

        # TODO: keep every sample-th row.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()
        return mask

    return (make_sampling_mask_rows,)


@app.cell(hide_code=True)
def _(make_sampling_mask_rows, mo, test_Q1b, test_Q1b_btn):
    if test_Q1b_btn.value:
        with mo.status.spinner(title="Running Test Q1b..."):
            test_Q1b(make_sampling_mask_rows)
    test_Q1b_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The cell below applies the mask you just made to Babak's k-space and reconstructs the image with an inverse FFT, giving the zero-filled reconstruction from the equation above.
    """)
    return


@app.cell
def _(babak_img, make_sampling_mask_rows, np, plt, sample_slider):
    sample = sample_slider.value   # set by the slider above (powers of 2 divide the image size evenly)
    rows_mask = make_sampling_mask_rows(babak_img.shape, sample)

    rows_ksp = np.fft.fftshift(np.fft.fft2(babak_img))
    sampled_ksp = np.where(rows_mask, rows_ksp, 0)
    recon_rows = np.fft.ifft2(np.fft.ifftshift(sampled_ksp)).real  # undo the shift, inverse FFT

    _fig, _ax = plt.subplots(2, 2, figsize=(8, 8))
    _ax[0, 0].imshow(rows_mask, cmap='gray', aspect='auto', interpolation='nearest')
    _ax[0, 0].set_title(f'sampling mask (every {sample} rows)')
    _ax[0, 1].imshow(np.log1p(np.abs(sampled_ksp)), cmap='gray')
    _ax[0, 1].set_title(r'sampled k-space $\log(1+|F|)$')
    _ax[1, 0].imshow(babak_img, cmap='gray')
    _ax[1, 0].set_title('original')
    _ax[1, 1].imshow(recon_rows, cmap='gray')
    _ax[1, 1].set_title('zero-filled reconstruction')
    for _a in _ax.ravel():
        _a.axis('off')
    plt.tight_layout()
    _fig
    return (sample,)


@app.cell(hide_code=True)
def _(mo):
    sample_slider = mo.ui.slider(steps=[1, 2, 4, 8, 16], value=2, label="sample (keep every sample-th row)", show_value=True)
    sample_slider
    return (sample_slider,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The artifact you are seeing is called **aliasing**. A hand-wavy justification is that the fourier transform doesn't have enough information to tell whether the sampled frequency information came from the original image, or from a **"ghost copy"** that's been shifted, so it reconstructs both. Try moving the `sample` slider - **what is the relation between the sampling interval and the quantity of ghost copies?**
    """)
    return


@app.cell(hide_code=True)
def _(answer_5, mo):
    mo.callout(answer_5, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    So sparse sampling only works if the object fits inside the smaller field of view, so that the ghost copies land on empty space instead of on top of each other.

    To see this, we'll cheat a little by zeroing out the top and bottom of Babak's image so that he fits in the middle `1/sample` of the rows, and only then sampling. (This is a numerical demonstration. In a real scan, choose the sample spacing to match the size of the object.) Keep this in mind for Section 2, where the calf only fills part of its field of view.
    """)
    return


@app.cell(hide_code=True)
def _(Q1c_hint_1, Q1c_hint_2, mo):
    mo.vstack([Q1c_hint_1, Q1c_hint_2])
    return


@app.cell
def _(np):
    def truncate_fov_rows(img, sample):
        """Keep only a centered horizontal band of the image; zero the rest.

        Inputs:
            img    -- a 2-D image with n rows
            sample -- the row-skipping factor from make_sampling_mask_rows

        Returns:
            an image the same size as img, equal to img on the middle n // sample
            rows and 0 everywhere else.

        Why: skipping rows shrinks the field of view to n // sample rows. If the
        object fits inside that band, the ghost copies no longer overlap it.
        """
        out = np.zeros_like(img)   # all-zero image, same size as img
        n = img.shape[0]           # number of rows


        # TODO: copy the centered band of n // sample rows into out.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()
        keep = ...
        start = ...
        out[...] = ...
        return out

    return (truncate_fov_rows,)


@app.cell(hide_code=True)
def _(mo, test_Q1c, test_Q1c_btn, truncate_fov_rows):
    if test_Q1c_btn.value:
        with mo.status.spinner(title="Running Test Q1c..."):
            test_Q1c(truncate_fov_rows)
    test_Q1c_btn
    return


@app.cell(hide_code=True)
def _(babak_img, make_sampling_mask_rows, np, plt, sample, truncate_fov_rows):
    # uses the same `sample` as the cell above
    img_trunc = truncate_fov_rows(babak_img, sample)
    trunc_mask = make_sampling_mask_rows(img_trunc.shape, sample)

    ksp_trunc = np.fft.fftshift(np.fft.fft2(img_trunc))
    sampled_ksp_trunc = np.where(trunc_mask, ksp_trunc, 0)
    recon_trunc = np.fft.ifft2(np.fft.ifftshift(sampled_ksp_trunc)).real

    ksp_full = np.fft.fftshift(np.fft.fft2(babak_img))
    recon_full = np.fft.ifft2(np.fft.ifftshift(np.where(trunc_mask, ksp_full, 0))).real

    _fig, _ax = plt.subplots(2, 2, figsize=(8, 8))
    _ax[0, 0].imshow(img_trunc, cmap='gray')
    _ax[0, 0].set_title(f'truncated FOV (kept 1/{sample} of rows)')
    _ax[0, 1].imshow(np.log1p(np.abs(sampled_ksp_trunc)), cmap='gray')
    _ax[0, 1].set_title(r'sampled k-space after truncation')
    _ax[1, 0].imshow(recon_trunc, cmap='gray')
    _ax[1, 0].set_title('truncate FOV, then sample')
    _ax[1, 1].imshow(recon_full, cmap='gray')
    _ax[1, 1].set_title('just sample (aliasing!)')
    for _a in _ax.ravel():
        _a.axis('off')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Notice that the aliased copies no longer interfere!** By cutting off the top and bottom of the image, the ghost copy lands in what used to be empty space instead of on top of the face.

    *Note: you'll see in later classes that "truncating the FOV" is analogous to applying a low pass filter before sampling, which is an absolute necessity to avoid the effects of aliasing for any flavor of signal.*
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec2'></a>
    ## <span style="color:navy">2. A Design Challenge</span>

    MRI scans are notoriously time-consuming, and the technicians have been complaining of scans eating into their lunch break, so a hospital asks you to design an acquisition strategy that does __not use the full k space array__. Let's suppose the technicians have been scanning the lower extremities. They present the following image for you to diagnose - not for medical conditions, but for **possible inefficiencies in their acquisition strategy**!
    """)
    return


@app.cell(hide_code=True)
def _(calf_img, np, plt):
    calf_ksp = np.fft.fft2(calf_img)
    calf_ksp_dsp = np.log1p(np.abs(np.fft.fftshift(calf_ksp)))

    _fig, _ax = plt.subplots(1, 2, figsize=(10, 4))
    _ax[0].imshow(calf_img, cmap='gray')
    _ax[0].set_title('Calf')
    _ax[0].axis('off')
    _ax[1].imshow(calf_ksp_dsp, cmap='gray')
    _ax[1].set_title(r'k-space $\log(1+|F|)$')
    _ax[1].axis('off')
    plt.tight_layout()
    _fig
    return (calf_ksp,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Your "scan budget" is __50%__. Ideally, the hospital doesn't want to provoke the radiologists, too, so they're hoping for _no reduction in image quality_.

    ___Note:___ Real MRI machines typically work like a "raster scan." This means that you can sample one line at a time for free, so **the 50% budget only counts the number of unique rows or columns** you've decided to sample. You may want to balance field of view and resolution considerations explored in the previous section as you design your acquisition strategy. Here's a brief summary:
    + some high frequency information is useful to improve resolution, but **the "most important" information is in the low frequencies**
    + coherently sampling (for example, zeroing out every other line) might result in **aliasing artifacts**

    Recall from Section 1 that the spacing of your k-space lines sets the field of view, and that skipping every other line creates a ghost copy shifted by half the image. Is there empty space in the calf image for that copy to land in?

    **Design the binary mask.** Then, provide a brief explanation and accompanying reconstructed image. Some artifacts are ok as long as they don't reduce image quality, and as long as you warn the radiologists about these in your explanation.

    **Check-in 2.1:** looking at the k-space magnitude plot above, which axis -- rows or columns -- would you rather sample fully, and which would you rather skip? Why?
    """)
    return


@app.cell(hide_code=True)
def _(answer_6, mo):
    mo.callout(answer_6, kind="info")
    return


@app.cell(hide_code=True)
def _(Q2a_hint_1, Q2a_hint_2, mo):
    mo.vstack([Q2a_hint_1, Q2a_hint_2])
    return


@app.cell
def _(np):
    def make_acquisition_mask_50(shape):
        """Your 50% k-space sampling plan for the calf.

        Inputs:
            shape -- (h, w), the size of the calf's (centered) k-space

        Returns:
            a boolean array of size (h, w), True where the scanner measures.
            Only whole lines count toward the budget, so sample complete rows
            OR complete columns, and use half of them.
        """
        mask = np.zeros(shape, dtype=bool)

        # TODO: design a mask using half the complete rows or columns.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()
        return mask

    return (make_acquisition_mask_50,)


@app.cell(hide_code=True)
def _(calf_ksp, make_acquisition_mask_50, np, plt):
    mask50 = make_acquisition_mask_50(calf_ksp.shape)
    _sample_percent = min(mask50.any(axis=0).mean(), mask50.any(axis=1).mean())

    _ksp_c = np.fft.fftshift(calf_ksp)
    _ksp_masked = _ksp_c * mask50
    recon50 = np.abs(np.fft.ifft2(np.fft.ifftshift(_ksp_masked)))

    _fig, _ax = plt.subplots(1, 3, figsize=(12, 4))
    _ax[0].imshow(mask50, cmap='gray', aspect='auto', interpolation='nearest')
    _ax[0].set_title(f'sampling mask ({100 * _sample_percent:.1f}%)')
    _ax[0].axis('off')
    _ax[1].imshow(np.log1p(np.abs(_ksp_masked)), cmap='gray')
    _ax[1].set_title('masked k-space')
    _ax[1].axis('off')
    _ax[2].imshow(recon50, cmap='gray')
    _ax[2].set_title('reconstruction')
    _ax[2].axis('off')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The hospital comes back and says that the technologists are still unhappy! They say they've convinced the radiology department to deal with _poor image quality_ as long as it keeps the complaints down! You're now tasked with finding a sampling mask that recovers the best image possible with only __25%__ of the original k space. Like before, the hospital wants an explanation, including a description of how the image is affected by applying your sampling mask (see Check-in 2.2 below).

    A good place to start is your 50% mask, and from there you can save more time by spacing the lines further apart (more ghost copies, like the `sample` slider in Section 1) or by sampling a narrower band around the center (lower resolution, like the mask radius slider in Section 1). Which one can this calf image tolerate?
    """)
    return


@app.cell(hide_code=True)
def _(Q2b_hint_1, Q2b_hint_2, mo):
    mo.vstack([Q2b_hint_1, Q2b_hint_2])
    return


@app.cell
def _(np):
    def make_acquisition_mask_25(shape):
        """Your 25% k-space sampling plan for the calf.

        Inputs:
            shape -- (h, w), the size of the calf's (centered) k-space

        Returns:
            a boolean array of size (h, w), True where the scanner measures,
            using about a quarter of the lines. Hint: start from your 50% mask.
        """
        h, w = shape
        mask = np.zeros(shape, dtype=bool)

        # TODO: design a mask using about one quarter of the lines.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()

        return mask

    return (make_acquisition_mask_25,)


@app.cell(hide_code=True)
def _(calf_ksp, make_acquisition_mask_25, np, plt):
    mask25 = make_acquisition_mask_25(calf_ksp.shape)
    _sample_percent = min(mask25.any(axis=0).mean(), mask25.any(axis=1).mean())

    _ksp_c = np.fft.fftshift(calf_ksp)
    ksp_25 = _ksp_c * mask25
    recon25 = np.abs(np.fft.ifft2(np.fft.ifftshift(ksp_25)))

    _fig, _ax = plt.subplots(1, 3, figsize=(12, 4))
    _ax[0].imshow(mask25, cmap='gray', aspect='auto', interpolation='nearest')
    _ax[0].set_title(f'sampling mask ({100 * _sample_percent:.1f}%)')
    _ax[0].axis('off')
    _ax[1].imshow(np.log1p(np.abs(ksp_25)), cmap='gray')
    _ax[1].set_title('masked k-space')
    _ax[1].axis('off')
    _ax[2].imshow(recon25, cmap='gray')
    _ax[2].set_title('reconstruction')
    _ax[2].axis('off')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Check-in 2.2:** explain your 25% mask to the hospital, including how it affects the image. Then compare it with your 50% mask: which artifact got worse -- resolution loss, or aliasing/ghosting -- and why does that match your mask design choices?
    """)
    return


@app.cell(hide_code=True)
def _(answer_7, mo):
    mo.callout(answer_7, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec3'></a>
    ## <span style="color:navy">3. Compressed Sensing: Filling in the Blanks</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Worked example: the MRI measurement operator

    You have already taken an FFT, applied a mask, and reconstructed an image. Let's write those operations as a linear measurement model:

    $$\mathbf y=A_{\mathrm{MRI}}\mathbf x+\mathbf n,\qquad A_{\mathrm{MRI}}=MF.$$

    Here $\mathbf x$ contains the image pixels, $F$ is the 2-D Fourier transform, $M$ keeps the measured frequencies, and $\mathbf n$ is measurement noise. Start with $\mathbf n=0$. Applying $A$ predicts what the scanner would measure; it does not reconstruct the image.

    An image can be stacked row by row into a vector. The FFT is a matrix acting on that vector, but we compute it with `fft2` instead of storing a huge matrix. Similarly, multiplying each Fourier coefficient by a mask is a diagonal matrix operation. We keep the arrays 2-D for convenience. Entries at unmeasured locations are **zero placeholders**, not extra measurements saying the true coefficient is zero.

    **The two functions below are supplied. Read them, then inspect the reconstruction figure.** `mri_forward` takes an image to masked k-space. `mri_zero_fill` takes that array back to an image. The supplied code uses these conventions:

    | Quantity | Array layout |
    |---|---|
    | `img` | image pixels, shape `(h, w)` |
    | `mask` | boolean mask drawn with DC at the center, as in Sections 1–2 |
    | `y` | complex k-space, shape `(h, w)`, with DC at the corner and zeros at unmeasured entries |

    Use `ifftshift(mask)` to align the mask with the output of `fft2`. Both transforms use `norm="ortho"`; this uses a matching normalization, so a full FFT followed by its inverse still returns the original image. **Keep the complex values.** We take magnitudes only when displaying images, since taking `abs` inside a measurement operator would destroy linearity.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.accordion({
        "Hint #1: forward measurement": mo.md("First transform the image to k-space. Then multiply by the mask in the same layout as that k-space. `fft2` leaves DC at the corner."),
        "Hint #2: zero-fill reconstruction": mo.md("The missing entries in `y` are already zero. Apply the inverse transform with the same normalization; there is no centering to undo in `y`."),
    })
    return


@app.cell
def _(np):
    def mri_forward(img, mask):
        """Image -> masked, uncentered complex k-space (same shape).

        mask is centered; use norm="ortho". Do not modify either input.
        """
        ksp = np.fft.fft2(img, norm="ortho")
        return np.fft.ifftshift(mask) * ksp

    def mri_zero_fill(y):
        """Uncentered, zero-filled k-space -> complex image, same shape."""
        return np.fft.ifft2(y, norm="ortho")

    return mri_forward, mri_zero_fill




@app.cell(hide_code=True)
def _(babak_img, mri_forward, mri_zero_fill, np, plt):
    _full = np.ones(babak_img.shape, dtype=bool)
    _half = np.zeros_like(_full)
    _half[::2, :] = True
    _fig, _ax = plt.subplots(1, 3, figsize=(12, 4))
    _ax[0].imshow(babak_img, cmap="gray", vmin=0, vmax=1)
    _ax[0].set_title("original")
    for _a, _mask, _name in zip(_ax[1:], [_full, _half], ["full sampling", "every other row"]):
        _y = mri_forward(babak_img, _mask)
        _estimate = mri_zero_fill(_y)
        _data_error = np.linalg.norm(mri_forward(_estimate, _mask) - _y) / np.linalg.norm(_y)
        _image_error = np.linalg.norm(_estimate - babak_img) / np.linalg.norm(babak_img)
        _a.imshow(np.abs(_estimate), cmap="gray", vmin=0, vmax=1)
        _a.set_title(f"{_name}\nmeasurement error: {_data_error:.1e}\nimage error: {_image_error:.3f}")
    for _a in _ax:
        _a.axis("off")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **MRI model check-in:** the figure reports relative errors $\|A\hat x-y\|_2/\|y\|_2$ (measurement error) and $\|\hat x-x\|_2/\|x\|_2$ (image error). Why can the undersampled reconstruction have almost zero measurement error and still look wrong? Which Fourier coefficients could you change without changing the acquired samples?
    """)
    return


@app.cell(hide_code=True)
def _(answer_mri_model, mo):
    mo.callout(answer_mri_model, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    With full sampling, $F^{-1}F=I$ and we recover the image. With a mask, zero-fill gives $\hat x=F^{-1}MFx$, which need not equal $x$. For a binary mask and noiseless data, measuring that estimate again gives the same data: $MF\hat x=M^2Fx=MFx=y$.

    The mask is linear, but discards information. A fixed linear operator satisfies $A(\alpha x_1+\beta x_2)=\alpha Ax_1+\beta Ax_2$; being linear does **not** imply it has an inverse. The next part asks how additional information about images can help choose among estimates that agree with our measurements.

    ### Using sparsity to fill in the missing information
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    In Section 2, every way of cutting the scan to 25% cost us something, either ghost copies or blur. Part of the reason is what we did with the k-space samples we **didn't** measure. Zero-filling sets all of them to 0, which is a guess, and usually not a very good one.

    The samples we measured are fixed, but we're free to choose what goes in the blanks. Every choice gives an image that agrees with our measurements, and zero-fill is just one of them. **Compressed sensing** tries to pick a better one, and it has two parts. The first is to sample k-space so that the missing samples only cause noise-like errors, which we'll come back to after the first reconstruction. The second is a reconstruction step that asks:

    > **Of all the images that agree with what we measured, which one looks most like a real image?**

    It turns out that real images are **sparse** in the right basis, meaning that most of their coefficients in that basis are close to zero. Random noise is not. The plot below sorts every coefficient of Babak's image, and of an image of pure noise, from largest to smallest in three different bases.
    """)
    return


@app.cell(hide_code=True)
def _(babak_img, haar2_forward, np, plt):
    # sort every coefficient by size (largest first) in three bases
    _noise = np.random.default_rng(0).random(babak_img.shape)
    _fig, _ax = plt.subplots(1, 2, figsize=(11, 3.8), sharey=True)
    for _a, (_title, _img) in zip(_ax, [("Babak (a real image)", babak_img), ("random noise", _noise)]):
        _img = _img - _img.mean()   # remove the average brightness so one DC coefficient doesn't dominate
        for _label, _coef in [("pixels", _img),
                              ("Fourier", np.fft.fft2(_img)),
                              ("Haar wavelet", haar2_forward(_img, level=3))]:
            _c = np.sort(np.abs(_coef).ravel())[::-1]
            _a.semilogy(100 * np.arange(_c.size) / _c.size, _c / _c[0] + 1e-12, label=_label)
        _a.set_title(_title)
        _a.set_xlabel("% of coefficients (sorted, largest first)")
        _a.legend()
    _ax[0].set_ylabel("magnitude / largest")
    _ax[0].set_ylim(1e-4, 1.5)
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    For the real image, a few percent of the Fourier and wavelet coefficients hold almost everything, and the rest drop off by orders of magnitude. For noise, the coefficients are much less concentrated, and that difference is what lets us tell a real image apart from a bad guess. (It also means you will never "accidentally" make a real image by generating random pixels: picture monkeys banging away on typewriters, hoping to write *A Midsummer Night's Dream*.)

    We can't use Fourier sparsity, though, because k-space is where we take our measurements. Instead, we use the **Haar wavelet basis**. You won't need to know its details, since like the Fourier basis, it's just another set of patterns that we can write an image as a sum of. The patterns are small blocks instead of stripes, so the transform splits an image into a smaller, blurry copy plus "detail" coefficients that pick out edges. Here is Babak after one level of the transform:
    """)
    return


@app.cell(hide_code=True)
def _(babak_img, haar2_forward, np, plt):
    _w = np.abs(haar2_forward(babak_img, level=1))
    _h, _wd = _w.shape
    # scale the blurry copy and the (much smaller) detail coefficients separately so both are visible
    _show = _w / np.percentile(_w[_h // 2:, :], 99.5)
    _show[:_h // 2, :_wd // 2] = _w[:_h // 2, :_wd // 2] / _w[:_h // 2, :_wd // 2].max()
    _fig, _ax = plt.subplots(1, 2, figsize=(10, 4.6))
    _ax[0].imshow(babak_img, cmap="gray")
    _ax[0].set_title("Babak")
    _ax[1].imshow(np.clip(_show, 0, 1), cmap="gray")
    _ax[1].set_title("one level of the Haar wavelet transform")
    for (_r, _c), _label in {(0, 0): "blurry copy", (0, 1): "vertical edges",
                             (1, 0): "horizontal edges", (1, 1): "diagonal details"}.items():
        _ax[1].text(_c * _wd / 2 + 6, _r * _h / 2 + 18, _label, color="yellow", fontsize=9,
                    bbox=dict(facecolor="black", alpha=0.6, edgecolor="none", pad=1.5))
    for _a in _ax:
        _a.axis("off")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Previously $x$ contained image pixels. Now let $c=Wx$ contain wavelet coefficients, so $x=W^{-1}c$ and $y=MFW^{-1}c+n$. The scanner is unchanged; we have changed the coordinates of the unknown. Below, $A$ means this coefficient-domain operator and $b$ denotes the same measured data previously called $y$.

    Apart from the blurry copy, most of the coefficients are close to zero (dark), and only the edges light up. This is the sparsity we want to take advantage of. We'll look for an image whose wavelet coefficients have as few large entries as possible, and to measure "few large entries" we use the $\ell_1$ norm $\|c\|_1$, the sum of absolute values. It's much easier to minimize than a count of nonzero entries.

    Putting it together, we fill in the blanks by solving a problem called **Basis Pursuit Denoising (BPD)**, which is one of several reconstruction methods used in compressed sensing:

    $$ \underset{c \in \mathbb{C}^N}{\text{minimize}} \quad \|c\|_1 \quad \text{subject to} \quad \frac{1}{2} \|Ac - b\|_2^2 \le \epsilon $$

    **Code notation:** the existing solver calls its coefficient array `x` (and later `x_final`). Those variables represent $c$, not image pixels.

    In this problem,

    + $b$ is the k-space samples we actually measured;
    + $c$ is the **wavelet coefficients** of the image we're solving for (not the image itself);
    + $A$ is the measurement model: given a candidate $c$, it produces the samples the scanner would have measured if that were the true image.

    So BPD looks for the $c$ with the smallest $\ell_1$ norm (a sparse coefficient representation) whose predicted measurements $Ac$ are close to $b$ (an image that agrees with what we measured).

    The diagram below shows how $A$ turns a guess $c$ into the measurements the scanner would have made if those coefficients described the true image.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.mermaid("""
    graph LR
        X["c: wavelet coefficients"] -->|"W⁻¹: inverse wavelet transform"| I["image"]
        I -->|"F: 2-D FFT"| K["full k-space"]
        K -->|"M: keep the measured samples"| AX["Ac: predicted measurements"]
        AX -.->|"BPD compares"| B["b: actual measurements"]
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Here $W$ is the Haar wavelet transform (image to wavelet coefficients), so $W^{-1}$ turns wavelet coefficients back into an image. Reading the diagram from left to right gives $A = MFW^{-1}$.

    **Check-in 3.1:** why does $A$ need the $W^{-1}$ step at all? What would go wrong if we used $A = MF$ while $c$ still held wavelet coefficients?
    """)
    return


@app.cell(hide_code=True)
def _(answer_11, mo):
    mo.callout(answer_11, kind="info")
    return


@app.cell(hide_code=True)
def _(Q3a_hint_1, Q3a_hint_2, mo):
    mo.vstack([
        mo.md(r"""
    We solve BPD with a standard solver called **FISTA**, which is already written for you as `bpd` in `utils/wavelets.py`. All it needs from you is the operator $A$ (and its adjoint $A^H$).
    """),
        mo.accordion({"Optional reading: how FISTA solves BPD": mo.md(r"""
    FISTA (Fast Iterative Shrinkage-Thresholding Algorithm) repeatedly:

      1) takes a **gradient-descent step** in the direction that reduces $\|Ac - b\|_2$ (**consistency** with the measurements), then
      2) applies a **shrinkage (soft-thresholding)** step that pulls small coefficients toward zero (**sparsity**).

    Hopefully, these steps seem like reasonable things to do!

    Strictly speaking, FISTA with a fixed threshold solves the penalized form of the problem, $\min_c \frac{1}{2}\|Ac-b\|_2^2 + \lambda\|c\|_1$, rather than the constrained form above. The `thresh` argument of `bpd` plays the role of $\lambda$ and sets how much data consistency we trade for sparsity, the same job $\epsilon$ does in the constrained form.
    """)}),
        mo.md(rf"""
    In the cell below, **build $A = MFW^{-1}$** by following the diagram above, with one line of code per block in the order they act on $c$ (first $W^{-1}$, then $F$, then $M$). The adjoint $A^H$, which FISTA also needs, is supplied. It applies the adjoint of each block in reverse order. This maps measurements back to coefficient space; it does not restore missing samples.

    {Q3a_hint_1}
    {Q3a_hint_2}
    """),
    ])
    return


@app.cell
def _(haar2_forward, np):
    def make_A_and_AH(shape, mask, level=3):
        """Build the compressed-sensing measurement operator A = M F W^-1 and
        its adjoint A^H, both as plain Python functions.

        Inputs:
            shape -- (h, w), the image size
            mask  -- boolean (h, w) sampling mask, drawn in CENTERED k-space
                     (DC in the middle), like every mask in this lab
            level -- number of Haar wavelet levels (leave at 3)

        Returns:
            A  -- function: wavelet coefficients x  ->  measured k-space samples
                  (inverse wavelet W^-1, then FFT F, then mask M). YOU write this.
            AH -- function: k-space y  ->  wavelet coefficients (A's steps in
                  reverse; already written for you)

        (See utils/wavelets.py for the Haar transform and why AH is the adjoint.)
        """
        # Our masks are drawn in centered k-space (DC in the middle), but
        # np.fft.fft2 puts DC in the corner, so we un-center the mask once, here.
        shifted_mask = np.fft.ifftshift(mask)

        def A(x):
            # TODO: coefficients -> image -> k-space -> measured samples.
            # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
            raise NotImplementedError()
            img = ...
            ksp = ...
            return ...

        def AH(y):
            # given: adjoints in reverse order; masking is not invertible
            img = np.fft.ifft2(shifted_mask * y, norm="ortho")
            return haar2_forward(img, level=level)

        return A, AH

    return (make_A_and_AH,)


@app.cell(hide_code=True)
def _(make_A_and_AH, mo, test_Q3a, test_Q3a_btn):
    if test_Q3a_btn.value:
        with mo.status.spinner(title="Running Test Q3a..."):
            test_Q3a(make_A_and_AH)
    test_Q3a_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Now we can test BPD. We'll measure a random half of Babak's k-space (individual samples this time, not whole rows or columns) and let BPD fill in the rest. We'll come back to why the mask is random after the reconstruction. The mask is made for you below, and `SAMPLING_PERCENT` sets how much of k-space we keep, so after you see the result, try lowering it.
    """)
    return


@app.cell(hide_code=True)
def _(np):
    def make_random_mask(shape, fraction):
        """Make a random sampling mask.

        Inputs:
            shape    -- (h, w), the size of the mask
            fraction -- the fraction of pixels to sample, between 0 and 1

        Returns:
            a boolean array of size (h, w) where each pixel is independently True
            with probability `fraction` (so about fraction * h * w pixels are True).
        """
        rng = np.random.default_rng(66)   # fixed seed, so everyone gets the same mask
        return rng.random(shape) < fraction   # each pixel: True with probability `fraction`

    return (make_random_mask,)


@app.cell
def _(babak_img, make_random_mask, plt):
    SAMPLING_PERCENT = 0.50

    cs_mask_demo = make_random_mask(babak_img.shape, SAMPLING_PERCENT)
    plt.figure(figsize=(4, 4))
    plt.imshow(cs_mask_demo, cmap='gray')
    plt.title(f'random mask ({100 * cs_mask_demo.mean():.1f}% sampled)')
    plt.axis('off')
    plt.gca()
    return (SAMPLING_PERCENT,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Set up the BPD problem** (find $b$ and $A$) and use `bpd(b, A, AH, shape)` to reconstruct. _Keep in mind that BPD might take a few seconds to run._ You can also try passing `niter=` or `thresh=` to play with the optional BPD parameters. `niter` tells the algorithm how many gradient descent + shrinkage steps to apply; `thresh` tells the algorithm how aggressively to shrink small coefficients toward zero (a rough stand-in for how strictly you enforce sparsity).

    The cell then shows your reconstruction next to the zero-filled one. Remember that `bpd` returns wavelet coefficients, so convert $c$ back to an image first.
    """)
    return


@app.cell(hide_code=True)
def _(Q3b_hint_1, Q3b_hint_2, mo):
    mo.vstack([Q3b_hint_1, Q3b_hint_2])
    return


@app.cell
def _(SAMPLING_PERCENT, babak_img, make_random_mask, np, plt):
    '''
    Goal: reconstruct Babak from a random SAMPLING_PERCENT of k-space with BPD.
    Given below:
        cs_mask       -- the random sampling mask (centered k-space)
        cs_ksp        -- Babak's full k-space, centered (fftshift), norm="ortho"
        cs_ksp_masked -- the samples we actually measured (centered)
    You produce:
        b      -- the measurements, UNshifted so they line up with np.fft.fft2
        A, AH  -- the operators for this mask (from make_A_and_AH)
        x      -- BPD's answer: wavelet coefficients, not an image
        recon  -- the reconstructed image (real, non-negative)
    '''
    cs_mask = make_random_mask(babak_img.shape, SAMPLING_PERCENT)
    cs_ksp = np.fft.fftshift(np.fft.fft2(babak_img, norm="ortho"))
    cs_ksp_masked = cs_ksp * cs_mask


    # TODO: prepare b, construct A and AH, run BPD, and recover image magnitudes.
    # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
    raise NotImplementedError()
    b = ...
    A, AH = ...
    x = ...
    recon = ...

    direct_recon = np.abs(np.fft.ifft2(b, norm="ortho"))

    _fig, _ax = plt.subplots(1, 3, figsize=(12, 4))
    _ax[0].imshow(babak_img, cmap="gray")
    _ax[0].set_title("Babak")
    _ax[1].imshow(direct_recon, cmap="gray")
    _ax[1].set_title("zero-fill reconstruction")
    _ax[2].imshow(recon, cmap="gray")
    _ax[2].set_title("BPD reconstruction")
    for _a in _ax:
        _a.axis("off")
    plt.tight_layout()
    _fig
    return b, cs_mask, direct_recon, recon, x


@app.cell(hide_code=True)
def _(b, babak_img, cs_mask, mo, recon, test_Q3b, test_Q3b_btn, x):
    if test_Q3b_btn.value:
        with mo.status.spinner(title="Running Test Q3b..."):
            test_Q3b(b, x, recon, babak_img, cs_mask)
    test_Q3b_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Both reconstructions use the same measured data. Zero-fill sets unmeasured coefficients to zero. BPD trades measurement agreement against sparsity in the wavelet coefficients; with a nonzero threshold, it need not match the measured samples exactly.

    So why did we use a random mask? In Section 1, skipping every other row made a clean ghost copy of Babak, which is called a **coherent** artifact. It looks like real image structure, so it's just as sparse as a real image, and BPD has no reason to remove it. Random sampling makes the error **incoherent** instead, spreading it over the whole image like noise, and since noise is not sparse, BPD can reduce it. Compressed sensing works best when the undersampling error looks like noise rather than like a second copy of the image, which will matter again in Section 5.

    Suppose we want to quantify exactly how good our reconstruction is. A simple error metric is

    $$ \frac{||y_{\text{recon}} - y_{\text{original}}||_2}{||y_{\text{original}}||_2}$$

    called the **normalized root-mean-square error (NRMSE)**. It measures how far the reconstructed image is from the ground truth the _same way_ BPD measures its distance from samples of the ground truth (in particular, by the 2 norm). It's already written for you as the function `nrmse_cs` below.

    The cell below also reports the **Structural Similarity Index Measure (SSIM)** (see the [wiki page](https://en.wikipedia.org/wiki/Structural_similarity_index_measure) for more info). This is a more advanced metric that is closer to the way human eyes perceive images. It uses both metrics to compare the BPD reconstruction with the naive zero-filled one.

    Lower NRMSE is better (0 is perfect), and higher SSIM is better (1 is perfect), and you'll see both numbers again in Section 5.
    """)
    return


@app.cell(hide_code=True)
def _(np):
    def nrmse_cs(y_original, y_recon):
        """Normalized root-mean-square error between two images.

        Inputs:
            y_original -- the ground-truth image
            y_recon    -- a reconstruction of it (same size)

        Returns:
            a single number, ||y_recon - y_original||_2 / ||y_original||_2.
            0 means a perfect reconstruction; bigger is worse.
        """
        return np.linalg.norm(y_recon - y_original) / np.linalg.norm(y_original)

    return (nrmse_cs,)


@app.cell(hide_code=True)
def _(babak_img, direct_recon, nrmse_cs, recon, ssim):
    err_zero = nrmse_cs(babak_img, direct_recon)
    err_bpd = nrmse_cs(babak_img, recon)

    d = babak_img.max() - babak_img.min()   # data range of the ground-truth image, needed by SSIM
    ssim_zero = ssim(babak_img, direct_recon, data_range=d)
    ssim_bpd = ssim(babak_img, recon, data_range=d)

    print(f"zero-fill   NRMSE: {err_zero:.4f}       SSIM: {ssim_zero:.4f}")
    print(f"BPD         NRMSE: {err_bpd:.4f}        SSIM: {ssim_bpd:.4f}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec4'></a>
    ## <span style="color:navy">4. Non-Cartesian Sampling and Motion Artifacts</span>

    _Most_ MRI scans use a raster-scan approach that samples an entire row or column of k-space at a time since this is the easiest to program and reconstruct. However, it _is_ possible to fill in k-space in other ways. Sometimes we call the sampling pattern a **"k-space trajectory."** You can imagine that we've sent a scout to explore k-space; they can walk around where they want to (with some constraints, of course), recording values as they go. It's easy to reconstruct an image if these values lie on a grid because we can simply FFT.

    Suppose we collect samples in circles, or diamonds, or stars, or in the shape of a caricature of your favorite EE66 lab TA. Technically, recovering an image in this case would require the use of something called a "_Nonuniform Fast Fourier Transform_" ([NUFFT](https://en.wikipedia.org/wiki/Non-uniform_discrete_Fourier_transform)) instead of the standard cartesian FFT.

    In other words, a trajectory is a choice of where, and in what order, we sample k-space. The reconstruction is still a Fourier transform, just a modified one (the NUFFT). In this lab we approximate trajectories with masks so that we can keep using the ordinary FFT. Below are masks for two common trajectories: **radial** (spokes through the center) and **spiral** (from the center outward). Both are written for you, and you'll reuse the spiral in Section 5. Its code is hidden; you only need its signature, `make_spiral_trajectory_mask(shape, n_turns, thickness)`.

    For fun, let's do this section with an MR image of a hand.
    """)
    return


@app.cell(hide_code=True)
def _(hand_img, np, plt):
    hand_ksp = np.fft.fft2(hand_img)
    hand_ksp_dsp = np.log1p(np.abs(np.fft.fftshift(hand_ksp)))

    _fig, _ax = plt.subplots(1, 2, figsize=(8, 4))
    _ax[0].imshow(hand_img, cmap='gray')
    _ax[0].set_title('Hand')
    _ax[0].axis('off')
    _ax[1].imshow(hand_ksp_dsp, cmap='gray')
    _ax[1].set_title(r'k-space $\log(1+|F|)$')
    _ax[1].axis('off')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(np):
    def make_radial_trajectory_mask(shape, n_spokes=10, thickness=1.0):
        """return a boolean mask that is True along `n_spokes` lines
            through the k-space center (approximate radial trajectory)."""
        h, w = shape
        cy, cx = h // 2, w // 2 # k-space center (DC) after fftshift
        yy, xx = np.indices(shape)
        y, x = yy - cy, xx - cx # centered coordinates

        mask = np.zeros(shape, dtype=bool)
        for k in range(n_spokes):
            alpha = k * np.pi / n_spokes # kth angle (0 to pi * (n_spokes-1)/n_spokes btw)
            dist = np.abs(x * np.sin(alpha) - y * np.cos(alpha)) # distance from line at angle alpha, leave this filled in
            mask |= dist <= thickness # boolean or to set pixels close to that line True
        return mask

    return (make_radial_trajectory_mask,)


@app.cell(hide_code=True)
def _(np):
    def make_spiral_trajectory_mask(shape, n_turns=10, thickness=1.0):
        """return a boolean mask that is True along an Archimedean spiral
            from the k-space center out to the edge."""
        h, w = shape
        cy, cx = h // 2, w // 2 # k-space center (DC) after fftshift
        yy, xx = np.indices(shape)
        y, x = yy - cy, xx - cx # centered coordinates

        r = np.hypot(x, y) # conversion to polar coordinates
        theta = np.arctan2(y, x) # HINT: normal arctan outputs -pi/2 to pi/2. we want angles in -pi to pi
        theta = np.mod(theta, 2 * np.pi) # HINT: put theta in (0, 2pi)

        r_max = min(h, w) / 2 # max circle radius that fits inside the image bounds
        s = r_max / (2 * np.pi * n_turns) # scale factor so 2pi*(n_turns*s) = r_max

        # if s*(theta + 2pik) ~= r, then that pixel is on the spiral
        k = np.round((r / s - theta) / (2 * np.pi))
        phi = theta + 2 * np.pi * k
        dist = np.abs(r - s * phi)
        return dist <= thickness # only keep that distance is within the desired thickness

    return (make_spiral_trajectory_mask,)


@app.cell(hide_code=True)
def _(hand_img, make_radial_trajectory_mask, make_spiral_trajectory_mask, plt):
    # what the two trajectories look like as k-space masks
    _masks = {
        "radial (spokes through the center)": make_radial_trajectory_mask(hand_img.shape, n_spokes=10, thickness=1.0),
        "spiral (center outward)": make_spiral_trajectory_mask(hand_img.shape, n_turns=10, thickness=1.0),
    }
    _fig, _ax = plt.subplots(1, 2, figsize=(8, 4))
    for _a, (_name, _m) in zip(_ax, _masks.items()):
        _a.imshow(_m, cmap="gray", vmin=0, vmax=1, interpolation="nearest")
        _a.set_title(f"{_name}\n{100 * _m.mean():.1f}% of k-space")
        _a.axis("off")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    If you're lucky enough to experience an MRI scan - they're pretty cool! - you will find out that they take a _really long time_. This is why motion artifacts are a _big problem_, especially for small children with a lot of energy or elderly people with stiff backs. A nice perk of some non-cartesian trajectories is their **robustness to motion artifacts**.

    We're going to simulate the effects of motion in an MRI scan by filling in k-space partway, then shifting the object slightly, and then filling in the rest. The cell below creates the shifted hand image. Our earlier model assumed every measurement described the same stationary image. Here the data mix two positions, so reconstructing with that stationary-image model produces artifacts.
    """)
    return


@app.cell(hide_code=True)
def _(hand_img, np, plt):
    # shift the hand to the right by 1/5 of the image width
    shifted_hand_img = np.roll(hand_img, hand_img.shape[1] // 5, axis=1)

    _fig, _ax = plt.subplots(1, 2, figsize=(8, 4))
    _ax[0].imshow(hand_img, cmap='gray')
    _ax[0].set_title('before motion')
    _ax[0].axis('off')
    _ax[1].imshow(shifted_hand_img, cmap='gray')
    _ax[1].set_title('after motion')
    _ax[1].axis('off')
    plt.tight_layout()
    _fig
    return (shifted_hand_img,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Interactive: Acquisition Order and Motion Robustness
    Use the controls below to choose **which trajectory** fills k-space (Cartesian top-to-bottom, Cartesian centric, radial spoke by spoke, or spiral center-out) and **how far into the scan** the patient moves (as a fraction of total acquisition time). Everything acquired *before* that point uses `hand_img`; everything acquired *after* uses `shifted_hand_img`.

    To keep the comparison fair, every trajectory here eventually visits *all* of k-space; they only differ in the *order* they visit it. The left panel shows which samples were acquired before the motion. A sharp image of the hand in either position counts as a success, so the error is measured against whichever clean image (before or after the motion) is closer.
    """)
    return


@app.cell(hide_code=True)
def _(hand_img, mo, np, nrmse, plt, shifted_hand_img):
    # Interactive k-space acquisition-order / motion-robustness explorer.
    # Every trajectory below visits ALL of k-space, just in a different order.
    # So the only difference between them is WHEN each k-space sample is
    # acquired relative to the motion event.
    _h, _w = hand_img.shape
    _yy, _xx = np.indices((_h, _w))
    _y_c, _x_c = _yy - _h // 2, _xx - _w // 2  # k-space center (DC) after fftshift
    _r_polar = np.hypot(_x_c, _y_c)
    _theta = np.mod(np.arctan2(_y_c, _x_c), 2 * np.pi)

    _ksp_still = np.fft.fftshift(np.fft.fft2(hand_img))
    _ksp_moved = np.fft.fftshift(np.fft.fft2(shifted_hand_img))

    def acquisition_order(key):
        """(rows, cols) of every k-space pixel, sorted by `key` (= acquisition time)."""
        idx = np.argsort(key.ravel(), kind='stable')
        return np.unravel_index(idx, (_h, _w))

    def cartesian_order(top_down=True):
        # one full row at a time: top to bottom, or center rows first ("centric")
        row_rank = _yy if top_down else np.abs(_yy - _h // 2)
        return acquisition_order(row_rank * 2 * _w + _xx)

    def radial_order(n_spokes=60):
        # one spoke (a line through the center) at a time, sweeping the angle.
        # each pixel is acquired with the spoke whose angle is closest to its own.
        spoke = np.floor(np.mod(np.arctan2(_y_c, _x_c), np.pi) / (np.pi / n_spokes))
        return acquisition_order(spoke * _h * _w + _r_polar)

    def spiral_order(n_turns=32):
        # walk along an Archimedean spiral from the center outward
        s = (min(_h, _w) / 2) / (2 * np.pi * n_turns)
        phi = _theta + 2 * np.pi * np.round((_r_polar / s - _theta) / (2 * np.pi))
        return acquisition_order(phi)

    _trajectory_orders = {
        'Cartesian (top-to-bottom)': cartesian_order(top_down=True),
        'Cartesian (centric, center rows first)': cartesian_order(top_down=False),
        'Radial (spoke by spoke)': radial_order(),
        'Spiral (center-out)': spiral_order(),
    }

    def explore_motion(trajectory, motion_time):
        rows, cols = _trajectory_orders[trajectory]
        split = int(motion_time * len(rows))

        # samples acquired before the motion come from the still hand,
        # everything after comes from the moved hand
        ksp_motion = _ksp_moved.copy()
        ksp_motion[rows[:split], cols[:split]] = _ksp_still[rows[:split], cols[:split]]
        before = np.zeros((_h, _w), dtype=bool)
        before[rows[:split], cols[:split]] = True

        recon = np.abs(np.fft.ifft2(np.fft.ifftshift(ksp_motion)))
        # A sharp image of the hand in EITHER position is fine; ghosts and
        # streaks are the damage. So compare against the closer clean image.
        err = min(nrmse(recon, hand_img), nrmse(recon, shifted_hand_img))

        fig, ax = plt.subplots(1, 2, figsize=(9, 4))
        ax[0].imshow(before, cmap='gray', vmin=0, vmax=1, interpolation='nearest')
        ax[0].set_title(f'{trajectory}\nwhite = acquired before motion ({100*motion_time:.0f}%)')
        ax[1].imshow(recon, cmap='gray')
        ax[1].set_title(f'reconstruction\n(NRMSE vs closer clean image = {err:.3f})')
        ax[0].set_xticks([]); ax[0].set_yticks([])  # keep the frame so white k-space stays visible
        ax[1].axis('off')
        plt.tight_layout()
        return fig

    trajectory_dropdown = mo.ui.dropdown(
        options=list(_trajectory_orders.keys()),
        value='Cartesian (top-to-bottom)',
        label="trajectory",
    )
    motion_time_slider = mo.ui.slider(0.05, 0.95, step=0.05, value=0.5, label="motion at")

    mo.hstack([trajectory_dropdown, motion_time_slider], justify="start")
    return explore_motion, motion_time_slider, trajectory_dropdown


@app.cell(hide_code=True)
def _(explore_motion, motion_time_slider, trajectory_dropdown):
    explore_motion(trajectory_dropdown.value, motion_time_slider.value)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Pick the acquisition strategy most robust to motion artifacts and explain why it works so well.** Use the explorer above: sweep `motion at` from early (0.1) to late (0.9) for each trajectory and compare the damage. **For the top-to-bottom Cartesian trajectory, when is motion most harmful, and why?** (Hint: most of the image's energy is near the center of k-space. When does each trajectory collect it?)
    """)
    return


@app.cell(hide_code=True)
def _(answer_13, mo):
    mo.callout(answer_13, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec5'></a>
    ## <span style="color:navy">5. A Design Challenge, Revisited</span>

    The hospital is back with a complaint. The techs used your Section 2 advice on all of their scans, and the radiologists are not happy, because a blurry leg was fine but a blurry brain is not. The new constraints are:

    + the scan budget is still **25%**;
    + the brain fills the whole field of view, so the Section 2 trick (skip lines and let the ghost copy land in empty space) won't work;
    + the image must be sharper than what you get by sampling only the center.

    This time, your mask has two parts:

    1. **A fully sampled region (FSR):** keep a disk at the center of k-space, where most of the image's energy lives (Section 1).
    2. **An incoherent trajectory** for the high frequencies, using the spiral from Section 4. Because it doesn't skip whole lines, the missing samples look like _noise_ instead of ghost copies.

    Then you reconstruct with BPD (Section 3), which can remove noise-like error.

    Here is the brain and its k-space:
    """)
    return


@app.cell(hide_code=True)
def _(brain_img, np, plt):
    brain_ksp = np.fft.fft2(brain_img)
    brain_ksp_dsp = np.log1p(np.abs(np.fft.fftshift(brain_ksp)))

    _fig, _ax = plt.subplots(1, 2, figsize=(8, 8))
    _ax[0].imshow(brain_img, cmap='gray')
    _ax[0].set_title('original')
    _ax[1].imshow(brain_ksp_dsp, cmap='gray')
    _ax[1].set_title(r'k-space $\log(1+|F|)$')
    for _a in _ax:
        _a.axis('off')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    In the cell below, build the FSR + spiral mask, then reconstruct the brain with BPD the same way you did in Section 3. For the brain, call the solver as `bpd(b, A, AH, shape, thresh=0.001, niter=200)`. These settings suit this smaller (256 x 256) image, and it still runs in a few seconds. Then run the autograder.
    """)
    return


@app.cell(hide_code=True)
def _(Q5_hint_1, Q5_hint_2, mo):
    mo.vstack([Q5_hint_1, Q5_hint_2])
    return


@app.cell
def _():
    # Goal: design a 25% mask for the brain (FSR disk + spiral) and reconstruct
    # it with BPD. You produce:
    #   final_mask      -- boolean mask, size of brain_img (centered k-space)
    #   b_final         -- the measured samples, unshifted (like b in Section 3)
    #   A_final, AH_final, x_final -- the BPD pieces, as in Section 3
    #   recon_bpd_final -- the reconstructed brain image (real, non-negative)
    fsr_radius = 40   # radius of the fully sampled region, in pixels
    n_turns = 8       # number of spiral turns
    thickness = 1.5   # spiral line thickness, in pixels


    # TODO: combine the masks, prepare the measurements, and reconstruct with BPD.
    # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
    raise NotImplementedError()
    final_mask = ...
    b_final = ...
    A_final, AH_final = ...
    x_final = ...
    recon_bpd_final = ...
    return b_final, final_mask, recon_bpd_final


@app.cell(hide_code=True)
def _(brain_img, final_mask, mo, recon_bpd_final, test_Q5, test_Q5_btn):
    if test_Q5_btn.value:
        with mo.status.spinner(title="Running Test Q5..."):
            test_Q5(final_mask, recon_bpd_final, brain_img)
    test_Q5_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The cell below compares your design with two other strategies that use the same 25% budget, sampling only the center (what the techs tried first) and an FSR plus randomly chosen full columns. Each row shows the mask, the zero-filled reconstruction, and the BPD reconstruction. _(It runs BPD twice more, so give it a few seconds.)_
    """)
    return


@app.cell(hide_code=True)
def _(
    b_final,
    bpd,
    brain_img,
    final_mask,
    haar2_inverse,
    make_A_and_AH,
    np,
    nrmse_cs,
    plt,
    recon_bpd_final,
    ssim,
):
    _h, _w = brain_img.shape
    _d = brain_img.max() - brain_img.min()

    # alternative 1: only the central 25% of columns
    _center = np.zeros((_h, _w), dtype=bool)
    _n = int(round(0.25 * _w))
    _center[:, _w // 2 - _n // 2: _w // 2 - _n // 2 + _n] = True

    # alternative 2: a 15% band of center columns plus random columns elsewhere
    _cols = np.zeros((_h, _w), dtype=bool)
    _nc = int(round(0.15 * _w))
    _c0 = _w // 2 - _nc // 2
    _cols[:, _c0:_c0 + _nc] = True
    _outer = np.setdiff1d(np.arange(_w), np.arange(_c0, _c0 + _nc))
    _cols[:, np.random.default_rng(66).choice(_outer, size=_n - _nc, replace=False)] = True

    def _reconstruct(mask):
        b = np.fft.ifftshift(np.fft.fftshift(np.fft.fft2(brain_img, norm="ortho")) * mask)
        A, AH = make_A_and_AH(brain_img.shape, mask)
        x = bpd(b, A, AH, brain_img.shape, thresh=0.001, niter=200)
        return np.abs(np.fft.ifft2(b, norm="ortho")), np.abs(haar2_inverse(x, level=3))

    _rows = [
        ("center only", _center, *_reconstruct(_center)),
        ("FSR + random columns", _cols, *_reconstruct(_cols)),
        ("FSR + spiral (yours)", final_mask, np.abs(np.fft.ifft2(b_final, norm="ortho")), recon_bpd_final),
    ]
    _fig, _ax = plt.subplots(3, 3, figsize=(11, 11))
    for _r, (_name, _mask, _zf, _bp) in enumerate(_rows):
        _ax[_r, 0].imshow(_mask, cmap="gray", vmin=0, vmax=1, interpolation="nearest")
        _ax[_r, 0].set_title(f"{_name}\n{100 * _mask.mean():.0f}% of k-space")
        for _c, (_kind, _img) in enumerate([("zero-fill", _zf), ("BPD", _bp)], start=1):
            _ax[_r, _c].imshow(_img, cmap="gray")
            _ax[_r, _c].set_title(f"{_kind}\nNRMSE {nrmse_cs(brain_img, _img):.3f}, SSIM {ssim(brain_img, _img, data_range=_d):.3f}")
    for _a in _ax.ravel():
        _a.axis("off")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Check-in 5.1:** rank the three masks best-to-worst by BPD reconstruction quality, and explain the ranking in one or two sentences using the idea of *coherent vs. incoherent* undersampling artifacts (Section 3). Lower NRMSE and higher SSIM are better, but also look at the images.
    """)
    return


@app.cell(hide_code=True)
def _(answer_16, mo):
    mo.callout(answer_16, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    To summarize, with the same 25% budget (in theory, 75% less scan time than a full scan):

    + **Center only** throws away the high frequencies. The image is blurry, and These measurements alone cannot determine the missing detail; recovery depends on additional assumptions.
    + **FSR + random columns** brings high frequencies back, but skipping whole columns creates **coherent** ghost copies, which BPD mistakes for real structure.
    + **FSR + spiral** brings them back **incoherently**, so the missing samples look like noise, which BPD can often reduce.

    Most of the improvement comes from the mask design, since BPD only helps when the sampling pattern leaves it noise-like errors to clean up.

    Hopefully you see the power of compressed sensing: in theory, you spent 75% less time sampling and still recovered a much better image than either alternative. That's the end of Part 1, and we hope you had fun exploring some interesting ideas about imaging!
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='bridge'></a>
    ## Bridging MRI and CT: from frequency samples to line integrals
    In Part 1, every design question came down to which k-space samples were worth the scan time. CT asks the same kind of question (how few measurements can we get away with?), but the cost is different. In MRI each measurement costs time, while in CT each measurement costs radiation dose.

    The measurement itself is also different, since instead of samples of a 2-D Fourier transform, a CT scanner measures how much X-rays are weakened along straight lines through the body. Both modalities still fit the same linear model,

    $$\mathbf y = A\mathbf x + \mathbf n,$$

    with $x$ again denoting image pixels. For MRI, $A=MF$. For CT, we will first transform the raw detector intensities into line integrals; those transformed measurements fit a linear projection model. We will build its matrix in Section 6.

    We'll also switch test images. From here on, we use the **Shepp-Logan phantom**, the standard test object for CT. Its sharp, simple shapes make streaks and blur easy to see.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Part 2. CT.
    <a id='sec6'></a>
    ## <span style="color:navy">6. From attenuation to line integrals</span>
    A CT scanner works by **shooting X-rays through the patient and measuring what comes out the other side**. A source on one side sends in a beam with a known intensity $I_0$. Every bit of tissue the beam passes through absorbs or scatters some of it, so the detector on the far side measures a weaker intensity $I$. Bone weakens the beam a lot, soft tissue less, and air hardly at all.

    So each detector reading tells us **how much the beam was weakened along one straight path** through the body, but it can't tell us _where_ along the path that happened, only the total.

    To make this precise, we describe the body by its **attenuation coefficient** $\mu(x,y)$, which says how strongly the tissue at each point weakens X-rays, and this is the image we want to recover. Each short step $d\ell$ through tissue multiplies the beam's intensity by about $e^{-\mu\,d\ell}$, and multiplying these factors along the whole path $L$ gives the **Beer-Lambert law**:

    $$I=I_0\exp\left(-\int_L\mu(x,y)\,d\ell\right).$$

    The integral $\int_L \mu\,d\ell$ is called a **line integral**: walk along the path and add up the attenuation you pass through. On a pixel grid, it's the sum of the pixel values the ray crosses, times the pixel width. Here is one path through the phantom:
    """)
    return


@app.cell(hide_code=True)
def _(np, phantom, plt):
    _row = phantom.shape[0] // 2 + 10
    _profile = phantom[_row, :]
    _fig, _ax = plt.subplots(1, 2, figsize=(11, 3.8))
    _ax[0].imshow(phantom, cmap="gray")
    _ax[0].axhline(_row, color="tab:red", lw=2)
    _ax[0].set_title("one X-ray path: source (left) to detector (right)")
    _ax[0].axis("off")
    _ax[1].plot(_profile, color="tab:red")
    _ax[1].fill_between(np.arange(_profile.size), _profile, color="tab:red", alpha=0.3)
    _ax[1].set_xlabel("position along the path (pixels)")
    _ax[1].set_ylabel(r"attenuation $\mu$")
    _ax[1].set_title(f"line integral = shaded area = {_profile.sum():.1f}")
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The detector doesn't measure that area directly, but it does measure $I$, and taking the negative log of $I / I_0$ recovers the line integral:

    $$-\ln\left(\frac{I}{I_0}\right)=\int_L\mu(x,y)\,d\ell.$$

    At one rotation angle $\theta$, the detector row records many parallel paths at once. This set of line integrals is called a **projection** $p_\theta(s)$, where $s$ is the position along the detector. The scanner then rotates and measures again, and stacking the projections from every angle side by side gives a **sinogram** (mathematically, the **Radon transform** of the object).

    **Fill in the function below** that turns raw detector readings $I$ into line integrals. Then we'll scan the phantom from 180 angles and see what your function does to the data.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.accordion({"Optional: the Radon transform formula": mo.md(r"""
    For angle $\theta$ and detector coordinate $s$, a projection can be written using a delta function:

    $$p_\theta(s)=\int\!\!\int \mu(x,y)\,\delta(s-x\cos\theta-y\sin\theta)\,dx\,dy.$$

    Interpret the delta function as selecting the points on the line $x\cos\theta+y\sin\theta=s$. The set of all projections is called the **Radon transform**.
    """)})
    return


@app.cell(hide_code=True)
def _(Q6_hint_1, Q6_hint_2, mo):
    mo.vstack([Q6_hint_1, Q6_hint_2])
    return


@app.function
def intensities_to_line_integrals(I, I0):
    """Turn raw CT detector readings into line integrals (Beer-Lambert).

    Inputs:
        I  -- array of detected X-ray intensities, one per ray (0 < I <= I0)
        I0 -- the intensity of the beam entering the patient (a single number)

    Returns:
        an array the same shape as I: the total attenuation along each ray,
        i.e. the integral of mu along that line.
    """

    # TODO: solve Beer-Lambert for the line integral.
    # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
    raise NotImplementedError()
    return ...


@app.cell(hide_code=True)
def _(mo, test_Q6, test_Q6_btn):
    if test_Q6_btn.value:
        with mo.status.spinner(title="Running Test Q6..."):
            test_Q6(intensities_to_line_integrals)
    test_Q6_btn
    return


@app.cell(hide_code=True)
def _(make_sinogram, np, phantom):
    # The scan used by the rest of Part 2: 180 equally spaced views of the phantom.
    angles = np.linspace(0, 180, 180, endpoint=False)
    sino = make_sinogram(phantom, angles)
    return angles, sino


@app.cell(hide_code=True)
def _(angles, make_sinogram, np, phantom, plt):
    # The simulated scanner: each pixel is 0.04 cm wide, and I0 photons enter every ray.
    _pixel_cm = 0.04
    _I0 = 10_000
    _detector_I = _I0 * np.exp(-make_sinogram(phantom, angles) * _pixel_cm)   # what the detector measures

    # your function turns the raw readings back into line integrals (in pixel units)
    _sino_yours = intensities_to_line_integrals(_detector_I, _I0) / _pixel_cm

    _ext = [angles[0], angles[-1], _detector_I.shape[0], 0]
    _fig, _axs = plt.subplots(1, 3, figsize=(15, 4))
    _axs[0].imshow(phantom, cmap='gray'); _axs[0].set_title('the phantom (attenuation map)'); _axs[0].axis('off')
    _axs[1].imshow(_detector_I, cmap='gray', aspect='auto', extent=_ext); _axs[1].set_title('raw detector reading $I$')
    _axs[2].imshow(_sino_yours, cmap='magma', aspect='auto', extent=_ext); _axs[2].set_title('your sinogram (unit-pixel convention)')
    for _a in _axs[1:]:
        _a.set_xlabel('projection angle (degrees)'); _a.set_ylabel('detector position')
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    *Units in the simulation:* the raw readings use pixels 0.04 cm wide. After the log transform, the display divides by 0.04 to match the unit-pixel sums used by `make_sinogram`. This fixed scaling preserves linearity.

    The raw detector reading is brightest where nothing is in the way (almost the whole beam gets through) and darkest through the thickest part of the phantom. Taking $-\ln(I/I_0)$ flips this around and turns the multiplied attenuation factors into a sum. The result is the sinogram, which every reconstruction from here on starts from.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Coding exercise Q6b: predict CT measurements

    The logarithm gives us sums along rays. If we stack the attenuation pixels into $x$, each sum has the form

    $$y_i=\sum_{j=0}^{N-1} A_{ij}x_j,\qquad y=Ax.$$

    Row $i$ of $A$ describes one ray; column $j$ describes how pixel $j$ contributes to all the rays. In an ideal pixel model, $A_{ij}$ is the length of ray $i$ inside pixel $j$. Assume unit pixel width for this small example.

    For instance, stack a $2\times2$ image **row by row**, so $x=[x_0,x_1,x_2,x_3]^T$. A horizontal ray through the top row measures $x_0+x_1$, so its matrix row is $[1,1,0,0]$. The two horizontal rays followed by the two vertical rays give:

    Write the image and its vector separately:

    $$X=\begin{bmatrix}x_0 & x_1 \\ x_2 & x_3\end{bmatrix},\qquad
    x=\begin{bmatrix}x_0 \\ x_1 \\ x_2 \\ x_3\end{bmatrix}.$$

    Order the measurements as **top row, bottom row, left column, right column**. With one unit of path length through each crossed pixel,

    $$y=Ax=
    \begin{bmatrix}
    1 & 1 & 0 & 0 \\
    0 & 0 & 1 & 1 \\
    1 & 0 & 1 & 0 \\
    0 & 1 & 0 & 1
    \end{bmatrix}
    \begin{bmatrix}x_0 \\ x_1 \\ x_2 \\ x_3\end{bmatrix}
    =\begin{bmatrix}x_0+x_1 \\ x_2+x_3 \\ x_0+x_2 \\ x_1+x_3\end{bmatrix}.$$

    For $X=\begin{bmatrix}1&2\\3&4\end{bmatrix}$, this gives $y=[3,7,4,6]^T$. The first column of $A$ is $[1,0,1,0]^T$: the top-left pixel contributes to the top-row and left-column measurements only. Four measurements do not guarantee a unique image: the sum of the two row measurements equals the sum of the two column measurements, so one equation is redundant.

    This hand-built example specifies its own ray order. The numerical projector below uses more angles and a different, explicitly defined ordering; its matrix is not this $4\times4$ matrix.

    In Lab 4, you built a convolution matrix by applying the blur to one basis image at a time. We can use the same construction for CT: apply the measurement operator to one basis image at a time. Let $e_j$ be an image with pixel $j$ equal to 1 and all other pixels zero. **The measured projection of $e_j$ is column $j$ of $A$.** Since $x=\sum_j x_j e_j$, linearity gives $Ax=\sum_j x_j A e_j$: the weighted sum of those columns.

    The supplied `ct_project_small(img, angles)` computes a sinogram. It uses numerical interpolation, so the matrix we build will contain the weights of that numerical projector, rather than exact geometric path lengths. This lets matrix multiplication and the supplied projector agree to rounding accuracy.

    **Only complete `ct_forward`: one matrix multiplication.** The matrix builder is supplied: it turns on one pixel at a time and stores its projected measurements in the corresponding column. Read that loop, then use the resulting matrix to predict measurements of an arbitrary image.

    `img.ravel()` stacks image rows; `sinogram.ravel()` stacks detector rows, with angles varying within each row. Use that same order everywhere. If there are $N=h\,w$ pixels and $m$ detector–angle pairs, $A$ has shape `(m, N)` and `y` has shape `(m,)`.
    """)
    return


@app.cell(hide_code=True)
def _(radon):
    def ct_project_small(img, angles):
        """Small-grid projector; retain the entire square image, with unit pixels."""
        return radon(img, theta=angles, circle=False, preserve_range=True)

    return (ct_project_small,)


@app.cell(hide_code=True)
def _(mo):
    mo.accordion({
        "Hint #1: one matrix column": mo.md("`basis.flat[j]` addresses pixel j in row-by-row order. Project that basis image with `ct_project_small`, then flatten its sinogram with `.ravel()`."),
        "Hint #2: dimensions": mo.md("`A_ct[:, j]` is column j. To predict measurements, multiply the completed matrix by the flattened image using `@` (not elementwise `*`)."),
    })
    return


@app.cell
def _(ct_project_small, np):
    def build_ct_matrix(shape, angles):
        """Return a real (measurements, pixels) matrix for ct_project_small.

        shape is (h, w); angles is a 1-D array of angles in degrees.
        Both images and sinograms use NumPy's default row-by-row ravel order.
        Intended for tiny grids only, not the full-size phantom.
        """
        n_pixels = int(np.prod(shape))
        n_measurements = ct_project_small(np.zeros(shape), angles).size
        A_ct = np.zeros((n_measurements, n_pixels))
        for j in range(n_pixels):
            basis = np.zeros(shape)
            basis.flat[j] = 1.0
            A_ct[:, j] = ct_project_small(basis, angles).ravel()
        return A_ct

    def ct_forward(A_ct, img):
        """Predict the flattened line-integral measurements of img using A_ct."""
        # TODO: predict measurements by multiplying A_ct by the image vector.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()
        return ...

    return build_ct_matrix, ct_forward


@app.cell(hide_code=True)
def _(build_ct_matrix, ct_forward, mo, test_Q6b, test_Q6b_btn):
    if test_Q6b_btn.value:
        with mo.status.spinner(title="Running Test Q6b..."):
            test_Q6b(build_ct_matrix, ct_forward)
    test_Q6b_btn
    return


@app.cell(hide_code=True)
def _(build_ct_matrix, ct_forward, ct_project_small, np, plt):
    ct_small = np.zeros((8, 8))
    ct_small[1:7, 2:6] = 0.3
    ct_small[2:4, 3:5] = 1.0
    ct_small[5:7, 4:6] = 0.7
    ct_small_angles = np.linspace(0, 180, 12, endpoint=False)
    ct_matrix = build_ct_matrix(ct_small.shape, ct_small_angles)
    ct_y = ct_forward(ct_matrix, ct_small)
    _direct = ct_project_small(ct_small, ct_small_angles)
    _predicted = ct_y.reshape(_direct.shape)
    _fig, _ax = plt.subplots(1, 3, figsize=(12, 3.8))
    _ax[0].imshow(ct_small, cmap="gray", vmin=0, vmax=1)
    _ax[0].set_title("8 by 8 attenuation image")
    _ax[0].set_xlabel("pixel column"); _ax[0].set_ylabel("pixel row")
    for _a, _data, _title in zip(_ax[1:], [_direct, _predicted], ["supplied projector", "matrix prediction: A @ x"]):
        _a.imshow(_data, cmap="magma", aspect="auto", vmin=0, vmax=_direct.max(), extent=(0, 180, _direct.shape[0], 0))
        _a.set_title(_title); _a.set_xlabel("projection angle (degrees)"); _a.set_ylabel("detector bin")
    plt.tight_layout()
    print(f"A shape: {ct_matrix.shape} (measurements, pixels)")
    print(f"Largest matrix/projector difference: {np.max(np.abs(_predicted - _direct)):.2e}")
    _fig
    return ct_matrix, ct_small, ct_y


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Check-in 6.1:** what do one row and one column of your matrix represent? If a pixel's attenuation doubles, what happens to that pixel's contribution to the measurements? Why does this linear model use $-\ln(I/I_0)$ rather than raw intensity $I$?

    We store a dense matrix only for this tiny image. The full phantom has far more pixels, so we continue to apply the projection operator as a function. The small example keeps the whole square (`circle=False`); the full-size phantom examples use `circle=True` because the object fits inside the scan circle. These are different domains, not different linear-algebra principles.
    """)
    return


@app.cell(hide_code=True)
def _(answer_ct_matrix, mo):
    mo.callout(answer_ct_matrix, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.accordion({"A message from Babak": mo.md(r"![Read my lips, Scotty! No new frequencies.](public/lti_scotty.png)")})
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Why does a sinogram look like a pile of overlapping waves? To see why, follow **a single bright point** at $(x_0, y_0)$. As the scanner rotates, the point doesn't stay in one detector bin, and instead lands at

    $$s = x_0\cos\theta + y_0\sin\theta,$$

    which is a sinusoid in $\theta$. **Every point in the object traces its own sinusoid**, and the sinogram is their attenuation-weighted sum. The single-point sinogram below is the same kind of object you stored in one column of $A$. _(This formula uses the math convention where $y$ points up. Image rows count down, so in the code the $y$ term picks up a minus sign.)_

    Think of a merry-go-round seen from the side. As it turns, each rider moves left and right in a sine wave. Riders near the edge swing wide, riders near the middle barely move, and a rider at the very center doesn't move at all. In CT the scanner rotates instead of the body, but the detector sees the same thing, with each point swinging back and forth by an amount equal to its distance from the center.
    """)
    return


@app.cell(hide_code=True)
def _(angles, make_sinogram, np, phantom, plt):
    _point = np.zeros_like(phantom)
    _y0, _x0 = 72, 118
    _point[_y0, _x0] = 1
    _point_sino = make_sinogram(_point, angles)
    _cy = (phantom.shape[0]-1)/2
    _cx = (phantom.shape[1]-1)/2
    _theta_rad = np.deg2rad(angles)
    # image rows count DOWNWARD, so the row offset enters with a minus sign
    _pred = (_x0-_cx)*np.cos(_theta_rad) - (_y0-_cy)*np.sin(_theta_rad) + _point_sino.shape[0]/2
    _fig, _ax = plt.subplots(1, 2, figsize=(12, 4))
    _ax[0].imshow(_point, cmap='gray'); _ax[0].plot(_x0, _y0, 'ro'); _ax[0].set_title('single bright point'); _ax[0].axis('off')
    _ax[1].imshow(_point_sino, cmap='magma', aspect='auto', extent=[angles[0], angles[-1], _point_sino.shape[0], 0])
    _ax[1].plot(angles, _pred, 'c-', lw=2, label='predicted trace')
    _ax[1].set_title('sinogram trace'); _ax[1].set_xlabel('angle (degrees)'); _ax[1].set_ylabel('detector position'); _ax[1].legend()
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    This is why sinograms aren't arbitrary images, and it also makes them useful for debugging, since motion, calibration drift, metal, or missing angles leave structured traces rather than random-looking errors.

    **Look** (no answer box, but be ready to explain this at checkoff). Go back to the full phantom sinogram above. **Why do some curves swing wider than others, and which part of the phantom does the widest one come from?**
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.vstack([
        mo.md(r"""
    <a id='sec7'></a>
    ## <span style="color:navy">7. Reconstructing the image: backprojection and filtered backprojection</span>
    Now that we have the sinogram, how do we get the image back? The simplest idea is to run the measurement in reverse, smearing each projection back across the image along the lines that produced it and adding up the contributions from every angle, which is called **backprojection**. (In operator language, backprojection is the adjoint $R^T$ of the projection $R$. It reverses the direction of the data flow, but it is not the inverse.)

    The standard CT reconstruction adds one step before smearing, which is to high-pass filter each projection with a **ramp filter** $Q(\omega)=|\omega|$ that boosts high spatial frequencies. Backprojecting these filtered projections is called **filtered backprojection (FBP)**.

    The figure below compares the two, with the phantom in the top row and, in the bottom row, a single bright dot backprojected from more and more views and then with FBP.
    """),
        mo.accordion({"Optional: the filtered backprojection formula": mo.md(r"""
    $$\hat \mu(x,y)=\int_0^\pi (p_\theta*q)(x\cos\theta+y\sin\theta)\,d\theta,$$

    where $q$ is the ramp filter (frequency response $Q(\omega)=|\omega|$) and $p_\theta$ is the projection at angle $\theta$.
    """)}),
    ])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Worked example: backprojection as a transpose

    Your matrix predicts measurements: $y_i=\sum_j A_{ij}x_j$. Now send each measurement back to the pixels that contributed to it, using those same weights:

    $$ (x_{\mathrm{BP}})_j=\sum_i A_{ij}y_i,\qquad x_{\mathrm{BP}}=A^T y.$$

    That is a **transpose**, not an inverse. $A$ has shape `(m, N)`, so $A^T$ has shape `(N, m)` and takes $m$ measurements back to $N$ pixels. **`ct_backproject` is supplied below**: it multiplies by the transpose, then reshapes to the original image shape. It does not normalize or clip the result; its amplitude is part of this operation. For the four-ray example above, $A^T[3,7,4,6]^T=[7,9,11,13]^T$, which is clearly different from the original $[1,2,3,4]^T$. Each pixel receives the sum of the two measurements crossing it.

    For this real-valued CT matrix, the adjoint is the transpose $A^T$. For complex MRI matrices it is the conjugate transpose $A^H$. Neither notation promises an inverse. We will use the exact transpose of our small matrix here; the library backprojector below uses numerical interpolation and scaling, so it need not give exactly the same pixel values.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.accordion({"Hint: follow the dimensions": mo.md("`A_ct.T` swaps the rows and columns. Multiply it by the measurement vector `y` with `@`, then use `.reshape(shape)` to put the pixels back into rows and columns.")})
    return


@app.function
def ct_backproject(A_ct, y, shape):
    """Backproject the measurements into an image of shape (h, w).

    A_ct is real with shape (m, h*w); y is a real vector of shape (m,).
    Preserve the weighted sum: no clipping or normalization.
    """
    return (A_ct.T @ y).reshape(shape)




@app.cell(hide_code=True)
def _(ct_forward, ct_matrix, ct_small, ct_y, np, plt):
    _point = np.zeros_like(ct_small)
    _point[3, 4] = 1
    _back = ct_backproject(ct_matrix, ct_y, ct_small.shape)
    _point_back = ct_backproject(ct_matrix, ct_forward(ct_matrix, _point), _point.shape)
    _fig, _ax = plt.subplots(1, 4, figsize=(13, 3.5))
    for _a, _im, _title in zip(_ax, [ct_small, _back, _point, _point_back],
                              ["original", "your backprojection", "one bright pixel", "backprojected pixel"]):
        _plot = _a.imshow(_im, cmap="gray", vmin=0)
        _a.set_title(_title); _a.set_xlabel("pixel column"); _a.set_ylabel("pixel row")
        _fig.colorbar(_plot, ax=_a, shrink=0.65)
    plt.tight_layout()
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Check-in 7.0:** follow the single bright pixel through measurement and backprojection. Why does its value spread to other pixels? In the expression $A^TAx$, what would $A^TA$ have to be to recover *every* image exactly? The colorbars show that backprojection also changes the scale, but rescaling alone does not remove the spreading.
    """)
    return


@app.cell(hide_code=True)
def _(answer_ct_bp, mo):
    mo.callout(answer_ct_bp, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The small matrix makes the spreading explicit. Now return to the full phantom and compare plain backprojection with **filtered backprojection**. Filtering changes the projections before we send them back across the image; it compensates for the blur of ordinary backprojection when the angular sampling is sufficiently dense. With finite pixels and views, the reconstruction is still approximate.
    """)
    return


@app.cell(hide_code=True)
def _(
    angles,
    backproject,
    filtered_backproject,
    make_sinogram,
    np,
    nrmse,
    phantom,
    plt,
    sino,
):
    # top row: the phantom, reconstructed both ways (180 views)
    _bp = backproject(sino, angles, phantom.shape[0])
    _fbp = np.clip(filtered_backproject(sino, angles, phantom.shape[0]), 0, 1)

    # bottom row: a single small bright dot, backprojected from more and more views
    _n = phantom.shape[0]
    _yy, _xx = np.indices((_n, _n))
    _dot = ((_yy - 80) ** 2 + (_xx - 110) ** 2 <= 4).astype(float)
    _dots = []
    for _k in [1, 2, 8, 180]:
        _th = np.linspace(0, 180, _k, endpoint=False)
        _dots.append((backproject(make_sinogram(_dot, _th), _th, _n), f"backprojection, {_k} view{'s' if _k > 1 else ''}"))
    _th = np.linspace(0, 180, 180, endpoint=False)
    _dots.append((filtered_backproject(make_sinogram(_dot, _th), _th, _n), "FILTERED backprojection, 180 views"))

    _fig = plt.figure(figsize=(18, 8.5))
    _top, _bottom = _fig.subfigures(2, 1)
    _ax = _top.subplots(1, 3)
    for _a, (_im, _title) in zip(_ax, [(phantom, "original"),
                                       (_bp, "backprojection\n(brightness scale is arbitrary)"),
                                       (_fbp, f"filtered backprojection\nNRMSE={nrmse(_fbp, phantom):.3f}")]):
        _a.imshow(_im, cmap="gray"); _a.set_title(_title); _a.axis("off")
    _ax = _bottom.subplots(1, 5)
    for _a, (_im, _title) in zip(_ax, _dots):
        _a.imshow(_im, cmap="gray", vmin=0, vmax=0.35 * _im.max())   # brightened so the halo shows
        _a.set_title(_title, fontsize=10); _a.axis("off")
    _fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Check-in 7.1:** plain backprojection looks blurry, while filtered backprojection gives sharp boundaries. Using the figure (especially the single dot), explain **why spreading each measurement along an entire line causes blur**, and **what the ramp filter does about it**.
    """)
    return


@app.cell(hide_code=True)
def _(answer_17, mo):
    mo.callout(answer_17, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    FBP gives a sharp image from 180 views, but every view costs the patient radiation. Next, we'll see how few views we can get away with.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec8'></a>
    ## <span style="color:navy">8. Radiation dose and the measurement budget</span>
    So far we've used 180 views. Every view is another dose of X-rays, so the hospital wants as few as possible.<sup>1</sup>

    At fixed exposure per view, fewer angles mean less dose, but some directions go unmeasured. In the matrix picture, each omitted view removes a group of measurement rows. Fewer equations can leave more ambiguity or make reconstruction less stable. Drag the slider and watch what happens to the sinogram and both reconstructions as you remove views. What kind of artifact appears, and at roughly how many views does it start to bother you?

    <sup>1: You could also cut dose by keeping every view but using a weaker beam. Fewer photons make each projection noisier, and because the ramp filter boosts high frequencies, it amplifies that noise too. (Real scanners soften this by rolling the ramp filter off at the highest frequencies.) In this lab we'll focus on the number of views.</sup>
    """)
    return


@app.cell(hide_code=True)
def _(iradon, mo, np, phantom, plt, radon):
    # Interactive CT acquisition explorer
    views_slider = mo.ui.slider(6, 180, step=6, value=36, label="number_of_views")

    def explore_ct_views(number_of_views):
        theta = np.linspace(0, 180, number_of_views, endpoint=False)
        sino = radon(phantom, theta=theta, circle=True)
        bp = iradon(sino, theta=theta, filter_name=None, circle=True)
        fbp = iradon(sino, theta=theta, filter_name='ramp', circle=True)
        fig, ax = plt.subplots(1, 4, figsize=(16, 4))
        ax[0].imshow(phantom, cmap='gray'); ax[0].set_title('object')
        ax[1].imshow(sino, cmap='gray', aspect='auto'); ax[1].set_title(f'sinogram ({number_of_views} views)')
        ax[2].imshow(bp, cmap='gray'); ax[2].set_title('backprojection')
        ax[3].imshow(fbp, cmap='gray'); ax[3].set_title('filtered backprojection')
        for a in ax: a.axis('off')
        plt.tight_layout()
        return fig

    views_slider
    return explore_ct_views, views_slider


@app.cell(hide_code=True)
def _(explore_ct_views, views_slider):
    explore_ct_views(views_slider.value)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Choosing a view budget
    Your task is to recommend **the smallest number of equally spaced projection angles that gives an acceptable image**. Define "acceptable" using at least two criteria, for example:

    - a numerical threshold;
    - visibility of a chosen structure;
    - streak strength;
    - edge fidelity;
    - computational or dose considerations.

    The answer isn't simply the angle count with the smallest error; it should come from requirements you can justify. The views slider above is a quick way to see how the streaks change before you pick candidates.

    The cell below scans and reconstructs each candidate for you. You need to:

    1. choose which view counts to test (`candidate_counts`);
    2. turn two criteria into numbers: an error threshold `MAX_NRMSE` and a dose cap `MAX_DOSE`;
    3. write the **one line** that decides whether a scan is acceptable.

    The recommendation is then the fewest views that pass both criteria. If you also care about something visual (a structure you need to see, or how much streaking you can accept), mention it at checkoff.
    """)
    return


@app.cell(hide_code=True)
def _(Q10_hint_1, Q10_hint_2, mo):
    mo.vstack([Q10_hint_1, Q10_hint_2])
    return


@app.cell
def _(filtered_backproject, gallery, make_sinogram, np, nrmse, phantom):
    # Design workspace: scan and reconstruct each candidate, then apply YOUR criteria.
    candidate_counts = [24, 36, 45, 60, 90]

    MAX_NRMSE = ...   # TODO: maximum acceptable reconstruction error
    MAX_DOSE = ...    # TODO: dose cap relative to the 180-view scan

    ct_recs, ct_labels, acceptable_counts = [], [], []
    for _n in candidate_counts:
        _theta = np.linspace(0, 180, _n, endpoint=False)   # _n equally spaced views
        _rec = np.clip(filtered_backproject(make_sinogram(phantom, _theta), _theta, phantom.shape[0]), 0, 1)
        _err = nrmse(_rec, phantom)   # reconstruction error (lower is better)
        _dose = _n / 180              # dose, relative to a full 180-view scan

        # TODO: require both criteria to pass.
        # DELETE THE FOLLOWING LINE AND FILL IN THE CODE BELOW
        raise NotImplementedError()
        _ok = ...

        if _ok:
            acceptable_counts.append(_n)
        ct_recs.append(_rec)
        ct_labels.append(f"{_n} views ({_dose:.0%} dose)\nNRMSE={_err:.3f}: {'PASS' if _ok else 'fail'}")

    # your recommendation: the fewest views that pass both criteria
    recommendation = min(acceptable_counts) if acceptable_counts else None
    print(f"Recommendation: {recommendation} views" if recommendation
          else "No candidate passes both criteria. Loosen a threshold, or test other view counts.")
    gallery(ct_recs, ct_labels, cols=len(candidate_counts), figsize=(3.6 * len(candidate_counts), 4))
    return (recommendation,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='sec9'></a>
    ## <span style="color:navy">9. MRI and CT side by side</span>

    ### Your two designs
    Here is what you built in this lab. The top row is your Section 5 MRI design, and the bottom row is your Section 8 CT recommendation.
    """)
    return


@app.cell(hide_code=True)
def _(
    b_final,
    brain_img,
    filtered_backproject,
    final_mask,
    make_sinogram,
    mo,
    np,
    nrmse,
    phantom,
    plt,
    recommendation,
    recon_bpd_final,
):
    # MRI: zero-fill vs. your FSR + spiral + BPD, both from the same samples
    _zero_fill = np.abs(np.fft.ifft2(b_final, norm="ortho"))
    _mri_pct = 100 * final_mask.mean()

    # CT: the full 180-view scan vs. your recommendation
    def _fbp(n_views):
        _theta = np.linspace(0, 180, n_views, endpoint=False)
        return np.clip(filtered_backproject(make_sinogram(phantom, _theta), _theta, phantom.shape[0]), 0, 1)

    _ct_n = recommendation if isinstance(recommendation, (int, np.integer)) and recommendation > 0 else None
    _ct_full = _fbp(180)
    _ct_yours = _fbp(_ct_n) if _ct_n else np.zeros_like(phantom)

    _fig, _ax = plt.subplots(2, 3, figsize=(12, 8.5))
    _rows = [
        [(brain_img, "brain (ground truth)"),
         (_zero_fill, f"zero-fill, same {_mri_pct:.0f}% of k-space\nNRMSE={nrmse(_zero_fill, brain_img):.3f}"),
         (recon_bpd_final, f"YOUR design: FSR + spiral + BPD\nNRMSE={nrmse(recon_bpd_final, brain_img):.3f}")],
        [(phantom, "phantom (ground truth)"),
         (_ct_full, f"full scan, 180 views\nNRMSE={nrmse(_ct_full, phantom):.3f}"),
         (_ct_yours, f"YOUR recommendation: {_ct_n} views\nNRMSE={nrmse(_ct_yours, phantom):.3f}" if _ct_n
                     else "set your criteria in Section 8")],
    ]
    for _r, _row in enumerate(_rows):
        for _c, (_img, _title) in enumerate(_row):
            _ax[_r, _c].imshow(_img, cmap="gray", vmin=0, vmax=1)
            _ax[_r, _c].set_title(_title, fontweight="bold" if _c == 2 else "normal")
            _ax[_r, _c].axis("off")
    _ax[0, 0].text(-0.08, 0.5, "MRI", transform=_ax[0, 0].transAxes, fontsize=16, fontweight="bold", rotation=90, va="center", ha="right")
    _ax[1, 0].text(-0.08, 0.5, "CT", transform=_ax[1, 0].transAxes, fontsize=16, fontweight="bold", rotation=90, va="center", ha="right")
    plt.tight_layout()

    _ct_line = (f"the CT radiation dose by {100 * (1 - _ct_n / 180):.0f}% ({_ct_n} views instead of 180)"
                if _ct_n else "the CT dose (set your criteria in Section 8 to see by how much)")
    mo.vstack([
        _fig,
        mo.md(f"> You cut the MRI scan time by {100 - _mri_pct:.0f}% and {_ct_line}, and both images still look pretty good. "
              "Whether they're good enough depends on your Section 8 criteria for CT and the Section 5 goal for MRI."),
    ])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### The two modalities, compared

    | Question | MRI | CT |
    |---|---|---|
    | What is measured? | Spatial-frequency samples | Line-integral projections |
    | Data representation | k-space | Sinogram |
    | Image-domain measurement operator | $A=MF$ | $A$: discrete projection weights |
    | What is $x$? | image pixels (wavelet coefficients $c$ in BPD) | attenuation pixels |
    | Basic reconstruction | Inverse FFT | Filtered backprojection |
    | Limited acquisition artifact | Aliasing / coherent structure | Streaks / missing directions |
    | Primary practical constraint | Scan time and motion | Dose and acquisition time |

    Both systems fit the linear inverse-problem model

    $$\mathbf y=A\mathbf x+\mathbf n,$$

    but their operators $A$ encode different physics.

    **Check-in 9.1:** **what do MRI and CT have in common when reconstructing an image from fewer measurements?** Give one benefit and one consequence of collecting less data.
    """)
    return


@app.cell(hide_code=True)
def _(ct_forward, ct_matrix, ct_small, mo, mri_forward, np):
    _rng = np.random.default_rng(66)
    _mask = np.zeros(ct_small.shape, dtype=bool)
    _mask[::2, :] = True
    _mri_clean = mri_forward(ct_small, _mask)
    _ct_clean = ct_forward(ct_matrix, ct_small)
    _rows = []
    for _name, _clean in [("MRI (complex k-space)", _mri_clean), ("CT (line integrals)", _ct_clean)]:
        _n = _rng.standard_normal(_clean.shape)
        if np.iscomplexobj(_clean):
            _n = (_n + 1j * _rng.standard_normal(_clean.shape)) * np.fft.ifftshift(_mask)
        _n *= 0.02 * np.linalg.norm(_clean) / np.linalg.norm(_n)
        _y = _clean + _n
        _relative = np.linalg.norm(_y - _clean) / np.linalg.norm(_clean)
        _rows.append(f"| {_name} | {_relative:.1%} |")
    mo.accordion({"Optional: where does n enter?": mo.md(
        "So far we used noiseless measurements. This supplied example adds reproducible noise with norm 2% of the clean data norm: "
        "`y = A(x) + n`. Even the true image now has a nonzero measurement residual. "
        "MRI noise is complex and is added only where the mask acquires samples. "
        "CT noise here is an illustrative additive error **after** the log transform; it is not a simulation of photon counts. "
        "Noise in real log-transformed CT data need not have the same variance for every ray.\n\n"
        "| Measurements | Relative residual of the true image |\n|---|---|\n" + "\n".join(_rows) +
        "\n\nMissing samples change the operator; noise changes the acquired values. Reconstruction has to account for both."
    )})
    return


@app.cell(hide_code=True)
def _(answer_21, mo):
    mo.callout(answer_21, kind="info")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='checkoff'></a>
    ## Checkoff
    When you have finished both parts, fill out the **[checkoff Google form](https://forms.gle/pwqopqgEaHvv7GUk9)** and ask course staff for a checkoff. You (or your team) should be able to explain each design choice you made and the artifacts in your figures.

    Be ready to show:

    1. your 50% and 25% MRI mask designs, and the artifacts each one creates;
    2. why the FSR + spiral mask works best with BPD (coherent vs. incoherent artifacts);
    3. your CT view-budget criteria (your two thresholds) and the recommendation they lead to;
    4. one sinogram feature you can explain geometrically;
    5. one comparison between backprojection and filtered backprojection;
    6. your MRI measurement/zero-fill functions and why data agreement alone does not guarantee the right image;
    7. one row and one column of your CT matrix, and why its transpose is not an inverse.
    """)
    return


@app.cell(hide_code=True)
def _(
    b,
    babak_img,
    brain_img,
    build_ct_matrix,
    cs_mask,
    ct_forward,
    final_mask,
    make_A_and_AH,
    make_radial_mask,
    make_sampling_mask_rows,
    mo,
    mri_forward,
    mri_zero_fill,
    recon,
    recon_bpd_final,
    test_Q1a,
    test_Q1b,
    test_Q1c,
    test_Q3a,
    test_Q3b,
    test_Q5,
    test_Q6,
    test_Q6b,
    test_all_btn,
    truncate_fov_rows,
    x,
):
    if test_all_btn.value:
        with mo.status.spinner(title="Running all tests..."):
            test_Q1a(make_radial_mask)
            test_Q1b(make_sampling_mask_rows)
            test_Q1c(truncate_fov_rows)
            test_Q3a(make_A_and_AH)
            test_Q3b(b, x, recon, babak_img, cs_mask)
            test_Q5(final_mask, recon_bpd_final, brain_img)
            test_Q6(intensities_to_line_integrals)
            test_Q6b(build_ct_matrix, ct_forward)
    test_all_btn
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='feedback'></a>
    ## Feedback
    If you have any feedback to give the teaching staff about the labs (lab content, staff, etc), you can submit it through this Google form. Responses are **fully anonymous** and responses are actively monitored to improve the labs and course. Completing this form is **not required**.

    [Anonymous feedback Google form](https://forms.gle/ezDiDHxYRHN7xtdV9)

    *If you have a personal matter to discuss or need a response to your feedback, please contact <a href="mailto:ee66.lab@berkeley.edu">ee66.lab@berkeley.edu</a> and/or <a href="mailto:ee66@berkeley.edu">ee66@berkeley.edu</a>*.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## References

    [1] A. C. Kak and M. Slaney, *Principles of Computerized Tomographic Imaging*. SIAM, 2001 -- CT projection models, Radon transforms, and filtered backprojection.

    [2] E. M. Haacke et al., *Magnetic Resonance Imaging: Physical Principles and Sequence Design*. Wiley, 1999 -- MRI physical background and k-space concepts.

    [3] S. van der Walt et al., "scikit-image: Image processing in Python," *PeerJ* 2:e453, 2014 -- the educational Shepp-Logan phantom, Radon transform, and inverse Radon utilities used in this lab.

    [4] mridata.org, http://mridata.org/about -- source of the MRI data used in this lab.

    [5] M. Nickparvar, "Brain Tumor MRI Dataset," Kaggle, https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset/data -- source of the brain MRI image used in Section 5.

    [6] A. Beck and M. Teboulle, "A Fast Iterative Shrinkage-Thresholding Algorithm for Linear Inverse Problems," *SIAM J. Imaging Sciences*, 2(1), 2009 -- the FISTA algorithm implemented directly with numpy in `utils/wavelets.py` for Basis Pursuit Denoising (Sections 3 and 5), used instead of an external convex-optimization package.

    [7] UC Berkeley EE 120 MRI laboratory materials. EE 120's MRI lab was an inspiration, but this EE 66 lab uses newly written code, text, and figures.
    """)
    return


@app.cell(hide_code=True)
def _(mo):

    answer_mri_model = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_ct_matrix = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_ct_bp = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_1 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_3 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_4 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_5 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_6 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_7 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_11 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_13 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_16 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_17 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    answer_21 = mo.ui.text_area(placeholder="YOUR ANSWER HERE")
    test_Q1a_btn = mo.ui.run_button(label="Test Q1a: make_radial_mask")
    test_Q1b_btn = mo.ui.run_button(label="Test Q1b: make_sampling_mask_rows")
    test_Q1c_btn = mo.ui.run_button(label="Test Q1c: truncate_fov_rows")
    test_Q3a_btn = mo.ui.run_button(label="Test Q3a: make_A_and_AH")
    test_Q3b_btn = mo.ui.run_button(label="Test Q3b: BPD setup")
    test_Q5_btn = mo.ui.run_button(label="Test Q5: FSR + spiral design")
    test_Q6_btn = mo.ui.run_button(label="Test Q6: Beer-Lambert")
    test_Q6b_btn = mo.ui.run_button(label="Test Q6b: CT forward prediction")
    test_all_btn = mo.ui.run_button(label="Test All")
    Q1a_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": mo.md(r"`yy` and `xx` hold every pixel's row and column number. Subtracting the center, `(h / 2, w / 2)`, gives every pixel's vertical and horizontal offset from the center, all at once and with no loops.")}, lazy=False)
    )
    Q1a_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": mo.md(r"Combine the two offsets with the Pythagorean theorem to get each pixel's distance `r` from the center (`np.sqrt` works on whole arrays). Comparing an array with a number, like `r < radius`, gives a True/False array of the same shape.")}, lazy=False)
    )
    Q1b_hint_1 = mo.as_html(
        mo.accordion({"Hint": mo.md(r"Slices can take a step: `arr[::k]` picks every `k`-th entry. Select every `sample`-th row of `mask` (and all of its columns), and set that whole slice to `True` in one assignment.")}, lazy=False)
    )
    Q1c_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": mo.md(r"Skipping rows shrinks the field of view to `n // sample` rows, so that's how many rows to keep.")}, lazy=False)
    )
    Q1c_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": mo.md(r"To center the band, split the leftover rows (`n - keep`) evenly above and below it. Then copy that block of rows from `img` into `out`, using the same row slice on both sides.")}, lazy=False)
    )
    Q2a_hint_1 = mo.as_html(
        mo.accordion({"Hint #1 (design)": mo.md(r"Look at two things. (1) Which direction is the calf's k-space energy stacked in? That tells you whether to keep whole rows or whole columns. (2) Where does the calf have empty space around it? Skipping lines puts a ghost copy half an image away, in the direction you skipped.")}, lazy=False)
    )
    Q2a_hint_2 = mo.as_html(
        mo.accordion({"Hint #2 (code)": mo.md(r"`mask[:, j]` is column `j` and `mask[i, :]` is row `i`, and a step like `::2` picks every other one, so your whole mask can be a single slice assignment.")}, lazy=False)
    )
    Q2b_hint_1 = mo.as_html(
        mo.accordion({"Hint #1 (design)": mo.md(r"Start from your 50% mask. You can halve the budget again by spacing the lines further apart (more ghost copies) or by keeping the same spacing over a narrower band around the center (less resolution). Which one can this calf image handle?")}, lazy=False)
    )
    Q2b_hint_2 = mo.as_html(
        mo.accordion({"Hint #2 (code)": mo.md(r"A band of `n` columns centered on column `w // 2` starts at column `w // 2 - n // 2`. A slice like `mask[:, start:stop:step] = True` sets every `step`-th column in that range.")}, lazy=False)
    )
    Q3b_hint_1 = mo.as_html(
        mo.accordion({"Hint #1: prepare the measurements and operators": mo.md(r"""
        The first two lines can be written exactly as follows:

        ```python
        b = np.fft.ifftshift(cs_ksp_masked)
        A, AH = make_A_and_AH(babak_img.shape, cs_mask)
        ```

        `cs_ksp_masked` already contains the measured samples. `ifftshift` moves them from the centered display layout to the layout expected by `A`. Pass the original centered `cs_mask` to `make_A_and_AH`; that function handles shifting the mask internally.
        """)}, lazy=False)
    )
    Q3b_hint_2 = mo.as_html(
        mo.accordion({"Hint #2: almost-complete reconstruction code": mo.md(r"""
        After the two lines in Hint #1, use:

        ```python
        x = bpd(b, A, AH, babak_img.shape)
        recon = np.abs(haar2_inverse(..., level=3))
        ```

        Replace `...` with `x`, the wavelet coefficients returned by `bpd`. `haar2_inverse` converts those coefficients to image pixels, and `np.abs` gives the magnitude image for display.

        Together, these two hints give the four lines for the TODO. Delete the marked `raise NotImplementedError()` line, replace the four placeholder assignments, and keep the setup and plotting code. Complete Q3a first so `make_A_and_AH` works, then run Test Q3b.
        """)}, lazy=False)
    )
    Q5_hint_1 = mo.as_html(
        mo.accordion({"Hint #1: the complete FSR + spiral mask": mo.md(r"""
        Keep `fsr_radius = 40`, `n_turns = 8`, and `thickness = 1.5` for your first attempt. Use those parameters to fill in `final_mask`:

        ```python
        final_mask = (
            make_radial_mask(brain_img.shape, fsr_radius)
            | make_spiral_trajectory_mask(
                brain_img.shape, n_turns=n_turns, thickness=thickness
            )
        )
        ```

        `|` means elementwise OR: keep a k-space location if it belongs to the fully sampled center disk OR the spiral. Both masks use the same centered layout. The next hint supplies the reconstruction steps.
        """)}, lazy=False)
    )
    Q5_hint_2 = mo.as_html(
        mo.accordion({"Hint #2: almost-complete BPD reconstruction": mo.md(r"""
        After `final_mask`, use the following code. The extra `_ksp` line computes the centered, normalized k-space that you will sample:

        ```python
        _ksp = np.fft.fftshift(np.fft.fft2(brain_img, norm="ortho"))
        b_final = np.fft.ifftshift(_ksp * final_mask)
        A_final, AH_final = make_A_and_AH(brain_img.shape, final_mask)
        x_final = bpd(
            b_final, A_final, AH_final, brain_img.shape,
            thresh=0.001, niter=200,
        )
        recon_bpd_final = np.abs(haar2_inverse(..., level=3))
        ```

        Replace the only `...` above with `x_final`, the wavelet coefficients from the solver. This is Q3b's pipeline with `brain_img` and `final_mask`: compute k-space, mask it, undo the shift, build the operators, solve, and convert coefficients back to an image.

        Use `norm="ortho"` here even though the earlier brain k-space display did not need it: the measurements must match the normalization inside `A_final`. Delete the marked `raise NotImplementedError()` line and replace the placeholder assignments with the code from these two hints. Complete Q1a and Q3a first, then run Test Q5.
        """)}, lazy=False)
    )
    Q6_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": mo.md(r"Start from $I = I_0 e^{-p}$, where $p$ is the line integral you want. Solve for $p$: divide both sides by $I_0$, then take the natural log of both sides.")}, lazy=False)
    )
    Q6_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": mo.md(r"In NumPy the natural log is `np.log` (not `np.log10`), and it works on whole arrays at once. Watch the sign. Since $I \le I_0$, $\ln(I/I_0)$ is negative, but attenuation is positive.")}, lazy=False)
    )
    Q10_hint_1 = mo.as_html(
        mo.accordion({"Hint #1 (choosing thresholds)": mo.md(r"There's no single right answer, but you need to be able to defend yours. For `MAX_NRMSE`, look at the gallery (and the views slider earlier in Section 8), find the point where the streaks stop bothering you, and read off its NRMSE. For `MAX_DOSE`, pick the largest fraction of a full scan you'd be comfortable giving a patient, for example 0.5 for half the dose.")}, lazy=False)
    )
    Q10_hint_2 = mo.as_html(
        mo.accordion({"Hint #2 (the code)": mo.md(r"A scan passes only if its error is at most `MAX_NRMSE` and its dose is at most `MAX_DOSE`. Python's `and` combines two comparisons into a single True/False value.")}, lazy=False)
    )
    Q3a_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": mo.md(r"Follow the block diagram. The blocks act on the coefficient array $c$ (called `x` in the code) in the order $W^{-1}$, then $F$, then $M$, so read $A = MFW^{-1}$ from right to left, with one line of code per block.")}, lazy=False)
    )
    Q3a_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": mo.md(r"$W^{-1}$ is `haar2_inverse` (pass `level=level`), $F$ is `np.fft.fft2` (pass `norm='ortho'`), and $M$ is multiplying by `shifted_mask`, which already lines up with the output of `np.fft.fft2`. `AH` below runs the same steps backwards, if you want a pattern to follow.")}, lazy=False)
    )
    return (
        Q10_hint_1,
        Q10_hint_2,
        Q1a_hint_1,
        Q1a_hint_2,
        Q1b_hint_1,
        Q1c_hint_1,
        Q1c_hint_2,
        Q2a_hint_1,
        Q2a_hint_2,
        Q2b_hint_1,
        Q2b_hint_2,
        Q3a_hint_1,
        Q3a_hint_2,
        Q3b_hint_1,
        Q3b_hint_2,
        Q5_hint_1,
        Q5_hint_2,
        Q6_hint_1,
        Q6_hint_2,
        answer_1,
        answer_11,
        answer_13,
        answer_16,
        answer_17,
        answer_21,
        answer_3,
        answer_4,
        answer_5,
        answer_6,
        answer_7,
        answer_ct_bp,
        answer_ct_matrix,
        answer_mri_model,
        test_Q1a_btn,
        test_Q1b_btn,
        test_Q1c_btn,
        test_Q3a_btn,
        test_Q3b_btn,
        test_Q5_btn,
        test_Q6_btn,
        test_Q6b_btn,
        test_all_btn,
    )


@app.cell(hide_code=True)
def _():
    import marimo as mo

    return (mo,)


if __name__ == "__main__":
    app.run()

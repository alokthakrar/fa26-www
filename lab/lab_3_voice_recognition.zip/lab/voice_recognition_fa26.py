import marimo

__generated_with = "0.17.6"
app = marimo.App(width="medium")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Voice Recognition: SVD/PCA Classification

    ### EE 66: Introduction to Signals, Dynamics, and Information, Fall 2026


    - **Fall 2024:** Junha Kim, Jessica Fan, Savit Bhat, Jack Kang
    - **Spring 2025:** Sonia Chacon
    - **Fall 2025:** Andrew Song
    - **Fall 2026:** Baris Oktay

    This lab was heavily inspired by previous EECS16B (now EE 64) lab 8, written by Nathaniel Mailoa, Emily Naviasky, et al.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Voice Recognition: SVD/PCA

    * [Task 1: Data Collection](#part1)
    * [Task 2: Data Preprocessing](#part2)
    * [Task 3: PCA via SVD](#task3)
    * [Task 4: Clustering Data Points](#task4)
    * [Task 5: Testing your Classifier](#task5)
    * [Task 6: Live Testing](#task6)
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='intro'></a>
    ## <span style="color:navy">Introduction</span>

    Throughout lectures and discussion, you have learned theoretical concepts of the DFT and SVD. In this voice recognition lab, we'll be applying these concepts from class to build an audio classifier using Principal Component Analysis (PCA), an application of the Singular Value Decomposition (SVD).

    This lab takes in voice recordings, sampling the waveform of an analog signal into discrete points. Multiple syllables will generate multiple peaks and troughs, and soft syllables will have discrete points of lower magnitude than hard syllables (eg. words like "here" and "pear" will have very similar voice recordings)

    In this lab, you will build a voice classifier for words of different syllables and intonation. We will explore dimensionality reduction and classification of voice signals using PCA.

    ### How this lab works (marimo)

    - This lab is a **marimo** notebook. Cells re-run **automatically** whenever something they depend on changes (for example, moving a slider), so you do not need to press Shift+Enter.
    - Until you fill in a `...  # YOUR CODE HERE` placeholder, cells that use it will show an error (such as a `NotImplementedError` or a shape error). This is expected: fill in the code and the cells below will update.

    /// warning | Do not add `print` statements inside your functions or loops
    Because cells re-run automatically, extra `print` statements (especially inside `align_recording`, `classify`, or any loop over the recordings) will print thousands of lines and **significantly slow down your code**. Remove any debugging prints once you are done with them.
    ///
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Overview of Classification Procedure
    Below is an overview of the classification procedure we will be following in this lab.
    1. Collect recordings of different words. This will form our data set. (We provide four words; recording a fifth word of your own is **optional**.)
    2. Split the data into 2 sets: training and testing data
    3. Preprocess the data to align the words.
    4. Perform SVD and evaluate on the training data split.
    5. Classify each word using clustering in the PCA basis.
    6. Evaluate performance of your PCA model by running the model on testing data.
    7. Make sure you (and the lab staff) are satisfied with the classifier's accuracy.

    ### Side Note: Datasets in Machine Learning Applications
    It is common practice in machine learning applications to split a dataset into a training set and testing set (some common ratios for train:test are 80:20 or 70:30). In this lab, we will split 70:30.
    """)
    return


@app.cell
def _():
    from IPython import display
    import numpy as np
    import csv
    import time
    import matplotlib.pyplot as plt
    import utils
    from mpl_toolkits.mplot3d import Axes3D
    cm = ['blue', 'red', 'green', 'orange', 'black', 'purple']
    # '%matplotlib inline' command supported automatically in marimo
    return Axes3D, cm, csv, display, np, plt, time, utils


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part1'></a>
    ## <span style="color:navy">Task 1: Data Collection</span>

    We will begin by collecting our data. We provide recordings of 4 words (`jack`, `jason`, `jessica`, `entanglement`) for the sake of time, so you do **not** need to record anything to complete this lab.

    /// note | Optional: record a fifth word
    If you would like to, you may record a set of 40 recordings for one additional word of your choosing and add it to the classifier. **This is entirely optional.** If you skip it, go straight to [Task 2](#part2).
    ///

    When humans distinguish words, they listen for temporal and frequency differences to determine what is being said. Let's keep that in mind when we choose our words.

    When you think of speech signals, you might notice that each word or sound has a distinctive shape. Taking the shape of the magnitude of a signal is called enveloping. We want to do some filtering to retrieve the envelope of the audio signal, which we will use for calculating the SVD.

    **If you choose to record your own word, brainstorm one word for your recordings.**
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    import base64 as _base64
    try:
        _png = (mo.notebook_dir() / "clippingsignal.png").read_bytes()
        clipping_img = (
            '<img src="data:image/png;base64,'
            + _base64.b64encode(_png).decode()
            + '" alt="Example of a clipping (railing) audio signal" width="600">'
        )
    except Exception:
        clipping_img = "*(Could not load `clippingsignal.png`. Make sure it is in the same folder as this lab.)*"
    mo.md(f"""
    ### Voice Recordings (Optional)

    /// note | This section is optional
    You only need to do this section if you want to add your own fifth word. Otherwise, skip to Task 2.
    ///

    If you want to add your own word, you will record **40** audio samples for it. We recommend that you split the recording between partners to maximize variance between the recorded signals. For each word, make sure to note who said it and how it was said (like through a video/audio recording on your phone) so that it is easier to reproduce later for live classification.

    Please read the full instructions for these tasks before proceeding.
    **For each chosen word, do the following:**
    1. Click the **Start Recording** button below and enter a file name
        - A text box will ask for a filename for your CSV recording. This file preserves your recordings outside the temporary session state, so you can reuse them after a break or after restarting marimo.
        - We recommend naming your csv file to: `YOUR_WORD.csv`
    2. Begin Recording. Each time you press enter, say your word once within the 3 second interval.
        - **Pronounce the word consistently**
        - "Good" audio data has a high signal to noise ratio (SNR). Recording words while far away from the microphone may cause your intended word to blend in with background noise. However, speaking too loudly and/or too closely into the mic) may also cause your output to rail. Here's what a railing (clipping) audio signal may look like:

        {clipping_img}

        - You can see that this signal is utilizing almost the maximum magnitude of signal allowed in this audio file format for the majority of the duration. When an audio signal is too loud, its magnitude will exceed the maximum allowed value and "rail" to that value. We don't want this--please re-record further away from your mic if this happens.
        - **We recommend that after taking 3 or 4 recordings for the first time, stop the recording by entering "stop" in the text box and check `YOUR_WORD.csv` make sure that it looks like a sound wave as opposed to being full of super low values. *It might help to graph the data as a line plot in Excel.*** You don't want to record 40 times only to find that your recordings weren't working.
        - Type "d" to delete the most recent recording
        - Repeat to make 40 recordings of your word.

    ### Before moving on, please note that:

    You may realize in the next section that one or two of your words are not sorting quite as well as you would like. Don't be afraid to come back to this section and try collecting different words based on what you have learned makes a word sortable.
    """)
    return


@app.cell(hide_code=True)
def _(mo, record_button):
    mo.md(f"""
    **(Optional)** Click the button below to start recording your own word <br>
    {mo.as_html(record_button)}
    """)
    return


@app.cell
def _(create_recording_csv, record_button):
    # run the recording script
    if record_button.value:
        create_recording_csv()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='part2'></a>
    ## <span style="color:navy">Task 2: Data Preprocessing</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Different recordings of the same word can look wildly different, depending on factors like when you started saying the word and how quickly you said it (assuming you are not a robot that can repeat the word 40 times exactly the same way). Thus, before we can use the recorded data for PCA, we must first process the data. We will do this according to the following procedure:
    1. Split the dataset into a training dataset and a test dataset
    2. Align the audio recordings
    3. Apply an envelope (low pass filter) to the recordings to remove irrelevant high-frequency components
    """)
    return


@app.cell
def _():
    # OPTIONAL: if you recorded your own word, add it to the end of this list
    # (e.g. 'myword' if your file is myword.csv). Otherwise leave the list as is.
    word_set = ['jack', 'jason', 'jessica', 'entanglement']
    return (word_set,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Task 2a: Split the Data
    Let's begin by splitting our data into a training and testing set with a 70/30 split. The code below does this for you automatically; read through it to make sure you understand what it does.
    """)
    return


@app.cell
def _(word_set, np, utils):
    train_test_split_ratio = 0.7
    train_dict = {}
    test_dict = {}
    for _i in range(len(word_set)):
        word_raw = utils.read_csv('{}.csv'.format(word_set[_i]))
        (_word_raw_train, _word_raw_test) = utils.train_test_split(word_raw, train_test_split_ratio)
        train_dict[word_set[_i]] = _word_raw_train
        test_dict[word_set[_i]] = _word_raw_test
    num_samples_train = min(list(map(lambda x: np.shape(x)[0], train_dict.values())))
    num_samples_test = min(list(map(lambda x: np.shape(x)[0], test_dict.values())))
    for (key, raw_word) in train_dict.items():
        train_dict[key] = raw_word[:num_samples_train, :]
    for (key, raw_word) in test_dict.items():
        test_dict[key] = raw_word[:num_samples_test, :]
    return num_samples_test, num_samples_train, test_dict, train_dict


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Let's take a look at all the training samples.

    /// attention | Important
    It's okay if the recordings aren't aligned. The code in the next part will align the data.
    ///
    """)
    return


@app.cell
def _(plt, train_dict, word_set):
    _word_number = 0
    for _word_raw_train in train_dict.values():
        plt.plot(_word_raw_train.T)
        plt.title('Training sample for "{}"'.format(word_set[_word_number]))
        _word_number = _word_number + 1
        plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Task 2b: Align Audio Recordings

    As seen above, the speech is a fraction of the 3 second window, and each sample starts at different times. PCA is not good at interpreting delay, so we need to align the recordings and trim to a smaller segment of the sample where the speech is present. To do this, we will use a thresholding algorithm.

    First, we define a **`threshold`** relative to the maximum value of the data. We say that any signal that crosses the threshold is the start of a speech command. In order to not lose the first couple samples of the speech command, we say that the command starts **`pre_length`** samples _before_ the threshold is crossed. We then use a window of the data that is **`length`** long, and try to capture the entire command in that window.

    /// warning | Reminder
    Do not add `print` statements inside `align_recording`; it is called once for every recording, so prints will flood the output and slow everything down.
    ///

    **Play around with the parameters `length`, `pre_length` and `threshold`** in the cells below to find appropriate values corresponding to your voice and chosen commands. You should see the results and how much of your command you captured in the plots generated below.

    We also pass in a `envelope=True` argument to our `process_data` function: this filters out the frequencies higher than our vocal range, to get back an "envelope" of the waveform of our voice recordings. Why might this be useful?

    Also note that we're "normalizing" the signal towards the end--this is very common in a lot of signal processing applications; another name for this is "min-max feature scaling," where we rescale the amplitude range of the signal to be in $[0,1]$ by dividing the signal by the maximum absolute value. This is different from taking a norm of a vector as we've seen in class.
    """)
    return


@app.cell
def _(np, utils):
    def align_recording(recording, length, pre_length, threshold, envelope=False):
        """
        align a single audio samples according to the given parameters.

        Args:
            recording (np.ndarray): a single audio sample.
            length (int): The length of each aligned audio snippet.
            pre_length (int): The number of samples to include before the threshold is first crossed.
            threshold (float): Used to find the start of the speech command. The speech command begins where the
                magnitude of the audio sample is greater than (threshold * max(samples)).
            envelope (bool): if True, use enveloping.

        Returns:
            aligned recording.
        """

        if envelope:
            recording = utils.envelope(recording, 5400, 100)

        # Find the threshold
        recording_threshold = threshold * np.max(recording)

        # TODO: Use recording_threshold, length, and prelength to cut the snippet to the correct length
        # we note where the recording magnitude first exceeds recording_threshold.
        # then, we leave prelength number of samples before the crossing of the threshold, which is where our recording starts.
        # we cut the recording so that it's 'length' samples away from the start of the recording.

        i = pre_length
        while False:  # YOUR CODE HERE: replace `False` with a condition that keeps looping until the recording crosses recording_threshold
            i += 1

        snippet_start = np.clip(i - pre_length, a_min=0, a_max=len(recording) - length)
        snippet = recording[ ... ] # YOUR CODE HERE

        # TODO: Normalize the recording.
        # "Normalize" in our case is dividing the signal by the maximum absolute value (different from taking the norm of a vector)
        snippet_normalized = ... # YOUR CODE HERE

        return snippet_normalized
    return (align_recording,)


@app.cell
def _(align_recording, np):
    def align_data(data, length, pre_length, threshold, envelope=False):
        """
        align all audio samples in dataset. (apply align_recording to all rows of the 
        data matrix)

        Args:
            data (np.ndarray): Matrix where each row corresponds to a recording's 
                               audio samples.

            length (int): The length of each aligned audio snippet.

            pre_length (int): The number of samples to include before the threshold 
                              is first crossed.

            threshold (float): Used to find the start of the speech command. The 
                               speech command begins where the magnitude of the 
                               audio sample is greater than (threshold * max(samples)).

        Returns:
            Matrix of aligned recordings.
        """
        assert isinstance(data, np.ndarray) and len(data.shape) == 2, "'data' must be a 2D matrix"
        assert isinstance(length, int) and length > 0, "'length' of snippet must be an integer greater than 0"
        assert 0 <= threshold <= 1, "'threshold' must be between 0 and 1"
        snippets = []

        # Iterate over the rows in data
        for recording in data:
            snippets.append(align_recording(recording, length, pre_length, threshold, envelope))

        return np.vstack(snippets)
    return (align_data,)


@app.cell
def _(align_data, plt, word_set):
    def process_data(dict_raw, length, pre_length, threshold, plot=True, envelope=False):
        """
        Process the raw data given parameters and return it. (wrapper function for align_data)

        Args:
            dict_raw (np.ndarray): dictionary of all words: data matrix.
            length (int): The length of each aligned audio snippet.
            pre_length (int): The number of samples to include before the threshold is first crossed.
            threshold (float): Used to find the start of the speech command. The speech command begins where the
                               magnitude of the audio sample is greater than (threshold * max(samples)).
            plot (boolean): Plot the dataset if true.
            envelope (boolean): Apply the envelope to each recording if true.

        Returns:
            Processed data dictionary.
        """
        processed_dict = {}
        _word_number = 0
        for (key, word_raw) in dict_raw.items():
            word_processed = align_data(word_raw, length, pre_length, threshold, envelope=envelope)
            processed_dict[key] = word_processed
            if plot:
                plt.plot(word_processed.T)
                plt.title('Samples for "{}"'.format(word_set[_word_number]))
                _word_number = _word_number + 1
                plt.show()
        return processed_dict
    return (process_data,)


@app.cell(hide_code=True)
def _(mo):
    mo.md("""
    ### Select Parameters

    Play around with different values for length, pre-length, and threshold for the data from the spoken word "Jack". The current value of each parameter is shown next to its control. Notice how the alignment of the samples changes for different parameter values. The goal is to align the samples so the lines in the graphs are similar. Can you tell what word is being spoken?
    """)
    return


@app.cell(hide_code=True)
def _(length_slider, mo, pre_length_slider, threshold_radio):
    mo.hstack([length_slider, pre_length_slider, threshold_radio])
    return


@app.cell(hide_code=True)
def _(length_slider, pre_length_slider, threshold_radio):
    # Plain-number versions of the controls above. These update automatically when you
    # move a slider, so below you can just use `length`, `pre_length`, and `threshold`
    # directly (no `.value` needed).
    length = length_slider.value
    pre_length = pre_length_slider.value
    threshold = threshold_radio.value
    return length, pre_length, threshold


@app.cell
def _(jack_data, length, pre_length, process_data, threshold):
    process_data(jack_data, length, pre_length, threshold, envelope=True)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Now, see how the values you chose affect the other words.
    """)
    return


@app.cell
def _(length, pre_length, process_data, threshold, train_dict):
    processed_train_dict = process_data(train_dict, length, pre_length, threshold, envelope=True)
    return (processed_train_dict,)


@app.cell(hide_code=True)
def _(mo, parameter_answer):
    mo.md(f"""
    What values did you choose for length, pre-length, and threshold? What made this combination the best set of parameters?<br><br>{mo.as_html(parameter_answer)}
    """)
    return


@app.cell(hide_code=True)
def _(alignment_answer, mo):
    mo.md(f"""
    **Conceptual question:** Why is alignment (with the function `align_recording`) necessary before applying PCA? What happens if the audio snippets aren't aligned?<br><br>{mo.as_html(alignment_answer)}
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task3'></a>
    ## <span style="color:navy">Task 3: PCA via SVD</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### SVD/PCA Resources
    - https://www.ams.org/publicoutreach/feature-column/fcarc-svd
    - https://stats.stackexchange.com/questions/2691/making-sense-of-principal-component-analysis-eigenvectors-eigenvalues
    - https://scikit-learn.org/stable/modules/decomposition.html#pca
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Task 3a: Generate and Preprocess PCA Matrix

    Now that we have our aligned data, we will build the PCA input matrix from that data by stacking all the data vertically.
    """)
    return


@app.cell
def _(np, processed_train_dict):
    processed_A = np.vstack(list(processed_train_dict.values()))
    return (processed_A,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The first step of PCA is to center the data's mean at zero and store it in demeaned_A. Please note that you want to get the mean of each feature (what are the features?). The function np.mean might be helpful here, along with specifying the axis parameter.

    /// tip | Hint: which axis?
    Each **row** of `processed_A` is one recording, and each **column** is one feature (one time index). To get the mean of each feature, you average **across recordings (down the rows)**, which is `axis=0`. Averaging with `axis=1` would instead average over time within each recording, which is not what we want. `mean_vec` should have one entry per feature, so its shape should be `(length,)`.
    ///
    """)
    return


@app.cell
def _(np, processed_A):
    # Zero-mean the matrix A
    # mean_vec should have shape (length,): one mean per feature (column), taken across recordings
    mean_vec = ...  # YOUR CODE HERE
    # subtract the mean from every row of processed_A
    demeaned_A = ...  # YOUR CODE HERE
    print(processed_A.shape)
    print(mean_vec.shape)
    return demeaned_A, mean_vec


@app.cell(hide_code=True)
def _(mo, svd_hint):
    mo.md(rf"""
    ### Task 3b: PCA

    Take the SVD of your demeaned data, $A = U \Sigma V^T$. Here $A$ is `demeaned_A`, with one recording per row and one feature (time index) per column. Each term has a meaning:

    - $U$: its columns are the *left singular vectors*. They live in "recording space" (one entry per recording) and describe how strongly each recording expresses each pattern.
    - $\Sigma$: a diagonal matrix of *singular values* $\sigma_1 \geq \sigma_2 \geq \dots \geq 0$. A large $\sigma_i$ means the $i$-th pattern accounts for a lot of the variation in the data. NumPy returns these as a 1D array `S`, not a matrix.
    - $V^T$: its **rows** are the *right singular vectors* (the principal components). They live in "feature space" (each has one entry per time index, so length `length`) and are the directions along which the data varies the most. NumPy returns `Vt` (already transposed), not `V`.

    {svd_hint}
    """)
    return


@app.cell
def _(demeaned_A, np):
    # Take the SVD of matrix demeaned_A
    U, S, Vt = ...  # YOUR CODE HERE
    return S, Vt


@app.cell(hide_code=True)
def _(mo, stem_hint):
    mo.md(f"""
    <div>Visually inspect your sigma values. They should tell you how many principal components you need.<br>{stem_hint}</div>
    """)
    return


@app.cell
def _(S, plt):
    # Plot out the sigma values (the singular values) as a stem plot
    plt.stem(...)  # YOUR CODE HERE: what should be plotted? (see the hint above)
    plt.title("Singular values")
    plt.xlabel("Index $i$")
    plt.ylabel("Singular value $\\sigma_i$")
    plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Task 3c: Choosing a Basis using Principal Components
    """)
    return


@app.cell(hide_code=True)
def _(PCA_comp_num_slider, mo, proj_eq, proj_hint_1, proj_hint_2, proj_hint_3):
    mo.md(f"""
    Set the `new_basis` argument to be a basis of the first **PCA_comp_num** principal components. Use the slider below to choose `PCA_comp_num` (it starts at 3; you will come back to experiment with it in Task 5).

    {mo.as_html(PCA_comp_num_slider)}

    Sanity check: When you plot `new_basis`, you should see one line for each principal component you've chosen. With three components, you should have three differently colored components, each with the `length` selected above.
    **NOTE: The projection onto a subspace with orthogonal basis vectors (i.e. a matrix with orthogonal columns) reduces to an inner product:**

    {proj_eq}

    Refer to [EECS 16B (now EE 64) Note 13: Orthonormalization](https://eecs16b.org/notes/sp24/note13.pdf) for a proof of this.

    {proj_hint_1}
    {proj_hint_2}
    {proj_hint_3}
    """)
    return


@app.cell
def _(PCA_comp_num_slider, Vt, plt):
    # Plot the principal component(s)
    PCA_comp_num = PCA_comp_num_slider.value  # set by the slider above (3 by default)
    # new_basis should have shape (length, PCA_comp_num): one column per principal component.
    # Use the variable PCA_comp_num here (do NOT hardcode 3), otherwise the slider will not change anything!
    new_basis = ...  # YOUR CODE HERE
    # Sanity check: new_basis must follow the slider. If this fails, you hardcoded the number of components.
    assert new_basis.shape[1] == PCA_comp_num, (
        f"new_basis has {new_basis.shape[1]} columns but the slider is set to PCA_comp_num={PCA_comp_num}. "
        "Use PCA_comp_num (do NOT hardcode 3), e.g. Vt[:PCA_comp_num, :]."
    )
    print(new_basis.shape)
    plt.plot(new_basis)
    plt.show()
    return (new_basis,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Now project the data in the matrix A onto the new basis and plot it. For three principal components, in addition to the 3D plot, we also provided 2D plots which correspond to the top and side views of the 3D plot. Do you see clustering? Do you think you can separate the data easily?
    """)
    return


@app.cell
def _(
    Axes3D,
    word_set,
    cm,
    demeaned_A,
    new_basis,
    np,
    num_samples_train,
    plt,
):
    # Project the demeaned data onto the new basis. proj should have shape (num recordings, PCA_comp_num)
    proj = ...  # YOUR CODE HERE
    if new_basis.shape[1] == 3:
        _fig = plt.figure(figsize=(10, 5))
        _ax = _fig.add_subplot(111, projection='3d')
        for _i in range(len(word_set)):
            Axes3D.scatter(_ax, *proj[_i * num_samples_train:num_samples_train * (_i + 1)].T, c=cm[_i], marker='o', s=20)
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1.07, 0.5))
        (_fig, _axs) = plt.subplots(1, 3, figsize=(15, 5))
        for _i in range(len(word_set)):
            _axs[0].scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 0], proj[_i * num_samples_train:num_samples_train * (_i + 1), 1], c=cm[_i], edgecolor='none')
            _axs[1].scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 0], proj[_i * num_samples_train:num_samples_train * (_i + 1), 2], c=cm[_i], edgecolor='none')
            _axs[2].scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 1], proj[_i * num_samples_train:num_samples_train * (_i + 1), 2], c=cm[_i], edgecolor='none')
        _axs[0].set_title('View 1')
        _axs[1].set_title('View 2')
        _axs[2].set_title('View 3')
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1, 0.5))
        plt.show()
    elif new_basis.shape[1] == 2:
        _fig = plt.figure(figsize=(10, 5))
        for _i in range(len(word_set)):
            plt.scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 0], proj[_i * num_samples_train:num_samples_train * (_i + 1), 1], edgecolor='none')
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1, 0.5))
        plt.show()
    return (proj,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Like in many AI applications, the data above are noisy, so we expect some classification errors. The important part is that you see strong clustering of your words.

    If you don't see clustering, try to think about why this might be the case. Things you might want to ask yourself:
    - How does PCA create the clusters?
    - Which characteristics of your waveform will PCA favor when clustering?
    - How can you choose your words to maximize the differences between the classes?

    Once you think you have decent clustering, move on to automating classification. **Make sure all of your words form distinct clusters. You will be using these words for the rest of this lab.**
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task4'></a>
    ## <span style="color:navy">Task 4: Clustering Data Points</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    #### Implement `find_centroids`, which finds the center of each cluster.
    """)
    return


@app.cell
def _(np):
    def find_centroid(clustered_data):
        """Find the center of each cluster by taking the mean of all points in a cluster.
        It may be helpful to recall how you constructed the data matrix (e.g. which rows correspond to which word)

        Parameters:
            clustered_data (np.array): the data already projected onto the new basis (for one word)

        Returns: 
            centroids (list): The centroids of the clusters
        """

        # Hint: each row of clustered_data is one projected recording of the same word.
        # The centroid is the mean of those rows (think about which axis to average over).
        centroid = ...  # YOUR CODE HERE
        return centroid
    return (find_centroid,)


@app.cell
def _(word_set, find_centroid, num_samples_train, proj):
    centroids = []
    for _i in range(len(word_set)):
        _centroid = find_centroid(proj[_i * num_samples_train:(_i + 1) * num_samples_train])
        centroids.append(_centroid)
    print(centroids)
    return (centroids,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    The cell below plots your centroids along with your projected data.
    """)
    return


@app.cell(hide_code=True)
def _(
    Axes3D,
    word_set,
    centroids,
    cm,
    new_basis,
    np,
    num_samples_train,
    plt,
    proj,
):
    centroid_list = np.vstack(centroids)
    colors = cm[:len(centroids)]
    for (_i, _centroid) in enumerate(centroid_list):
        print('Centroid {} is at: {}'.format(_i, str(_centroid)))
    if new_basis.shape[1] == 3:
        _fig = plt.figure(figsize=(10, 7))
        _ax = _fig.add_subplot(111, projection='3d')
        for _i in range(len(word_set)):
            Axes3D.scatter(_ax, *proj[_i * num_samples_train:num_samples_train * (_i + 1)].T, c=cm[_i], marker='o', s=20)
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1.07, 0.5))
        for _i in range(len(word_set)):
            Axes3D.scatter(_ax, *np.array([centroids[_i]]).T, c=cm[_i], marker='*', s=300)
        plt.title('Training Data')
        (_fig, _axs) = plt.subplots(1, 3, figsize=(15, 5))
        for _i in range(len(word_set)):
            _axs[0].scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 0], proj[_i * num_samples_train:num_samples_train * (_i + 1), 1], c=cm[_i], edgecolor='none')
            _axs[1].scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 0], proj[_i * num_samples_train:num_samples_train * (_i + 1), 2], c=cm[_i], edgecolor='none')
            _axs[2].scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 1], proj[_i * num_samples_train:num_samples_train * (_i + 1), 2], c=cm[_i], edgecolor='none')
        _axs[0].set_title('View 1')
        _axs[1].set_title('View 2')
        _axs[2].set_title('View 3')
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1, 0.5))
        _axs[0].scatter(centroid_list[:, 0], centroid_list[:, 1], c=colors, marker='*', s=300)
        _axs[1].scatter(centroid_list[:, 0], centroid_list[:, 2], c=colors, marker='*', s=300)
        _axs[2].scatter(centroid_list[:, 1], centroid_list[:, 2], c=colors, marker='*', s=300)
        plt.show()
    elif new_basis.shape[1] == 2:
        _fig = plt.figure(figsize=(10, 7))
        for _i in range(len(word_set)):
            plt.scatter(proj[_i * num_samples_train:num_samples_train * (_i + 1), 0], proj[_i * num_samples_train:num_samples_train * (_i + 1), 1], c=colors[_i], edgecolor='none')
        plt.scatter(centroid_list[:, 0], centroid_list[:, 1], c=colors, marker='*', s=300)
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1, 0.5))
        plt.title('Training Data')
        plt.show()
    return centroid_list, colors


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task5'></a>
    ## <span style="color:navy">Task 5: Testing your Classifier</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Great! Now that we have the mean (centroid) for each word, let's evaluate performance. Recall that we classify each data point according to the centroid with the smallest Euclidean distance from it.

    Before we perform classification, we need to do the same preprocessing to the test data that we did to the training data (enveloping, demeaning, projecting onto the PCA basis). You have already written most of the code for this part. However, note the difference in variable names as we are now working with test data.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    First let's look at what our raw test data looks like.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Task 5a: Test Data Preprocessing
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Let's repeat what we did for our training data, so we can try out the test data on our trained model!
    """)
    return


@app.cell
def _(word_set, plt, test_dict):
    _word_number = 0
    for _word_raw_test in test_dict.values():
        plt.plot(_word_raw_test.T)
        plt.title('Test sample for "{}"'.format(word_set[_word_number]))
        _word_number = _word_number + 1
        plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Perform enveloping and trimming of our test data.
    """)
    return


@app.cell
def _(length, pre_length, process_data, test_dict, threshold):
    processed_test_dict = process_data(test_dict, length, pre_length, threshold, plot=True, envelope=True)
    return (processed_test_dict,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Construct the PCA matrix from the processed test data. Refer to the code we used above for the training set!
    """)
    return


@app.cell
def _(np, processed_test_dict):
    # Same idea as processed_A, but built from processed_test_dict
    processed_A_test = ...  # YOUR CODE HERE
    return (processed_A_test,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### Now we will do something slightly different

    Previously, you projected data onto your PCA basis with $(x - \bar{x})P$, where $\bar{x}$ is the mean vector, $x$ is a single row of `processed_A`, and $P$ is `new_basis`.

    We can rewrite this operation as:

    $$(x - \bar{x})P = xP - \bar{x}P = xP - \bar{x}_{\text{proj}}$$

    where

    $$\bar{x}_{\text{proj}} = \bar{x}P$$

    Why might we want to do this? In the real world, we want our data to take up as little storage as possible. Instead of storing a length $n$ vector $\bar{x}$, we can precompute $\bar{x}_{\text{proj}} \in \mathbb{R}^k$ (where $k$ is the number of principal components, 3 by default) and store that instead!

    Compute $\bar{x}_{\text{proj}}$ using the **same mean vector** as the one computed with the training data.
    """)
    return


@app.cell
def _(mean_vec, new_basis, np):
    # Project the (training) mean vector onto the new basis, just like you would project a data point
    projected_mean_vec = ...  # YOUR CODE HERE
    print(new_basis.shape)
    print(mean_vec)
    return (projected_mean_vec,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Project the test data onto the **same PCA basis** as the one computed with the training data.
    """)
    return


@app.cell
def _(new_basis, np, processed_A_test):
    # Project every test recording onto new_basis (do NOT subtract the mean yet; that is the next step)
    projected_A_test = ...  # YOUR CODE HERE
    return (projected_A_test,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Zero-mean the projected test data using the **`projected_mean_vec`**.
    """)
    return


@app.cell
def _(projected_A_test, projected_mean_vec):
    # Subtract projected_mean_vec from each projected test recording
    proj_1 = ...  # YOUR CODE HERE
    print(projected_mean_vec.shape)
    return (proj_1,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Plot the projections to see how well your test data clusters in this new basis. This will give you an idea of test classification accuracy.
    """)
    return


@app.cell
def _(
    Axes3D,
    word_set,
    centroid_list,
    centroids,
    cm,
    colors,
    new_basis,
    np,
    num_samples_test,
    plt,
    proj_1,
):
    if new_basis.shape[1] == 3:
        _fig = plt.figure(figsize=(10, 7))
        _ax = _fig.add_subplot(111, projection='3d')
        for _i in range(len(word_set)):
            Axes3D.scatter(_ax, *proj_1[_i * num_samples_test:num_samples_test * (_i + 1)].T, c=cm[_i], marker='o', s=20)
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1.07, 0.5))
        plt.title('Test Data')
        for _i in range(len(word_set)):
            Axes3D.scatter(_ax, *np.array([centroids[_i]]).T, c=cm[_i], marker='*', s=300)
        (_fig, _axs) = plt.subplots(1, 3, figsize=(15, 5))
        for _i in range(len(word_set)):
            _axs[0].scatter(proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 0], proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 1], c=cm[_i], edgecolor='none')
            _axs[1].scatter(proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 0], proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 2], c=cm[_i], edgecolor='none')
            _axs[2].scatter(proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 1], proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 2], c=cm[_i], edgecolor='none')
        _axs[0].set_title('View 1')
        _axs[1].set_title('View 2')
        _axs[2].set_title('View 3')
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1, 0.5))
        _axs[0].scatter(centroid_list[:, 0], centroid_list[:, 1], c=colors, marker='*', s=300)
        _axs[1].scatter(centroid_list[:, 0], centroid_list[:, 2], c=colors, marker='*', s=300)
        _axs[2].scatter(centroid_list[:, 1], centroid_list[:, 2], c=colors, marker='*', s=300)
        plt.show()
    elif new_basis.shape[1] == 2:
        _fig = plt.figure(figsize=(10, 7))
        for _i in range(len(word_set)):
            plt.scatter(proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 0], proj_1[_i * num_samples_test:num_samples_test * (_i + 1), 1], c=colors[_i], edgecolor='none')
        plt.scatter(centroid_list[:, 0], centroid_list[:, 1], c=colors, marker='*', s=300)
        plt.legend(word_set, loc='center left', bbox_to_anchor=(1, 0.5))
        plt.title('Test Data')
        plt.show()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Now that we have some idea of how our test data looks in our PCA basis, let's see how our data actually performs. Implement the `classify` function, which takes a data point after enveloping and returns the word whose centroid is closest in Euclidean distance.
    """)
    return


@app.cell
def _(np):
    def classify(word_set, data_point, new_basis, projected_mean_vec, centroids):
        """Classifies a new voice recording into a word.

        Args:
            word_set (list): set of words that we've chosen
            data_point (np.array): new data point vector before demeaning and projection
            new_basis (np.array): the new processed basis to project on
            projected_mean_vec (np.array): the same projected_mean_vec as before
            centroids (list): the centroid of each word's cluster, in the same order as word_set
        Returns:
            (string): The classified word
        Hint:
            Remember to use 'projected_mean_vec'!
            np.argmin(), and np.linalg.norm() may also help!
        """
        # TODO: classify the demeaned data point by comparing its distance to the centroids
        # YOUR CODE HERE
        projected_data_point = ...  # YOUR CODE HERE

        # hint: demean with the precomputed mean vector
        demeaned = ...  # YOUR CODE HERE

        # hint: we're returning the word that this data point classified as
        return ...  # YOUR CODE HERE
    return (classify,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Try out the classification function below.
    """)
    return


@app.cell
def _(
    word_set,
    centroids,
    classify,
    new_basis,
    processed_A_test,
    projected_mean_vec,
):
    # Try out the classification function
    # Modify the row index of processed_A_test to use other vectors
    print(classify(word_set, processed_A_test[0,:], new_basis, projected_mean_vec, centroids))
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    **Our goal is 80% accuracy for each word.** Apply the `classify` function to each sample and compute the accuracy for each word. If you do not meet 80% accuracy for each word, try to find different combinations of words/parameters that result in more distinct clusters in the plots of the projected data.
    """)
    return


@app.cell
def _(
    word_set,
    centroids,
    classify,
    new_basis,
    np,
    num_samples_test,
    processed_A_test,
    projected_mean_vec,
):
    correct_counts = np.zeros(len(word_set))
    for (row_num, data) in enumerate(processed_A_test):
        word_num = row_num // num_samples_test
        if classify(word_set, data, new_basis, projected_mean_vec, centroids) == word_set[word_num]:
            correct_counts[word_num] = correct_counts[word_num] + 1
    for _i in range(len(correct_counts)):
        print('Percent correct of word {} = {}%'.format(word_set[_i], 100 * correct_counts[_i] / num_samples_test))
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(f"""
    Why did we choose to classify with three PCA components? What would happen if we went down to two or even one PCA component? What would happen if we increased the number of PCA components? Scroll back up to the `PCA_comp_num` slider in Task 3c and try different numbers. Changing it automatically reruns dependent cells, so the percentages above may change. Give Marimo a couple of seconds to rerun and render the results.
    """)
    return


@app.cell(hide_code=True)
def _(PCA_comp_num_ans, mo):
    mo.md(f"""
    How many PCA components did you choose, and why?

    {mo.as_html(PCA_comp_num_ans)}
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    <a id='task6'></a>
    ## <span style="color:navy">Task 6: Testing the classifier -- Real Time</span>
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Now, we'll be testing the classifier in real time.

    /// attention | Fill in the code first
    **Fill in the two `# YOUR CODE HERE` lines in the code cell below *before* you click the recording button.** The button is located *below* the code cell.
    ///

    Then, click the button below the code cell and, when prompted, say one of the words in `word_set`. Remember that `length`, `pre_length`, and `threshold` hold the **current slider values** from Task 2 (they are set from `length_slider.value`, `pre_length_slider.value` and `threshold_radio.value` for you), so you can pass them directly into `align_recording`.
    """)
    return


@app.cell
def _(
    align_recording,
    centroids,
    classify,
    display,
    length,
    live_classify_button,
    new_basis,
    pre_length,
    projected_mean_vec,
    word_set,
    threshold,
    time,
    utils,
):
    rate = 5400  # Sample rate
    chunk = 1024  # Chunk size
    record_seconds = 3  # Record duration in seconds
    num_recordings = 40  # Total number of recordings needed
    recording_count = 0
    word = ""

    if live_classify_button.value:
        while True:
            user_input = input("Press Enter to start recording, or type 'stop' and then Enter to stop recording: ")

            if user_input == '':
                # Record audio
                audio_recording = utils.record_audio(seconds=record_seconds, rate=rate, chunk=chunk)

                # Preprocess the single recording with align_recording(), the same way you did in Task 2.
                # Pass in: the recording, then length, pre_length, threshold (in that order; these are the slider values you chose in Task 2), and set envelope=True.
                processed_audio_recording = align_recording(audio_recording, ..., ..., ..., envelope=True)  # YOUR CODE HERE

                # Classify the processed recording with classify(). It takes (word_set, data_point, new_basis, projected_mean_vec, centroids).
                print("Classified Word: " + classify(word_set, processed_audio_recording, ..., ..., ...))  # YOUR CODE HERE
                time.sleep(2)

            if user_input == 'stop':
                display.clear_output()
                break
    return


@app.cell(hide_code=True)
def _(live_classify_button, mo):
    mo.md(f"""
    Once your code above is filled in, click the button below to start live classification:
    <br><br>
    {mo.as_html(live_classify_button)}
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## <span style="color:green">CHECKOFF</span>

    ### When you are ready to get checked off, fill out the **[checkoff Google form](https://forms.gle/pwqopqgEaHvv7GUk9)**


    - **Have all questions, code, and plots completed in this lab.** Your TA will check all your PCA code and plots.
    - **Show your TA that you've achieved 80% accuracy on your test data for all of your words.**
    - **Show your TA that you are able to classify live.**
    - **Be prepared to answer conceptual questions about the lab.**

    ## Feedback

    [Submit anonymous lab feedback](https://forms.gle/ezDiDHxYRHN7xtdV9). Completing the feedback form is optional.
    """)
    return


@app.cell
def _():
    import marimo as mo
    return (mo,)


@app.cell(hide_code=True)
def _(csv, display, mo, train_dict, utils):
    # contains the variables for Marimo interative features
    # DO NOT MODIFY

    length_slider = mo.ui.slider(
        start=1000, stop=8000, step=250, value=4000, label="Length", show_value=True
    )
    pre_length_slider = mo.ui.slider(
        start=0, stop=2000, step=100, value=400, label="Pre-Length", show_value=True
    )
    threshold_radio = mo.ui.radio(
        options={"0.25": 0.25, "0.50": 0.5, "0.75": 0.75, "1.00": 1.00},
        value="0.25",
        label="Threshold",
    )
    jack_data = {"jack": train_dict["jack"]}

    record_button = mo.ui.run_button(label="Start Recording")
    live_classify_button = mo.ui.run_button(label="Start Recording")

    parameter_answer = mo.ui.text_area(placeholder="type your answer here ...")

    alignment_answer = mo.ui.text_area(placeholder="type your answer here ...")

    svd_hint = mo.as_html(
        mo.accordion({"Click for a hint": "np.linalg.svd may be useful here"}, lazy=False)
    )

    stem_hint = mo.as_html(
        mo.accordion({"Click for a hint": "use plt.stem to create a stem plot"}, lazy=False)
    )

    proj_hint_1 = mo.as_html(
        mo.accordion({"Hint #1": "Of the three outputs from the SVD function call, which one will contain the principal components onto which we want to project our data points? Do we need to transpose it?"}, lazy=False)
    )
    proj_hint_2 = mo.as_html(
        mo.accordion({"Hint #2": "For a data matrix $A \\in \\mathbb{R}^{m \\times n}$ with SVD $A = U\\Sigma V^T$, the columns of $U$ form a basis for the column space of $A$ and the columns of $V$ form a basis for the row space of $A$. Each row of our data is a recording, so the principal components we want live in the row space. NumPy returns `Vt` (that is, $V^T$), so the principal components are the **rows** of `Vt`."}, lazy=False)
    )
    proj_hint_3 = mo.as_html(
        mo.accordion({"Hint #3": "The first `PCA_comp_num` principal components are the first `PCA_comp_num` rows of `Vt`, i.e. `Vt[:PCA_comp_num, :]`, which has shape `(PCA_comp_num, length)`. We want each principal component to be a **column** of `new_basis` so that `demeaned_A @ new_basis` has compatible shapes, so you need to transpose it (`.T`)."}, lazy=False)
    )

    proj_eq = "$$\\text{proj}_{\\text{Col(Q)}} (\\vec{y}) = QQ^T \\vec{y} = \\sum^n_{i=1} \\langle \\vec{y}, \\vec{q}_i \\rangle \\vec{q}_i$$"

    PCA_comp_num_slider = mo.ui.slider(
        start=1, stop=10, value=3, label="Number of PCA Components", show_value=True
    )

    PCA_comp_num_ans = mo.ui.text_area(placeholder="type your answer here ...")

    def create_recording_csv(rate=5400, chunk=1024, record_seconds=3, num_recordings=40):
        filename = input("Enter the CSV file name (it will be created): ")
        if not filename.endswith('.csv'):
            print("Warning: filename does not end with .csv. Appending .csv to the filename.")
            filename = filename + '.csv'

        recording_count = 0

        with open(filename, mode='w', newline='') as file:
            writer = csv.writer(file)

            try:
                while recording_count < num_recordings:
                    user_input = input("Press Enter to start recording, or type 'd' and then Enter to remove the last entry, or type 'stop' and then Enter to stop recording: ")

                    if user_input == '':
                        # Record audio
                        audio_data = utils.record_audio(seconds=record_seconds, rate=rate, chunk=chunk)
                        writer.writerow(audio_data)
                        file.flush()

                        recording_count += 1

                        display.clear_output()
                        print(f"Audio data saved to CSV. Recorded {recording_count}/{num_recordings}. Length of vector: {len(audio_data)}\n")

                    elif user_input.lower() == 'd': 
                        if recording_count > 0:
                            # Remove the last entry
                            with open(filename, mode='r') as f:
                                lines = f.readlines()
                            with open(filename, mode='w') as f:
                                f.writelines(lines[:-1])

                            recording_count -= 1
                            display.clear_output()
                            print(f"Last recording removed. Recorded {recording_count}/{num_recordings}.")
                        else:
                            print("No entries to delete.")
                    elif user_input.lower() == 'stop': 
                        break

            except KeyboardInterrupt:
                print("Data collection stopped.")

        print("Data collection stopped. Saved to " + filename)
    return (
        PCA_comp_num_ans,
        PCA_comp_num_slider,
        alignment_answer,
        create_recording_csv,
        jack_data,
        length_slider,
        live_classify_button,
        parameter_answer,
        pre_length_slider,
        proj_eq,
        proj_hint_1,
        proj_hint_2,
        proj_hint_3,
        record_button,
        stem_hint,
        svd_hint,
        threshold_radio,
    )



if __name__ == "__main__":
    app.run()

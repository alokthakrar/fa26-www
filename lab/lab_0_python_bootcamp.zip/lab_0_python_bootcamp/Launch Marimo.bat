@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"

set "PYTHON_EXE="
for %%P in (
    "%~dp0..\..\.venv\Scripts\python.exe"
    "%ProgramData%\Miniconda3\python.exe"
    "%LocalAppData%\miniconda3\python.exe"
    "%UserProfile%\miniconda3\python.exe"
    "%UserProfile%\anaconda3\python.exe"
) do (
    if not defined PYTHON_EXE if exist "%%~P" (
        "%%~P" -c "import marimo" >nul 2>&1
        if not errorlevel 1 set "PYTHON_EXE=%%~P"
    )
)

if not defined PYTHON_EXE (
    where python >nul 2>&1
    if not errorlevel 1 (
        python -c "import marimo" >nul 2>&1
        if not errorlevel 1 set "PYTHON_EXE=python"
    )
)

if not defined PYTHON_EXE (
    echo ERROR: Could not find a Python environment with marimo installed.
    echo Install the lab requirements, then run this launcher again.
    pause
    exit /b 1
)

"%PYTHON_EXE%" -m marimo edit "ee66_python_bootcamp.py"
if errorlevel 1 echo ERROR: marimo exited with an error.
pause
